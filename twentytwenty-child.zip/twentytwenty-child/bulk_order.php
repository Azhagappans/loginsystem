<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: Bulk Order
 */
 get_header();
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
            <div class="">
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive">
                            <table class="table table-bordered list_table dt-responsive display nowrap"  id="bulk_orders_table">
                                <thead>
                                    <tr>
                                        <th scope="col" width="20%" id="contactName">Contact Name</th>
                                        <th scope="col" width="20%" id="contactMail">Contact Email</th>
                                        <th scope="col" width="20%" id="contactPhn">Contact Phone</th>
                                        <th scope="col" width="20%" id="deliveryDate">Expected Delivery Date</th>
                                        <th scope="col" width="20%" class="actions" >Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                global $wpdb;
                                $tablename = $wpdb->prefix.'bulk_order';
                                $query_sql ="SELECT *  FROM $tablename";
                                $bulk_order = $wpdb->get_results( $wpdb->prepare($query_sql));
                                // print_r($users);
                                foreach($bulk_order as $value){
                                    $s = $value->expected_date;
                                    $dt = new DateTime($s);

                                    $date = $dt->format('Y-m-d');
                                ?>
                                    <tr>
                                        <td><?php echo $value->contact_name; ?></td>
                                        <td><?php echo $value->contact_email; ?></td>
                                        <td><?php echo $value->contact_phone; ?></td>
                                        <td><?php echo $date; ?></td>
                                        <td>
                                            <button type="button" data-target="#exampleModalLong<?php echo $value->id; ?>" class="btn btn-primary recept_btn" data-toggle="modal" title="View"><i class="fa fa-eye"></i></button>
                                        </td>
                                    </tr>
                                        
                                    <!-- Modal -->
                                    <div class="modal fade bulk_order_model" id="exampleModalLong<?php echo $value->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle">Order Details</h5>
                                                
                                                </button>
                                            </div>
                                            
                                            <div class="modal-body">
                                                <div class="container-fluid">
                                                    <div class="row">
                                                        <div class="col">
                                                            <p><strong>Contact Name :</strong> <?php echo $value->contact_name; ?></p>
                                                            <p><strong>Contact Email :</strong> <?php echo $value->contact_email; ?></p>
                                                            <p><strong>Contact Phone Number :</strong> <?php echo $value->contact_phone; ?></p>
                                                            <p><strong>Expected Delivery Date :</strong> <?php echo $date; ?></p>
                                                            <p><strong>Your Message :</strong> <?php echo $value->your_details; ?></p>
                                                            <p><strong>Create At :</strong> <?php echo $value->create_at; ?></p>
                                            
                                                        </div>

                                                    </div>
                                                    <div class="row">
                                                        <div class="col">
                                                            <button type="button" class="btn bulk_order_close btn-default rec_common_btn" data-dismiss="modal">Close</button>
                                                            <a href="<?php echo admin_url().'/post-new.php?post_type=shop_order'; ?>" target="_blank" class="btn btn-default bulk_order_close rec_common_btn">Bulk Order</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            </div>
                                        </div>
                                    </div>

                                <?php
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
    </div>
</div>

<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>