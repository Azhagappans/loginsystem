<?php
global $wpdb;
$tablename = $wpdb->prefix.'bulk_order';

/*$wpdb->insert( $tablename, array(
    'contact_name' => $_POST['contact_name'], 
    'contact_email' => $_POST['contact_email'],
    'contact_phone' => $_POST['contact_phone'], 
    'expected_date' => date('Y-m-d', strtotime($_POST['expected_date'])),
    'your_message' => $_POST['your_message']
    ),
    array( '%s', '%s', '%s', '%s', '%s') 
        );*/

$sql = "INSERT INTO `".$wpdb->prefix."bulk_order` (`contact_name`,`contact_email`,`contact_phone`,`expected_date`,`your_details`) values ('" . $_POST['contact_name'] . "', '" . $_POST['contact_email'] . "', '" . $_POST['contact_phone'] . "', '" . date('Y-m-d', strtotime($_POST['expected_date'])). "', '" . $_POST['your_message'] . "')";

$wpdb->query($sql);

//send mail
//$to = "testmail5210@gmail.com";
$to = get_option( 'admin_email' );
$subject = "New Bulk Order: Voucher";
$message = "
<html>
<head>
<title>Property Ads</title>
</head>
<body>
<p><b>Contact Name:</b> ". $_POST['contact_name'] ."</p>
<p><b>Contact Email:</b> ". $_POST['contact_email'] ."</p>
<p><b>Contact Phone:</b> ". $_POST['contact_phone'] ."</p>
<p><b>Expected Delivery Date:</b> ". $_POST['expected_date'] ."</p>
<p><b>Your Details:</b> ". $_POST['your_details'] ."</p>
</body>
</html>
";

// Always set content-type when sending HTML email
// $headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: '. $_POST['contact_email'] .  "\r\n";

$result = mail($to,$subject,$message,$headers);

?>