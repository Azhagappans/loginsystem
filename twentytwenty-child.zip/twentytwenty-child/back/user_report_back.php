<?php 
if (get_current_user_id()) {
    // display navbar here
 ?>
 <?php
/**

*/
 get_header();
?>
<div class="main-content-area payment_report">
<div class="page-inner-wrapper">
<div class="user-management-page white-bg-wrap">

    <div class="container">
    <div class="row">
    <div class="col-12">

        <table cellspacing="5" cellpadding="5" class="borderless">
        <tbody>
            <tr>
                <td><h4>Registered Date:</h4></td>
                <td>From:</td>
                <td><input type="text" id="minid" name="minid" class="date_input_filters"></td>
                <td>To:</td>
                <td><input type="text" id="maxid" name="maxid" class="date_input_filters"></td>
                <td><button type="" id="regiFilter" class="action-btn" data-toggle="modal"  title="Filter"><i class="fa fa-filter"></i></button></td>
                <td><button type="" id="regiRedo" class="action-btn" data-toggle="modal"    title="Reset"><i class="fa fa-repeat"></i></button></td>
            </tr>
            <tr>
                <td><h4>Last Order Date:</h4></td>
                <td>From:</td>
                <td><input type="text" id="dlo_from" name="dlo_from" class="date_input_filters"></td>
                <td>To:</td>
                <td><input type="text" id="dlo_to" name="dlo_to" class="date_input_filters"></td>
                <td><button type="" id="dloFilter" class="action-btn" data-toggle="modal"   title="Filter"><i class="fa fa-filter"></i></button></td>
                <td><button type="" id="dloRedo" class="action-btn" data-toggle="modal"     title="Reset"><i class="fa fa-repeat"></i></button></td>
            </tr>
            <tr>
                <td><h4>Last Order Value:</h4></td>
                <td>Minimum Price:</td>
                <td><input type="number" id="priceMin" name="priceMin" min="0"  class="date_input_filters"></td>
                <td>Maximum Price:</td>
                <td><input type="number" id="priceMax" name="priceMax" min="0"  class="date_input_filters"></td>
                <td><button type="" id="filter" class="action-btn" data-toggle="modal"  title="Filter"><i class="fa fa-filter"></i></button></td>
                <td><button type="" id="Reset" class="action-btn" data-toggle="modal"   title="Reset"><i class="fa fa-repeat"></i></button></td>
            </tr>
        </tbody>
        </table>
    </div>
    </div>
    </div>

    <div class="container">
    <div class="row">
    <div class="col-md-12">

        <div class="table-responsive">
            <table class="table table-bordered list_table column_height user_report_table"  id="report_table">
            <thead>
                <tr>
                    <th id="firstNameCol">Name</th>
                    <th id="dateCreated">Date Registered</th>
                    <th id="lastOrderDate">Date Last Order</th>
                    <th id="valueLastOrder">Value Last Order</th>
                    <th class="table_hide CustomerEmail">Email</th>
                    <th class="table_hide phonenumber">Phone Number</th>
                    <th class="table_hide CustomerCountry">Country</th>
                    <th class="table_hide CustomerCity">City</th>
                    <th class="table_hide companyname">Company Name</th>
                    <th class="table_hide companyname">Company Registration Number</th>
                    <th class="table_hide companyname">VAT Registration Number</th>
                    <th class="table_hide addressname">Company Address</th>
                    <th class="table_hide OrderId">Order Id</th>
                    <th class="table_hide ItemsSold">No.of Items sold</th>
                    <th class="table_hide ShippingTotal">Shipping Total</th>
                    <th class="table_hide OrderStatus">Order Status</th>
                    <th>Actions</th>                    
                </tr>
            </thead>
            <tbody>
                <?php
                    global $wpdb;
                
                    $users = get_users();       
                    // print_r($users);
                    foreach($users as $user) { 
                        $firstName = get_user_meta($user->ID, 'first_name', true);
                        $displayname = get_user_meta($user->ID, 'nickname', true);
                        $lastName = get_user_meta($user->ID, 'last_name', true);
                        $udata = get_userdata( $user->ID );
                        $registered = $udata->user_registered;

                        $customer = new WC_Customer($user->ID);
                        
                        $order_id     = '';
                        $order        = '';
                        $order_date   = '';
                        $item_total   = ''; 
                        $item_quantity  = '';
                        $shipping_total = '';
                        $order_status  = '';
                        $email = '';
                        $billing_country = '';
                        $billing_city = '';
                        $country = '';
                        $city = '';
                        $phone_number = '';
                        $company_name = '';
                        $company_reg = '';
                        $company_vat = '';
                        $company_address = '';
                        
                        $last_order = $customer->get_last_order();

                        if(isset($last_order) && !empty($last_order)){
                            $order_id     = $last_order->get_id();
                            $order        = wc_get_order( $order_id );
                            $order_date   = $order->get_date_created();
                            $item_total   = $order->get_total();

                            foreach ( $order->get_items() as $item_id => $item ) {
                                $item_quantity = $item->get_quantity();
                            }
                            $shipping_total = $order->get_total_shipping();
                            $order_status  = $order->get_status();
                            $email = get_userdata($order->get_user_id() ) ? $a->user_email : '';
                            $billing_country = $order->get_billing_country();
                            $billing_city = $order->get_billing_city();
                        }

                        $all_meta_for_user = get_user_meta($user->ID);

                        $country = $all_meta_for_user['country'][0];
                        $city = $all_meta_for_user['user_city'][0];
                        $phone_number = $all_meta_for_user['mobile_number'][0];
                        $company_name = $all_meta_for_user['company-name'][0];
                        $user_email = $customer->email;
                        $company_reg = $all_meta_for_user['company-registration-number'][0];
                        $company_vat = $all_meta_for_user['vat-registration-number'][0];
                        $company_address = $all_meta_for_user['user-address'][0];
                    
                ?>
                    <tr>
                        <td>
                            <?php
                            if(!empty($firstName) || !empty($lastName)){
                                echo $firstName; ?> <?php echo $lastName; 
                            }else{
                                echo $displayname;
                            }
                            ?>
                        </td>
                        <td><?php echo date('Y-m-d', strtotime($registered)); ?></td>
                        <td><?php if(!empty($order_date)){ echo date('Y-m-d', strtotime($order_date)); }else{ echo '-';} ?></td>
                        <td><?php if(!empty($item_total)){ echo get_woocommerce_currency_symbol().$item_total; }else{ echo '-';} ?></td>
                        <td class="table_hide"><?php echo $user_email; ?></td>
                        <td class="table_hide"><?php echo $phone_number; ?></td>
                        <td class="table_hide"><?php echo $country; ?></td>
                        <td class="table_hide"><?php echo $city; ?></td>
                        <td class="table_hide"><?php echo $company_name; ?></td>
                        <td class="table_hide"><?php echo $company_reg; ?></td>
                        <td class="table_hide"><?php echo $company_vat; ?></td>
                        <td class="table_hide"><?php echo $company_address; ?></td>
                        <td class="table_hide"><?php echo $order_id; ?></td>
                        <td class="table_hide"><?php echo $item_quantity; ?></td>
                        <td class="table_hide"><?php if(!empty($shipping_total)){ echo get_woocommerce_currency_symbol().$shipping_total; }else{ echo get_woocommerce_currency_symbol().'0';} ?></td>
                        <td class="table_hide"><?php echo $order_status; ?></td>
                        <td>     
                            <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#exampleModalLong<?php echo $user->ID; ?>" id="<?php echo $user->ID; ?>" title="View" data-original-title="View" class="red-tooltip"><i class="fa fa-eye"></i></button>
                            <button type="button" class="btn btn-success recipient_update recept_btn user_edit_btn" data-toggle="modal" onclick="window.location.href='<?php echo admin_url(); ?>/user-edit.php?user_id=<?php echo $user->ID; ?>';" id="<?php echo $user->ID; ?>" title="Edit" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>
                            
                            </td>

                        
                        
                    </tr>
                    <!-- View Modal -->
                    <div class="modal fade bulk_order_model" id="exampleModalLong<?php echo $user->ID; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">User Details</h5>
                                
                                </button>
                            </div>
                            
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col">
                                            <p><strong>Name :</strong> 
                                            <?php
                                            if(!empty($firstName) || !empty($lastName)){
                                                echo $firstName; ?> <?php echo $lastName; 
                                            }else{
                                                echo $displayname;
                                            }
                                            ?>
                                            </p>
                                            <p><strong>Email :</strong> <?php echo $user_email; ?></p>
                                            <p><strong>Phone Number :</strong> <?php echo $phone_number; ?></p>
                                            <p><strong>Country :</strong> <?php echo $country; ?></p>
                                            <p><strong>Registered At :</strong> <?php echo date('Y-m-d', strtotime($registered)); ?></p>
                                            <p><strong>City :</strong> <?php echo $city; ?></p>
                                            <p><strong>Company Name :</strong> <?php echo $company_name; ?></p>
                                            <p><strong>Company Registration Number:</strong> <?php echo $company_reg; ?></p>
                                            <p><strong>VAT Registration Number:</strong> <?php echo $company_vat; ?></p>
                                            <p><strong>Company Address:</strong> <?php echo $company_address; ?></p>
                            
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <button type="button" class="btn bulk_order_close btn-default rec_common_btn" data-dismiss="modal">Close</button>
                                            <!-- <a href="<?php echo admin_url().'/post-new.php?post_type=shop_order'; ?>" target="_blank" class="btn btn-default bulk_order_close rec_common_btn">Bulk Order</a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            </div>
                        </div>
                    </div>

                <?php
                    } ?>
            </tbody>
            </table>
        </div>

    </div>
    </div>
    </div>

</div>
</div>
</div>

<?php get_footer(); ?>
<?php
// display navbar here
} 
else {
    wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); 
}
?>