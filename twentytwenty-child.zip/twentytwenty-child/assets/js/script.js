jQuery(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
     
	
	setInterval(function(){  $('[data-toggle="tooltip"]').tooltip(); }, 3000);
	
	
    if (typeof(Storage) !== "undefined") {
            
        // Retrieve
        var action = localStorage.getItem("action");
        if(action == "true"){
            
        jQuery(".sidebar-toggle span").parents().find(".sidebar-wrapper").removeClass("min-sidebar");
        jQuery(".sidebar-toggle span").parents().find(".sidebar-wrapper").siblings(".main-page-wrapper").removeClass("min-sidebar");
        }
    }

    jQuery(".sidebar-toggle span").click(function(){
        jQuery(this).parent().toggleClass("active");
        jQuery(this).parents().find(".sidebar-wrapper").toggleClass("min-sidebar");
        jQuery(this).parents().find(".sidebar-wrapper").siblings(".main-page-wrapper").toggleClass("min-sidebar");
        // sidebarheight();
       

        if(jQuery(this).parents().find(".sidebar-wrapper").hasClass("min-sidebar") ){
        //    alert("close");
           // Check browser support
            if (typeof(Storage) !== "undefined") {
                // Store
                localStorage.setItem("action", "false");
                // Retrieve
                // document.getElementById("result").innerHTML = localStorage.getItem("action");
            } else {
                document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            }
        }else{
            // alert("open");
            // Check browser support
            if (typeof(Storage) !== "undefined") {
                // Store
                localStorage.setItem("action", "true");
                // Retrieve
                // document.getElementById("result").innerHTML = localStorage.getItem("action");
            } else {
                document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            }
        }
    });
    //Mob Menu
    if(jQuery(window).width() < 768){
        jQuery(".mob-toggle").click(function(){
            jQuery(".sidebar-toggle span").trigger("click");
        })
    }

  //Menu Active toggle
  jQuery(".menu-wrapper ul li a").click(function(){
    jQuery(".menu-wrapper ul li").removeClass("active");
    jQuery(this).parent().addClass("active");
    jQuery(this).parents("li").addClass("active");
})

//SIdebar toggle
jQuery(".help-wrapper a").click(function(){
    jQuery(".help-sidebar").addClass("active")
})
jQuery(".help-sidebar .close").click(function(){
    jQuery(this).parent().removeClass("active");
})

    if(jQuery(".menu-wrapper ul > li").hasClass("active") ){
        jQuery(".menu-wrapper ul > li.active").find(".panel-collapse").toggleClass("show");
    } 
    jQuery(".form-control").focusin(function(){
        
        jQuery(this).parents(".form-group").addClass("label-top");
    });
    jQuery(".form-control").focusout(function(){
        
        jQuery(this).parents(".form-group").removeClass("label-top");
        
        if(jQuery(this).val().length>0)
        {
            jQuery(this).parents(".form-group").addClass('label-top');
        }
        else
        {
            jQuery(this).parents(".form-group").removeClass('label-top');  
        }
    
    })

    jQuery("select").focusin(function(){
        jQuery(this).parents(".form-group").addClass("label-top");
    
    })
    jQuery("select").focusout(function(){
        jQuery(this).parents(".form-group").removeClass("label-top");
        if(jQuery(this).val().length>0)
        {
            jQuery(this).parents(".form-group").addClass('label-top');
        }
        else
        {
            jQuery(this).parents(".form-group").removeClass('label-top');  
        }
    
    })
    jQuery(".form-control").each(function(){
        if(jQuery(this).val()){
        jQuery(this).parents(".form-group").addClass("label-top");
        }
    })

function checkForInput(){

    if (jQuery(".form-control").val().length > 0) {
    jQuery(this).parents("form-group").addClass("label-top")
    } else {
        jQuery(this).parents("form-group").removeClass('label-top');
    }

}
jQuery('.form-control').on('change keyup', function() {
    checkForInput(this);  
    jQuery(this).parents(".form-group").addClass("label-top");
  });

  jQuery(".form-control").keypress(function(){
      valLength = jQuery(this).val().length ;
        setInterval(function(){
            if(valLength < 1){
                jQuery(this).parents(".form-group").addClass("no-value");
            }
        },1000)
    })
    
    


    //Main content scroll
    var contentHeight = jQuery(".main-page-wrapper").height();
    var headerHeight =  jQuery(".cus-header").height();
    var scrollHeight = contentHeight - headerHeight;
    jQuery(".main-content-area").css({"max-height": scrollHeight - 30});
  
});

jQuery('.custom-register-form .um-form-field').removeAttr('placeholder');

jQuery('.um-field-checkbox .um-field-label').remove();

jQuery("label[for='account_display_name']").remove();
