// Filter vouchers from recipient starts
jQuery('.recipient').on('change', function() {
    var recipient = $(".recipient").children("option:selected").attr("id");
    $("#retailer-tooltip").removeAttr("data-original-title", "Select Recipient First");
    if(recipient == 0){ 
        $(".retailer").prop("disabled", true );
        $(".voucher_price").prop("disabled", true ); 
        $("#retailer-tooltip").attr("data-original-title", "Select Recipient First");
        $("#value-tooltip").attr("data-original-title", "Select Retailer First");
        
        // $("select.retailer").find('option').remove();
        // $("select.voucher_price").find('option').remove();
        // $("#buy").css("pointer-events", "none");
    }else{
        // $("#value-tooltip").removeAttr("data-original-title", "Select Retailer First");
        $("#retailer-tooltip").removeAttr("data-original-title", "Select Recipient First");
        $(".retailer").prop("disabled", false );
        $(".voucher_price").prop("disabled", false );
    }
});
// Filter vouchers from recipient end

// Filter price from vouchers starts
jQuery('.retailer').on('change', function() {
    var voucher = $(".retailer").children("option:selected").attr("id");
    $("#value-tooltip").removeAttr("data-original-title", "Select Retailer First.");
    if(voucher == 0 ){ 
        $("select.voucher_price").find('option').remove();
        $("#value-tooltip").attr("data-original-title", "Select Retailer First.");
              
    } else {
        $("#overlay").fadeIn(300);
    $.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "pricelist",nonce_ajax : frontEndAjax.nonce,voucher:voucher},
        //dataType : "json",
    }).done(
        function(data){
            setTimeout(function(){
                $("#overlay").fadeOut(300);
            });
            $('#retailer').removeClass('disabled');
            $('#voucher_price').removeClass('disabled');
            $("#value-tooltip").removeAttr("data-original-title", "Select Retailer First.");

            var price_value = '<option value="0">Please Select Value</option>';
            console.log(data);
            if(data == '0') {
                // alert("Please select another recipient");
                $('#retialer_error').css('display','block');
                $("#value-tooltip").attr("data-original-title", "Select Retailer First.");
                $("select.voucher_price").find('option').remove();
                $("select.voucher_price").html('<option value="0">Please Select Value</option>');
            } else {
                $('#retialer_error').css('display','none');
                $("#value-tooltip").removeAttr("data-original-title", "Select Retailer First.");
                price_value += data;
                $("select.voucher_price").html(price_value);
            }
            
            
        });
    }
});
// Filter price from vouchers end
jQuery('.retailer').on('change', function() {
    var voucher = $(".retailer").children("option:selected").attr("id");
    if(voucher == 0){ 
        // alert("Please Select Retailer");
        $(".addcart").attr("disabled", true);
    }
});
jQuery('.recipient').on('change', function() {
    var recipient = $(".recipient").children("option:selected").attr("id");
    if( recipient == 0 ){ 
        $('#retailer').css('opacity','0.5');
        $('#voucher_price').css('opacity','0.5');
        $('#recipient_error').css('display','block');
        $(".addcart").attr("disabled", true);
        $('input[name="active"]').prop('checked', 'false');
    }else{
        $('#recipient_error').css('display','none');
        $('#retailer').css('opacity','1');
        $('#voucher_price').css('opacity','1');
    }
});
jQuery('#quantity').keyup(function(e){
    var thisval = $(this).val();
    var voucher_price = $('#voucher_price').find(':selected').attr('data-count');
    //alert(voucher_price);
    if(parseInt(thisval)<=parseInt(0)){
        $('#quantity').val(1);
    }

    if(parseInt(thisval)>=parseInt(voucher_price)){
        $('#quantity').val(voucher_price);
    }
});

jQuery('.voucher_price').on('change', function() {
    var productid = $(".voucher_price").children("option:selected").val();
    var count = $(this).val();
    var voucher_count =  $('#voucher_price').find(':selected').attr('data-count');
    // $("#pluscount-max-limit").removeAttr("data-original-title", "Maximum stock available count "+voucher_count);
    //console.log(count);
    if(productid == 0){
        $('#voucher_error').css('display','block');
        $("#buy").addClass('link-button-blue');
        $(".addcart_btn").prop('disabled', true);
        $('.quantity_area').css('display','none');
    } 
    if(productid != 0){
        $("#buy").removeClass('link-button-blue');
        $('#voucher_error').css('display','none');
        $(".addcart_btn").prop('disabled', false);
        $('.quantity_area').css('display','block');
        // $("#pluscount-max-limit").attr("data-original-title", "Maximum stock available count "+voucher_count);
    }
});
// function myFunction(s) {
//     // alert(s[s.selectedIndex].id);
//     // var recid = document.getElementById("recipient").id;
//     sessionStorage.setItem('key', s[s.selectedIndex].id);
//     let rec_data_id = sessionStorage.getItem('key');
//     alert(rec_data_id);
//   }
//   $( 'body' ).load(function() { 
//     $('.recipient').val(rec_data_id);
//   });
//personalize value checked by recipient
$(".recipient").change(function(){
    var rec_id = $(".recipient").children("option:selected").val();
    $("#overlay").fadeIn(300);
    jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "filter_personalize",nonce_ajax : frontEndAjax.nonce,rec_id:rec_id},
        dataType : "json",
        }).done(
        function(data){    
            setTimeout(function(){
                $("#overlay").fadeOut(300);
              });
            $('#retailer').removeClass('disabled');
            // $('#voucher_price').removeClass('disabled');        
            var data1 = JSON.stringify(data[0].personalize);
            var sms = JSON.parse(data1);
            console.log(sms);
            if(sms == "Yes") { 
                $("#active_no").attr('checked', false);
                $("#active_yes").attr('checked', true);  
            }
            if(sms == "No") { 
                $("#active_yes").attr('checked', false);
                $("#active_no").attr('checked', true);  
            }
        });
});


//personalize value checked by recipient
$(".remove").click(function(){
    $("#overlay").fadeIn(300);
});
//Add product to cart session starts
function add_cart(){
    event.preventDefault();
    var retid = $(".retailer").children("option:selected").val();
    var productid = $(".voucher_price").children("option:selected").val();
    var recipient = $(".recipient").children("option:selected").attr("id");
    var rec_number = $(".recipient").children("option:selected").attr("data-id");
    var store_id = $(".recipient").children("option:selected").val();
    var quantity = $(".quantity").val();
    var personalized = $("input[type='radio']:checked").val();
    
    $("#overlay").fadeIn(300);
    $.ajax({
    type: "POST",
    url: frontEndAjax.ajaxurl,
    data: {action: "add_cart",nonce_ajax : frontEndAjax.nonce,productid:productid,recipient:recipient,rec_number:rec_number,store_id:store_id,retid:retid,productid:productid,quantity:quantity,personalized:personalized},
    }).done(
        function(data){
            var data1 = JSON.parse(data);
            if(data1.Error)
            { 
                setTimeout(function(){
                    $("#overlay").fadeOut(300);
                  });
                swal(data1.Error);
                return false;
            } 
            else 
            {
                setTimeout(function(){
                    $("#overlay").fadeOut(300);
                  });
                Swal.fire("Item Added");
                window.location.reload();
                // console.log(data1.recp_id);
                var str = data.replace(/[^\w\s]/gi, '');
                window.location.href = "/voucher/?recp_id="+data1.recp_id;
                // window.location.href = "/voucher/?recp_id="+data1.recp_id+"&retail="+data1.retail+"&product_value="+data1.product_value;
            }
        });
}
//Add product to cart session ends


//////////////////////////////////////////////////////////////////////////
//save recipients starts
$(document).ready(function(){
    $("#recipient_save").click(function(){
        var person_name = $(".person_name").val();
        var person_number = $("#mob_num").val();
        var personalize = $("input[name='personalize']:checked").val();
        var active_status = $("input[name='active']:checked").val();
        
        if((person_name  == '') || (person_number  == '')){
            if(person_name == '' ){
                $("#save_name_error").css('display','block');
            }
            else
            {
                $("#save_name_error").css('display','none');
            }
            if(person_number == '' ){
                $("#save_num_error").css('display','block');
            }
            else
            {
                $("#save_num_error").css('display','none');
            }
            
        }
        else
        {
            $("#overlay").fadeIn(300);
            jQuery.ajax({
                type: "POST",
                url: frontEndAjax.ajaxurl,
                data: {action: "save_recipient",nonce_ajax : frontEndAjax.nonce,
                person_name:person_name,person_number:person_number,personalize:personalize,active_status:active_status},
                dataType : "json",
                }).done(
                function(data){        
                    setTimeout(function(){
                        $("#overlay").fadeOut(300);
                      });  
                    Swal.fire("Recipient Added");
                    console.log(data);
                    window.location.reload();
                });
        }
      });
  });
//save recipients ends





function confirmDeleteModal(id){
    $('#deleteModal').modal();
	$('#deleteButton').html('<a class="btn btn-danger" onclick="deleteData('+id+')">Delete</a>');
}     
function deleteData(id){
    $("#overlay").fadeIn(300);
    jQuery.ajax({
    type: "POST",
    url: frontEndAjax.ajaxurl,
    data: {action: "delete_recipient",nonce_ajax : frontEndAjax.nonce,rec_id:id},
    dataType : "json",
    }).done(
    function(data){      
        setTimeout(function(){
            $("#overlay").fadeOut(300);
          });    
        console.log(data);
        window.location.reload();
    });
}  

function EditModal(id){
    $('#viewModal').modal();
	$('#recipient_update').html('<a class="btn btn-danger" onclick="editData('+id+')">Delete</a>');
}     
function editData(id){
    jQuery.ajax({
    type: "POST",
    url: frontEndAjax.ajaxurl,
    data: {action: "edit_recipient",nonce_ajax : frontEndAjax.nonce,rec_id:id},
    dataType : "json",
    }).done(
    function(data){          
        console.log(data);
        window.location.reload();
    });
} 

$(document).ready(function(){
    tooltipload();
    $(document).on("click",".paginate_button ",function() {
        tooltipload();
    });
   
    $("select").keyup(function() { 
        //console.log('test');
        tooltipload(); 
    });
    $("input").keyup(function() { 
        console.log('test');
        tooltipload(); 
    });
    $(document).on("click",".sorting ",function() {
        tooltipload();
    });
    function tooltipload(){
        $('[data-toggle="modal"]').tooltip();
    }
    // $(".recept_btn ").attr("data-toggle", "tooltip");
    // $(".recept_btn ").attr("data-placement", "top");
    // $(".recept_btn").attr("data-original-title", "View");
    //$(".user_edit_btn").attr("data-original-title", "Edit");
    const params = new URLSearchParams(window.location.search)
    if(params.has('recp_id')){
        $("#overlay").fadeIn(300);
        var rec_id = params.get('recp_id');
        var ret = params.get('retail');
        var p_value = params.get('product_value');
        $('#recipient').val(rec_id);
        $('#retailer').removeClass('disabled');
        // $('#voucher_price').removeClass('disabled');
        $(".retailer").prop("disabled", false );
        $("#retailer").removeAttr("data-toggle", "tooltip");
        $("#retailer").removeAttr("data-placement", "top");
        // $("#retailer").removeAttr("title", "Delete");
        $("#retailer-tooltip").removeAttr("data-original-title", "Select Recipient First");
        // $("#value-tooltip").removeAttr("data-original-title", "Select Retailer First.");
        $("#voucher_price").prop("disabled", false );
        // $('.retailer').val(ret);
        // $('.quantity_area').css('display','block');
        // $(".addcart_btn").prop('disabled', false);
        // $.ajax({
        //     type: "POST",
        //     url: frontEndAjax.ajaxurl,
        //     data: {action: "pricelist",nonce_ajax : frontEndAjax.nonce,voucher:ret},
        //     //dataType : "json",
        //     }).done(
        //         function(data){
        //             setTimeout(function(){
        //                 $("#overlay").fadeOut(300);
        //               });
        //               $('#retailer').removeClass('disabled');
        //               $('#voucher_price').removeClass('disabled');
        //             var price_value ='';
        //             if(data == '0') {
        //                 $('#retialer_error').css('display','block');
        //                 $("select.voucher_price").find('option').remove();
        //                 $("select.voucher_price").html('<option value="0">Please Select Value</option>');
        //             } else {
        //                 $('#retialer_error').css('display','none');
        //                  price_value += data;
        //                 $("select.voucher_price").append(price_value);
        //             }
        //             // $('#voucher_price').val(p_value);
        //         });
                // alert(p_value);
                // $('#voucher_price').val(p_value);
        jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "filter_personalize",nonce_ajax : frontEndAjax.nonce,rec_id:rec_id},
        dataType : "json",
        }).done(
        function(data){    
            setTimeout(function(){
                $("#overlay").fadeOut(300);
              });
            $('#retailer').removeClass('disabled');
            $('#voucher_price').removeClass('disabled');        
            var data1 = JSON.stringify(data[0].personalize);
            var sms = JSON.parse(data1);
            console.log(sms);
            if(sms == "Yes") { 
                $("#active_no").attr('checked', false);
                $("#active_yes").attr('checked', true);  
            }
            if(sms == "No") { 
                $("#active_yes").attr('checked', false);
                $("#active_no").attr('checked', true);  
            }
        });
    }
});

var recept_table = $('.tbl_yes').DataTable({
    columnDefs: [
        { orderable: false, targets: [1,2,3] }
     ]
});

// Recipient filter by active status
$(".status_filter").change(function(){
    var filter_value = $(".status_filter").children("option:selected").val();
    if(filter_value == "No"){
        $('#active_status_content_yes').hide();
        $('#active_status_content_no').show(); 
        var recept_table_no = $('.tbl_no').DataTable({
            columnDefs: [
                { orderable: false, targets: [1,2,3] }
             ],
             responsive: true
        });
        $('.tbl_yes').dataTable().fnDestroy();
    }
    if(filter_value == "Yes"){
        $('#active_status_content_no').hide();
        $('#active_status_content_yes').show();
        var recept_table = $('.tbl_yes').DataTable({
            destroy: true,
            responsive: true,
            columnDefs: [
                { orderable: false, targets: [1,2,3] }
             ]
        });
        $('.tbl_no').dataTable().fnDestroy();
    }
});
// Recipient filter by active status

// $(document).ready(function () {
//     function readCookie(name) {
//         var nameEQ = name + "=";
//         var ca = document.cookie.split(';');
//         for(var i=0;i < ca.length;i++) {
//             var c = ca[i];
//             console.log(c);
            
//             // while (c.charAt(0)==' ') c = alert(c.substring(1,c.length));
//             // if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
//         }
//         return null;
//     }
//     // readCookie();
//     // console.log(getCookie('store_id'));
//     if(getCookie('store_id')){
//         $('#recipient').val(getCookie('store_id'));
//         }
//   });

//   function setCookie(name,value,days) {
//     var expires = "";
//     if (days) {
//         var date = new Date();
//         date.setTime(date.getTime() + (days*24*60*60*1000));
//         expires = "; expires=" + date.toUTCString();
//     }
//     document.cookie = name + "=" + (value || "")  + expires + "; path=/";
// }
// function getCookie(name) {
//     var nameEQ = name + "=";
//     var ca = document.cookie.split(';');
//     for(var i=0;i < ca.length;i++) {
//         var c = ca[i];
//         while (c.charAt(0)==' ') c = c.substring(1,c.length);
//         if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
//     }
//     return null;
// }
// function eraseCookie(name) {   
//     document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
// }

function lastConfirm() {
   
    var r = confirm("Are you sure?");

    if( r == true){
       return true;
    } else {
       return false;
    }
  }

  $(document).ready(function(){

    var quantitiy=0;
       $('.quantity-right-plus').click(function(e){
            // Stop acting like a button
            e.preventDefault();
            var quantity = parseInt($('#quantity').val());
                $('#quantity').val(quantity + 1);
            var voucher_price = $('#voucher_price').find(':selected').attr('data-count');
            // $("#pluscount-max-limit").removeAttr("data-original-title", "Maximum stock available count "+voucher_price);
            $('#quantity').val(quantity + 1);
            if(parseInt(quantity)>=parseInt(voucher_price)){
                var quantity = parseInt($('#quantity').val());
                // $('#quantity').val(voucher_price);
                // $("#pluscount-max-limit").attr("data-original-title", "Maximum stock available count "+voucher_price);
                swal("There are only " + voucher_price + " vouchers available.");
                $('#quantity').val(voucher_price);
            }
                
        });
    
         $('.quantity-left-minus').click(function(e){
            // Stop acting like a button
            e.preventDefault();
            var quantity = parseInt($('#quantity').val()) - 1;
            if(parseInt(quantity)<=parseInt(0)){
                $('#quantity').val(1);
            }else{
                $('#quantity').val(quantity);
            }
           
        });
        
    });



    $(document).ready(function(){
        // $("input[type=radio][name='verification_by[]']").change(function() {
            $('.um-register #um-submit-btn').addClass("reg_otp_btn");

        $("#otp_submit").click(function(){
            var otp = $('.otp_check').val();
            var mob_num = $("#mobile_number-14").val();
            // alert(otp);
            $("#overlay").fadeIn(300);
            jQuery.ajax({
                type: "POST",
                url: frontEndAjax.ajaxurl,
                data: {action: "verifyotp",nonce_ajax : frontEndAjax.nonce,mob_num:mob_num,otp:otp},
                dataType : "json",
                }).done(
                function(data){
                    console.log(data);
                    setTimeout(function(){
                        $("#overlay").fadeOut(300);
                      });
                    if(data.msg == "Verified"){
                        swal("Phone Number Verified");
                        $('#otp_value_sms-14').val(1);
                        $(".reg_otp_btn").trigger("click");
                        
                        // window.location.reload();
                    }else if(data.msg == "Incorrect OTP"){
                        swal("Incorrect OTP");
                        $('#otp_sms_modal').modal('show');
                    }
                });
        });

        $("#otp_submit_email").click(function(){
            var otp = $('.otp_check_email').val();
            // var mob_num = $("#mobile_number-14").val();
            var email = $("#user_email-14").val();
            // alert(otp);
            $("#overlay").fadeIn(300);
            jQuery.ajax({
                type: "POST",
                url: frontEndAjax.ajaxurl,
                data: {action: "email_verifyotp",nonce_ajax : frontEndAjax.nonce,email:email,otp:otp},
                dataType : "json",
                }).done(
                function(data){
                    console.log(data);
                    setTimeout(function(){
                        $("#overlay").fadeOut(300);
                      });
                    if(data.msg == "Verified"){
                        swal("Email Verified");
                        $('#otp_value_sms-14').val(1);
                        $(".reg_otp_btn").trigger("click");
                        // window.location.reload();
                    }else if(data.msg == "Incorrect OTP"){
                        swal("Incorrect OTP");
                        $('#otp_email_modal').modal('show');
                    }
                });
        });

});


function retailer_management(termid){
    window.open("/voucher/wp-admin/term.php?taxonomy=retailer&tag_ID="+termid+"tag_id&post_type=product&wp_http_referer=%2Fvoucher%2Fwp-admin%2Fedit-tags.php%3Ftaxonomy%3Dretailer%26post_type%3Dproduct", "_blank");
}

function add_retailer(){
    window.open("/voucher/wp-admin/edit-tags.php?taxonomy=retailer&post_type=product", "_blank");
}


$('table tr td').css('background-color','#fff')

$(".logout_no").click(function(){
    jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "cart_logout_no",nonce_ajax : frontEndAjax.nonce},
        dataType : "json",
        }).done(
        function(data){          
            // console.log(data);
            // window.location.reload();
        });
});

$(".logout_yes").click(function(){
    $("#overlay").fadeIn(300);
    $("#place_order").trigger("click");
    sessionStorage.clear();
    // sessionStorage.setItem('cart_logout_val' , 'cart_logout_yes');
    // sessionStorage.removeItem('cart_logout_val');
    // $(".logout_btn").trigger("click");
    jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "cart_logout_yes",nonce_ajax : frontEndAjax.nonce},
        dataType : "json",
        }).done(
        function(data){          
            // console.log(data);
            // window.location.reload();
        });
});

// alert( sessionStorage.getItem('cart_logout_val') );
var ses_cart_val = sessionStorage.getItem('cart_logout_val');

$(document).ready(function(){

    $('.reg_otp_btn').click(function(){
        if($("#otp_value_sms-14").val() == 0){

            $(".first_name-14-error").css('display', 'none');
            $(".last_name-14-error").css('display', 'none');
            $(".mobile_number-14-error").css('display', 'none');
            $(".mobile_number-14-error1").css('display', 'none');
            $(".mail-14-error").css('display', 'none');
            $(".mail-14-error1").css('display', 'none');
            $(".mail-14-error2").css('display', 'none');
            $('.user_password-14-error').css('display','none');
            $('.user_password-14-error1').css('display','none');
            $('.user_confirm_password-14-error').css('display','none');
            $('.user_confirm_password-14-error1').css('display','none');
            $('.user_verify-14-error').css('display','none');
            $('.user_terms-14-error').css('display','none');


            if($("#first_name-14").val() == ''){ 
                $('<div class="first_name-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>First Name is required</div>').insertAfter('.um-field-first_name .um-field-area'); 
                // return false;
            } else { 
                $('.first_name-14-error').css('display','none');
                var field_fname ='valid';
            }
            
            if($("#last_name-14").val() == ''){ 
                $('<div class="last_name-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Last Name is required</div>').insertAfter('.um-field-last_name .um-field-area'); 
                // return false;
            } else { 
                $('.last_name-14-error').css('display','none');
                var field_lname ='valid';
            }

            if($("#mobile_number-14").val() == ''){ 
                $('<div class="mobile_number-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Mobile Number is required</div>').insertAfter('.um-field-mobile_number .um-field-area'); 
                // return false;
            } else if(($("#mobile_number-14").val()).length < 9){
                $('<div class="mobile_number-14-error1"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Mobile Number is not valid</div>').insertAfter('.um-field-mobile_number .um-field-area');
                // return false;
            } else { 
                $('.mobile_number-14-error').css('display','none');
                var field_mobnum ='valid';
            }

            if($('#user_email-14').val() == ''){
                $('<div class="mail-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>E-mail Address is required</div>').insertAfter('.um-field-user_email .um-field-area');
                // return false;
            }else if (!isValidEmailAddress($("#user_email-14").val())) {
                $('<div class="mail-14-error1"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Please enter a valid email address</div>').insertAfter('.um-field-user_email .um-field-area');
                // return false;
            } else{
                var email_val = "valid";
                $(".mail-14-error1").css('display', 'none');
                 console.log("Valid");
                
            }


            var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[~`!@#$%\^&*()\-_=+[\]{};:\x27.,\x22\\|/?><]).*$/;
            // if($("#user_password-14").val() == ''){ 
            //     $('<div class="user_password-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Password is required</div>').insertAfter('#um_field_14_user_password .um-field-area'); 
            //     // return false;
            // }
            if(pattern.test($("#user_password-14").val())){
                // console.log("Valid");
                var field_pass = "valid";
            }else { 
                $('<div class="user_password-14-error1"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Your password must contain at least least 8 characters, one lowercase letter, one capital letter, one special character and one number</div>').insertAfter('#um_field_14_user_password .um-field-area');
                // return false;
            }

            if($("#user_password-14").val() != ''){
                if($("#confirm_user_password-14").val() == ''){
                    $('<div class="user_confirm_password-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Please confirm your password</div>').insertAfter('#um_field_14_confirm_user_password .um-field-area');
                    // return false;
                }else if($("#confirm_user_password-14").val() != $("#user_password-14").val()){
                    $('<div class="user_confirm_password-14-error1"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Your passwords do not match</div>').insertAfter('#um_field_14_confirm_user_password .um-field-area');
                    // return false;
                }
                else{
                    $('.user_confirm_password-14-error1').css('display','none');
                    var field_confpass = "valid";
                }
            }

            if ($('input[name="verification_by[]"]:checked').length == 0) {
                $('<div class="user_verify-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Verification Method is required</div>').insertAfter('#um_field_14_verification_by .um-field-area');
                // return false;
            }

            if(!$('input[name="terms-conditions[]').is(":checked")){
                $('<div class="user_terms-14-error"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Terms and Condition is required</div>').insertAfter('#um_field_14_terms-conditions .um-field-area');
                // return false;
            }else{
                $('.user_terms-14-error').css('display','none');
                    var field_terms = "valid";
            }
            // alert(email_val);
            if((field_fname == "valid") && (field_lname == "valid") && (field_mobnum == "valid") && (field_pass == "valid") && (field_confpass == "valid") && (field_terms == "valid")){
                if(email_val == "valid"){
                    // $('#email_valid-14').val(0);
                    $("#overlay").fadeIn(300);
                        jQuery.ajax({
                        type: "POST",
                        url: frontEndAjax.ajaxurl,
                        data: {action: "check_email",nonce_ajax : frontEndAjax.nonce,email:$('#user_email-14').val(),motp:"no"},
                        dataType : "json",
                        }).done(
                        function(data){
                            console.log(data);
                            setTimeout(function(){
                                $("#overlay").fadeOut(300);
                            });
                            if( data.msg == "Number Already Verified"){
                                $(".mail-14-error2").css('display', 'none');
                                $('<div class="mail-14-error2"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>This email is already linked to an existing account</div>').insertAfter('.um-field-user_email .um-field-area');
                                $('#email_valid-14').val(0);
                                // alert($('#email_valid-14').val());
                                return false;
                            }else{
                                // var email_valid = "valid";
                                $(".mail-14-error2").css('display', 'none');
                                $('#email_valid-14').val(1);
                                $("#overlay").fadeIn(300);
                                jQuery.ajax({
                                type: "POST",
                                url: frontEndAjax.ajaxurl,
                                data: {action: "voucherotp",nonce_ajax : frontEndAjax.nonce,email:$('#user_email-14').val(),motp:"no"},
                                dataType : "json",
                                }).done(
                                function(data){
                                    console.log(data);
                                    setTimeout(function(){
                                        $("#overlay").fadeOut(300);
                                    });
                                    if( data.msg == "Number Already Verified"){
                                        $(".mail-14-error2").css('display', 'none');
                                        $('<div class="mail-14-error2"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>This email is already linked to an existing account</div>').insertAfter('.um-field-user_email .um-field-area');
                                        return false;
                                        // $('#otp_value_sms-14').val(1);
                                        // $(".reg_otp_btn").trigger("click");
                                    }else if(data.msg == "OTP Sent"){
                                        $('#otp_email_modal').modal('show');
                                    }else if( data.msg == "Please Check Number" ){
                                        swal("Please Check Email");
                                    }
                                });
                            }
                        });
                }
            }
            // alert($('#email_valid-14').val());
            // if(($('#email_valid-14').val() == 1) && (email_valid == "valid")){
                // if((field_fname == "valid") && (field_lname == "valid") && (field_mobnum == "valid") && (field_pass == "valid") && (field_confpass == "valid") && (field_terms == "valid")){
                    // $(".reg_otp_btn").trigger("click");
                    // alert($('#email_valid-14').val());
                    // alert(email_valid);
                // if(($("#otp_value_sms-14").val() == 0) && ($('#email_valid-14').val() == 1)){
                    // console.log("sd");
                    var otp_type = $('input[name="verification_by[]"]:checked').val();
                    if(otp_type == "SMS"){
                        $("#overlay").fadeIn(300);
                        jQuery.ajax({
                        type: "POST",
                        url: frontEndAjax.ajaxurl,
                        data: {action: "voucherotp",nonce_ajax : frontEndAjax.nonce,mob_num:$("#mobile_number-14").val(),motp:"yes"},
                        dataType : "json",
                        }).done(
                        function(data){
                            // console.log(data);
                            // alert(data.msg);
                            setTimeout(function(){
                                $("#overlay").fadeOut(300);
                            });
                            if( data.msg == "Number Already Verified"){
                                swal("Number Already Verified");
                                $('#otp_value_sms-14').val(1);
                                $(".reg_otp_btn").trigger("click");
                            }else if(data.msg == "OTP Sent"){
                                $('#otp_sms_modal').modal('show');
                            }else if( data.msg == "Please Check Number" ){
                                $(".mob-14-error2").css('display', 'none');
                                $('<div class="mobile_number-14-error1"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>Please Check Number</div>').insertAfter('.um-field-mobile_number .um-field-area');
                            }
                        });
                    }
                
                    if((otp_type == "Email") && ($('#email_valid-14').val() == 1)){
                        // $("#overlay").fadeIn(300);
                        // jQuery.ajax({
                        // type: "POST",
                        // url: frontEndAjax.ajaxurl,
                        // data: {action: "voucherotp",nonce_ajax : frontEndAjax.nonce,email:$('#user_email-14').val(),motp:"no"},
                        // dataType : "json",
                        // }).done(
                        // function(data){
                        //     console.log(data);
                        //     setTimeout(function(){
                        //         $("#overlay").fadeOut(300);
                        //     });
                        //     if( data.msg == "Number Already Verified"){
                        //         $(".mail-14-error2").css('display', 'none');
                        //         $('<div class="mail-14-error2"><span class="um-field-arrow"><i class="um-faicon-caret-up"></i></span>This email is already linked to an existing account</div>').insertAfter('.um-field-user_email .um-field-area');
                        //         return false;
                        //         // $('#otp_value_sms-14').val(1);
                        //         // $(".reg_otp_btn").trigger("click");
                        //     }else if(data.msg == "OTP Sent"){
                        //         $('#otp_email_modal').modal('show');
                        //     }else if( data.msg == "Please Check Number" ){
                        //         swal("Please Check Email");
                        //     }
                        // });
                    }
                // }
                return false; 
            // }       
            // return false; 
        }
    });
});


$("#mobile_number-14").keypress(function (e){
    var charCode = (e.which) ? e.which : e.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
  });

  function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return pattern.test(emailAddress);
};
  //email validation
  if (!isValidEmailAddress($("#email").val())) {
    // errorMessage = errorMessage + "<br />Please enter a valid email address";
  }

  $(".extra_column tr:nth-child(2)").insertAfter("tbody tr:nth-child(4)");
  $(".extra_column_vat tr:nth-child(3)").insertAfter("tbody tr:nth-child(4)");




$(document).ready(function(){
    $(".remove_order").click(function(){
    // alert("SDFSF");
    $.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "removeorder",nonce_ajax : frontEndAjax.nonce},
        //dataType : "json",
    }).done(
        // console.log($order_id);
    )
    });
});