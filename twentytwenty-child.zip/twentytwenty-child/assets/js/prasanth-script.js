$(document).ready(function(){
    $('.menu-item-has-children').each(function(){
        var id = $(this).attr("id");
        if ($(this).find('.sub-menu').length) {
            var arrow = "<span class='down-arrow'><i class='fa fa-angle-down arrow float-right'></i></span>";
            $('#'+id+' .sub-menu').siblings('a').append(arrow);
            $('#'+id+' .sub-menu  .arrow').remove();
            $('#'+id+' .sub-menu').siblings('a').attr("data-target",  "#"+id+" .sub-menu");
            $('#'+id+' .sub-menu').siblings('a').attr("data-toggle", "collapse");
            $('#'+id+' .sub-menu').addClass('collapse');
            
        }
        
    }) 

    $('.sub-menu .sub-menu').removeClass('collapse'); 
    // $('.sub-menu .sub-menu').addClass('collapse in');   
    

    $('#um_field_14_terms-conditions .um-field-area').attr("data-toggle","modal" );
    $('#um_field_14_terms-conditions .um-field-area').attr("data-target","#exampleModalCenter");

    $('#um_field_14_terms-conditions label').click(function(){
        $('#um_field_14_terms-conditions i').removeClass('um-icon-android-checkbox-outline');
        $('#um_field_14_terms-conditions i').addClass('um-icon-android-checkbox-outline-blank');
        return false;
    })

    $('#tc-accept').click(function(){
        $('#um_field_14_terms-conditions i').removeClass('um-icon-android-checkbox-outline-blank');
        $('#um_field_14_terms-conditions i').addClass('um-icon-android-checkbox-outline');
        $('#um_field_14_terms-conditions .um-field-checkbox').addClass('active');
        $('#um_field_14_terms-conditions input').attr("checked","checked");
    
    })
    $('#tc-decline').click(function(){
        $('#um_field_14_terms-conditions i').removeClass('um-icon-android-checkbox-outline');
        $('#um_field_14_terms-conditions i').addClass('um-icon-android-checkbox-outline-blank');
        $('#um_field_14_terms-conditions .um-field-checkbox').removeClass('active');
        $('#um_field_14_terms-conditions input').removeAttr("checked");
    
    })

    //Terms and condition text adding
    var tc_lable = "<span class='tc-lable'><a href='#'>Accept Terms and Conditions.</a> </span>";
    $('#um_field_14_terms-conditions .um-field-area .um-clear').before(tc_lable);

    //register-password eye icon adding
    var password_eye = "<i class='glyphicon glyphicon-eye-open form-control-feedback' onclick='passwordEye()'></i>";
    $('.um-register .um-col-132 .um-field-password .um-field-area #user_password-14').after(password_eye);
    
    var confirm_password_eye = "<i class='glyphicon glyphicon-eye-open form-control-feedback' onclick='confirmPasswordEye()'></i>";
    $('.um-register .um-col-132 .um-field-password .um-field-area #confirm_user_password-14').after(confirm_password_eye);
    

    //checkout page col-2 change to col-12
    $('#customer_details .col-2').addClass('col');
    $('#customer_details .col-2').removeClass('col-2');
    
    
    $('#um_field_14_city_user').addClass('label-top');
    $('#country_user').val('South Africa');
  
    var password = $('#hidden_password').val();
    $('#user_password-14').attr("value",password);
  
    
    $('#som_new_user_pass').parent().attr('id','som_new_password');
    $('#som_new_user_pass_again').parent().attr('id','som_again_password');
    var back_btn = "<a href='http://202.129.196.139:3444/voucher/my-account/orders/' class='btn right rec_common_btn return_list'>Back</a>";
    $('#back_btn a.btn.pull-right.rec_common_btn.return_list').after(back_btn);
    $(".remove-number .wc-item-meta li:nth-child(2)").remove();
    $(".remove-number .wc-item-meta li:nth-child(2)").remove();
   
    $(".wc-item-meta strong").remove();
    $(".remove-recipient .wc-item-meta li:nth-child(1)").remove();
    $(".remove-recipient .wc-item-meta li:nth-child(2)").remove();

    
    $('#order_review').parent().parent().addClass('white-bg-wrap');
    $('.woocommerce-order.thank-you').parent().addClass('white-bg-wrap');
    $('.woocommerce-order.thank-you').parent().addClass('thankyou-outer');

    //disable the fiest and last class in checkout
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').each(function(){
     
      
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').removeClass(' form-row-first');
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').removeClass(' form-row-last');
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').removeClass(' form-row-wide');
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').addClass(' col-4');
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p').addClass(' float-left');
    })
    
    //disable the fiest and last class in checkout
    $('.woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper p input').each(function(){
      var input_id = $(this).attr('id');
      var error_span = "<span id='"+input_id+"_error' class='checkout-error-optional'>Please enter the Firstname</span>";
    
      if(input_id == 'billing_first_name'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Firstname</span>";
      }
      if(input_id == 'billing_last_name'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Lastname</span>";
      }
      if(input_id == 'billing_address_1'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Street address</span>";
      }
      if(input_id == 'billing_addres'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Street address</span>";
      }
      if(input_id == 'billing_city'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the City</span>";
      }
      if(input_id == 'billing_postcode'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Postcode/ZIP</span>";
      }
      if(input_id == 'billing_phone'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the Phone</span>";
      }
      if(input_id == 'billing_email'){
          var error_span = "<span id='"+input_id+"_error' class='checkout-error'>Please enter the E-mail</span>";
      }
      $(error_span).insertAfter($(this).parent());
      
  })
  $('#bulkordermodal p:nth-child(5) input').datepicker({  
    format: 'yyy-mm-dd'
  });  

  //add cancel button in bulk order model
  
  var cancel_button = "<button type='button' class='btn btn-default rec_common_btn' id='recipient_cancel' style='float:right;' data-dismiss='modal'>Cancel</button>";
  $('#bulkordermodal p:nth-child(6)').append(cancel_button);

  //add cancel button in bulk order model
})

//register-toggle password visibility
function passwordEye() {
    var x = document.getElementById("user_password-14");
    if (x.type === "password") {
      x.type = "text";
      
    $('.um-register .um-col-132 #um_field_14_user_password i').removeClass('glyphicon-eye-open');
    $('.um-register .um-col-132 #um_field_14_user_password i').addClass('glyphicon-eye-close');
    } else {
      x.type = "password";
      
    $('.um-register .um-col-132 #um_field_14_user_password i').removeClass('glyphicon-eye-close');
    $('.um-register .um-col-132 #um_field_14_user_password i').addClass('glyphicon-eye-open');
    }
}
function confirmPasswordEye() {
      var x = document.getElementById("confirm_user_password-14");
      if (x.type === "password") {
        x.type = "text";
        
      $('.um-register .um-col-132 #um_field_14_confirm_user_password i').removeClass('glyphicon-eye-open');
      $('.um-register .um-col-132 #um_field_14_confirm_user_password i').addClass('glyphicon-eye-close');
      } else {
        x.type = "password";
        
      $('.um-register .um-col-132 #um_field_14_confirm_user_password i').removeClass('glyphicon-eye-close');
      $('.um-register .um-col-132 #um_field_14_confirm_user_password i').addClass('glyphicon-eye-open');
      }

      


}


//reset-toggle password visibility
function resetPasswordEye() {
  var x = document.getElementById("som_new_user_pass");
  if (x.type === "password") {
    x.type = "text";
    
  $('#som_new_password .icon .glyphicon').removeClass('glyphicon-eye-open');
  $('#som_new_password .icon .glyphicon').addClass('glyphicon-eye-close');
  } else {
    x.type = "password";
    
  $('#som_new_password .icon .glyphicon').removeClass('glyphicon-eye-close');
  $('#som_new_password .icon .glyphicon').addClass('glyphicon-eye-open');
  }
}
function resetConfirmPasswordEye() {
    var x = document.getElementById("som_new_user_pass_again");
    if (x.type === "password") {
      x.type = "text";
      
    $('#som_again_password .icon .glyphicon').removeClass('glyphicon-eye-open');
    $('#som_again_password .icon .glyphicon').addClass('glyphicon-eye-close');
    } else {
      x.type = "password";
      
    $('#som_again_password .icon .glyphicon').removeClass('glyphicon-eye-close');
    $('#som_again_password .icon .glyphicon').addClass('glyphicon-eye-open');
    }
}

//only number function mob_num rec_common_input
var input = document.querySelector('#mob_num');
if(input){
    input.addEventListener('keyup', function (event) {
      if (event.which != 8 && event.which != 0 && event.which < 48 || event.which > 57) {
        this.value = this.value.replace(/\D/g, "");
      }
    });
  }
    
// var input = document.querySelector('.mob_num.rec_common_input');
if(input){
input.addEventListener('keyup', function (event) {
  if (event.which != 8 && event.which != 0 && event.which < 48 || event.which > 57) {
    this.value = this.value.replace(/\D/g, "");
  }
});
}
function isNumberKey(evt){
//  var sel = 
  var input = document.querySelector('#recipient_num_'+evt);
  // alert(sel);
if(input){
  input.addEventListener('keyup', function (event) {
    if (event.which != 8 && event.which != 0 && event.which < 48 || event.which > 57) {
      this.value = this.value.replace(/\D/g, "");
    }
  });
  }
}
// $('input[name=myInput]').change(function() { });

//save service fee starts
$(document).ready(function(){
  $("#service_fee_save").click(function(){
      var retailer = $("#retailer").val();
      var service_fee = $("#service_fee").val();
      var value_from = $("#value_from").val();
      var value_to = $("#value_to").val();
      var start =  (parseInt(value_from));
      var end = (parseInt(value_to));
      var numbers = /^[+-]?([0-9]*[.])?[0-9]+$/;

      if( (retailer != 0) && (service_fee != '')  && (value_from.match(numbers))   && (service_fee.match(numbers))){
        if(((start < end) && (value_to.match(numbers))) || value_to == ""  ){
        $("#value_to_number_less_error").css('display','none');
        $("#service_fee_number_error").css('display','none');
        $("#service_fee_error").css('display','none');
        $("#value_from_number_error").css('display','none');
        $("#value_to_number_error").css('display','none');
      
        jQuery.ajax({
          type: "POST",
          url: frontEndAjax.ajaxurl,
          data: {action: "value_exist_validate",nonce_ajax : frontEndAjax.nonce,retailer_id:retailer},
          dataType : "json",
          }).done(
          function(data){  
            var q=0;
            var p=0;
            var r=0;
            var s=0;
            var t=0;
            for (let i = 0; i < data.length; i++) {
              var value_from_exist = JSON.stringify(data[i].feevalue_from);
              var value_to_exist = JSON.stringify(data[i].feevalue_to);
              var feevalue_from = JSON.parse(value_from_exist);
              var feevalue_to = JSON.parse(value_to_exist);
              if(start >= feevalue_from && start <= feevalue_to  )
              {
                p++;
              }
              if(end >= feevalue_from && end <= feevalue_to  )
              {
                q++;
              }
              if(value_to == ''){
                if(feevalue_to == ''){
                 r++; 
                }
              }
              if(feevalue_to == ''){
                if(start >= feevalue_from ){
                  s++; console.log(feevalue_from,s)
                }
                if( end >= feevalue_from ){
                  t++; console.log(feevalue_from,feevalue_to,t)
                }
              }
               
            }
            if(p > 0 || q > 0 || r > 0 || s > 0 || t > 0){
              if(p > 0 || s > 0){
                $("#value_from_exist_error").css('display','block');
              }
              else{
                $("#value_from_exist_error").css('display','none');
              }
              if(q > 0 || r > 0 || t > 0){
                $("#value_to_exist_error").css('display','block');
              }else{
                $("#value_to_exist_error").css('display','none');
              }
            }else{
              $("#value_from_exist_error").css('display','none');
              $("#value_to_exist_error").css('display','none');
              $("#overlay").fadeIn(300);
              jQuery.ajax({
                  type: "POST",
                  url: frontEndAjax.ajaxurl,
                  data: {action: "save_service_fee",nonce_ajax : frontEndAjax.nonce,
                  retailer:retailer,service_fee:service_fee,value_from:value_from,value_to:value_to},
                  dataType : "json",
                  }).done(
                  function(data){        
                    setTimeout(function(){
                    $("#overlay").fadeOut(300);
                  });      
                      Swal.fire("Service Fee Added");
                      console.log(data);
                      window.location.reload();
                });
            }
          });
        }
        else
        { 
          if(value_to != ''){  
            if(value_to.match(numbers))
            {
              $("#value_to_number_error").css('display','none');
  
            }
            else
            {
              $("#value_to_number_error").css('display','block');
            }
          }
          else
          {          
            $("#value_to_number_error").css('display','none');
          }
          if(start > end){
            if(end == ''){
              $("#value_to_number_less_error").css('display','none');
            }
            else
            {     
              $("#value_to_number_less_error").css('display','block');
            }
          }
          else{
            $("#value_to_number_less_error").css('display','none');
          }
        }
      }
      else
      {
        
        if(retailer == 0 ){
        
          $("#retailer_error").css('display','block');
        }
        else
        {
          $("#retailer_error").css('display','none');
        }
        if(service_fee == ''){
          $("#service_fee_error").css('display','block');
        }
        else
        {
          $("#service_fee_error").css('display','none');
          
          if(service_fee.match(numbers))
          {
            $("#service_fee_number_error").css('display','none');
          }
          else
          {
            $("#service_fee_number_error").css('display','block');
          }


        }
        
        if(value_from.match(numbers))
        {
          $("#value_from_number_error").css('display','none');
        }
        else
        {
          $("#value_from_number_error").css('display','block');
        }

        if(value_to != ''){  
          if(value_to.match(numbers))
          {
            $("#value_to_number_error").css('display','none');

          }
          else
          {
            $("#value_to_number_error").css('display','block');
          }
        }
        else
        {          
          $("#value_to_number_error").css('display','none');
        }
        if(start > end){
          if(end == ''){
            $("#value_to_number_less_error").css('display','none');
          }
          else
          {     
            $("#value_to_number_less_error").css('display','block');
          }
        }
        else{
          $("#value_to_number_less_error").css('display','none');
        }

      }
    });
});
//save service fee ends

//update Service fees starts
function updateServiceModal(id){

  var retailer = $("#retailer_"+id).val();
  var service_fee = $("#service_fee_"+id).val();
  var value_from = $("#value_from_"+id).val();
  var value_to = $("#value_to_"+id).val();
  var numbers = /^[+-]?([0-9]*[.])?[0-9]+$/;
  var start =  (parseInt(value_from));
  var end = (parseInt(value_to));
  
  

  if((service_fee != '')  && (value_from.match(numbers))  && (service_fee.match(numbers))){
    if(((start < end) && (value_to.match(numbers))) || value_to == ""  ){
    $("#value_to_number_less_error_"+id).css('display','none');
    $("#service_fee_number_error_"+id).css('display','none');
    $("#service_fee_error_"+id).css('display','none');
    $("#value_from_number_error_"+id).css('display','none');
    $("#value_to_number_error_"+id).css('display','none');

    jQuery.ajax({
      type: "POST",
      url: frontEndAjax.ajaxurl,
      data: {action: "update_value_exist_validate",nonce_ajax : frontEndAjax.nonce,retailer_id:retailer,id:id},
      dataType : "json",
      }).done(
      function(data){  
        var p=0;
        var q=0;
        var r=0;
        var s=0;
        var t=0;
        for (let i = 0; i < data.length; i++) {
          var value_from_exist = JSON.stringify(data[i].feevalue_from);
          var value_to_exist = JSON.stringify(data[i].feevalue_to);
          var feevalue_from = JSON.parse(value_from_exist);
          var feevalue_to = JSON.parse(value_to_exist);
          if(start >= feevalue_from && start <= feevalue_to  )
          {
            p++;
          }
          if(end >= feevalue_from && end <= feevalue_to  )
          {
            q++;
          }
          if(value_to == ''){
             if(feevalue_to == ''){
              r++; 
             }
          }
          if(feevalue_to == ''){
            if(start >= feevalue_from ){
              s++; console.log(feevalue_from,s)
            }
            if( end >= feevalue_from ){
              t++; console.log(feevalue_from,feevalue_to,t)
            }
          }
           
        }
        if(p > 0 || q > 0 || r > 0 || s > 0 || t > 0){
          if(p > 0 || s > 0 ){
            $("#value_from_exist_error_"+id).css('display','block');
          }
          else{
            $("#value_from_exist_error_"+id).css('display','none');
          }
          if(q > 0 || r > 0 || t > 0 ){
            $("#value_to_exist_error_"+id).css('display','block');
          }else{
            $("#value_to_exist_error_"+id).css('display','none');
          }
        }else{
          $("#value_from_exist_error_"+id).css('display','none');
          $("#value_to_exist_error_"+id).css('display','none');
          $("#overlay").fadeIn(300);
          jQuery.ajax({
          type: "POST",
          url: frontEndAjax.ajaxurl,
          data: {action: "update_service_details",nonce_ajax : frontEndAjax.nonce,
          id:id,service_fee:service_fee,value_from:value_from,value_to:value_to,retailer:retailer},
          dataType : "json",
          }).done(
          function(data){         
              setTimeout(function(){
            $("#overlay").fadeOut(300);
          });    
              Swal.fire("Service Fee Updated");
              console.log(data);
              window.location.reload();
          });
        }
      });

    
    }
    else
    {
      if(start > end){
        if(end == ''){
          $("#value_to_number_less_error_"+id).css('display','none');
        }
        else
        {     
          $("#value_to_number_less_error_"+id).css('display','block');
        }
      }
      else{
        $("#value_to_number_less_error_"+id).css('display','none');
      }
      if(value_to != ''){  
        if(value_to.match(numbers))
        {
          $("#value_to_number_error_"+id).css('display','none');
        }
        else
        {
          $("#value_to_number_error_"+id).css('display','block');
        }
      }
    }

  }
  else
  {


    if(start > end){
      if(end == ''){
        $("#value_to_number_less_error_"+id).css('display','none');
      }
      else
      {     
        $("#value_to_number_less_error_"+id).css('display','block');
      }
    }
    else{
      $("#value_to_number_less_error_"+id).css('display','none');
    }
 
   if(service_fee == '') {
      $("#service_fee_error_"+id).css('display','block');
      $("#service_fee_number_error_"+id).css('display','none');
    }
    else
    {
      $("#service_fee_error_"+id).css('display','none');

      if(service_fee.match(numbers))
      {
        $("#service_fee_number_error_"+id).css('display','none');
      }
      else
      {
        $("#service_fee_number_error_"+id).css('display','block');
      }
    }
    if(value_from.match(numbers))
    {
      $("#value_from_number_error_"+id).css('display','none');
    }
    else
    {
      $("#value_from_number_error_"+id).css('display','block');
    }

    if(value_to != ''){  
      if(value_to.match(numbers))
      {
        $("#value_to_number_error_"+id).css('display','none');

       
      }
      else
      {
        $("#value_to_number_error_"+id).css('display','block');
      }
    }
        
  }
 }
//update Service fees ends

//duplicate Service fees starts
function duplicateServiceModal(id){

    var retailer = $("#duplicate_retailer_"+id).val();
    var service_fee = $("#duplicate_service_fee_"+id).val();
    var value_from = $("#duplicate_value_from_"+id).val();
    var value_to = $("#duplicate_value_to_"+id).val();
    var numbers = /^[+-]?([0-9]*[.])?[0-9]+$/;
    var start =  (parseInt(value_from));
    var end = (parseInt(value_to));
    
    
  
    if((service_fee != '')  && (value_from.match(numbers))  && (service_fee.match(numbers))){
      if(((start < end) && (value_to.match(numbers))) || value_to == ""  ){
      $("#duplicate_value_to_number_less_error_"+id).css('display','none');
      $("#duplicate_service_fee_number_error_"+id).css('display','none');
      $("#duplicate_service_fee_error_"+id).css('display','none');
      $("#duplicate_value_from_number_error_"+id).css('display','none');
      $("#duplicate_value_to_number_error_"+id).css('display','none');
  
      jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "duplicate_value_exist_validate",nonce_ajax : frontEndAjax.nonce,retailer_id:retailer},
        dataType : "json",
        }).done(
        function(data){  
          var q=0;
          var p=0;
          var r=0;
          var s=0;
          var t=0;
          for (let i = 0; i < data.length; i++) {
            var value_from_exist = JSON.stringify(data[i].feevalue_from);
            var value_to_exist = JSON.stringify(data[i].feevalue_to);
            var feevalue_from = JSON.parse(value_from_exist);
            var feevalue_to = JSON.parse(value_to_exist);
            if(start >= feevalue_from && start <= feevalue_to  )
            {
              p++;
            }
            if(end >= feevalue_from && end <= feevalue_to  )
            {
              q++;
            }
            if(value_to == ''){
              if(feevalue_to == ''){
               r++; 
              }
            }
            if(feevalue_to == ''){
              if(start >= feevalue_from ){
                s++; console.log(feevalue_from,s)
              }
              if( end >= feevalue_from ){
                t++; console.log(feevalue_from,feevalue_to,t)
              }
            }
          }
          if(p > 0 || q > 0 || r > 0 || s > 0 || t > 0){
            if(p > 0 || s > 0){
              $("#duplicate_value_from_exist_error_"+id).css('display','block');
            }
            else{
              $("#duplicate_value_from_exist_error_"+id).css('display','none');
            }
            if(q > 0 || r > 0 || t > 0){
              $("#duplicate_value_to_exist_error_"+id).css('display','block');
            }else{
              $("#duplicate_value_to_exist_error_"+id).css('display','none');
            }
          }else{
            $("#duplicate_value_from_exist_error_"+id).css('display','none');
            $("#duplicate_value_to_exist_error_"+id).css('display','none');
            $("#overlay").fadeIn(300);
            jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "duplicate_service_details",nonce_ajax : frontEndAjax.nonce,
            id:id,service_fee:service_fee,value_from:value_from,value_to:value_to,retailer:retailer},
            dataType : "json",
            }).done(
            function(data){         
                setTimeout(function(){
              $("#overlay").fadeOut(300);
            });    
                Swal.fire("Service Fee Duplicated");
                console.log(data);
                window.location.reload();
            });
          }
        });
  
      
      }
      else
      {
        if(start > end){
          if(end == ''){
            $("#duplicate_value_to_number_less_error_"+id).css('display','none');
          }
          else
          {     
            $("#duplicate_value_to_number_less_error_"+id).css('display','block');
          }
        }
        else{
          $("#duplicate_value_to_number_less_error_"+id).css('display','none');
        }
        if(value_to != ''){  
          if(value_to.match(numbers))
          {
            $("#duplicate_value_to_number_error_"+id).css('display','none');
          }
          else
          {
            $("#duplicate_value_to_number_error_"+id).css('display','block');
          }
        }
      }
  
    }
    else
    {
  
  
      if(start > end){
        if(end == ''){
          $("#duplicate_value_to_number_less_error_"+id).css('display','none');
        }
        else
        {     
          $("#duplicate_value_to_number_less_error_"+id).css('display','block');
        }
      }
      else{
        $("#duplicate_value_to_number_less_error_"+id).css('display','none');
      }
   
     if(service_fee == '') {
        $("#duplicate_service_fee_error_"+id).css('display','block');
        $("#duplicate_service_fee_number_error_"+id).css('display','none');
      }
      else
      {
        $("#duplicate_service_fee_error_"+id).css('display','none');
  
        if(service_fee.match(numbers))
        {
          $("#duplicate_service_fee_number_error_"+id).css('display','none');
        }
        else
        {
          $("#duplicate_service_fee_number_error_"+id).css('display','block');
        }
      }
      if(value_from.match(numbers))
      {
        $("#duplicate_value_from_number_error_"+id).css('display','none');
      }
      else
      {
        $("#duplicate_value_from_number_error_"+id).css('display','block');
        $("#duplicate_value_from_exist_error_"+id).css('display','none');
      }
  
      if(value_to != ''){  
        if(value_to.match(numbers))
        {
          $("#duplicate_value_to_number_error_"+id).css('display','none');
  
         
        }
        else
        {
          $("#duplicate_value_to_number_error_"+id).css('display','block');
        }
      }
          
    }
 }
//update Service fees ends

function confirmVatDeleteModal(id){
  $('#vatDeleteModal').modal();
$('#vatDeleteButton').html('<a class="btn btn-danger" onclick="VatdeleteData('+id+')">Delete</a>');
}     
function VatdeleteData(id){
  $("#overlay").fadeIn(300);
  jQuery.ajax({
  type: "POST",
  url: frontEndAjax.ajaxurl,
  data: {action: "delete_vat",nonce_ajax : frontEndAjax.nonce,vat_id:id},
  dataType : "json",
  }).done(
  function(data){      
     setTimeout(function(){
    $("#overlay").fadeOut(300);
  });        
      console.log(data);
      window.location.reload();
  });
}  


function confirmserviceDeleteModal(id){
  $('#serviceDeleteModal').modal();
$('#serviceDeleteButton').html('<a class="btn btn-danger" onclick="servicedeleteData('+id+')">Delete</a>');
}     
function servicedeleteData(id){
  $("#overlay").fadeIn(300);
  jQuery.ajax({
  type: "POST",
  url: frontEndAjax.ajaxurl,
  data: {action: "delete_service",nonce_ajax : frontEndAjax.nonce,service_id:id},
  dataType : "json",
  }).done(
  function(data){         
      setTimeout(function(){
    $("#overlay").fadeOut(300);
  });    
      console.log(data);
      window.location.reload();
  });
}  
// $('#country_user').onchange(function(){
//   var country_label = $('#country_user').val();
//   alert(country_label);
// });


//save recipients starts
// $(document).ready(function(){
//   $(".register-screen #um-submit-btn").click(function(){
   
//        var person_name = $("#first_name-14").val();
//        var last_name = $("#last_name-14").val();
//        var person_number = $("#mobile_number-14").val();
//        var password = $("#user_password-14").val();
//        var confirmpassword = $("#confirm_user_password-14").val();
//        var city = $("user_city-14").val();
//        var email = $("#user_email-14").val();
//        var verification = $(".register-screen input:checked").val();
//        var terms = $(".register-screen input[type='checkbox']:checked").val();
//        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
   
       
//        if(person_name != "" && last_name != "" && email.match(re) && person_number != "" && password != "" && confirmpassword != "" && city != "" && email != "" && verification && confirmpassword == password  && terms ){
//         var personalize = "Yes";
//         var active_status = "Yes";
          
//         jQuery.ajax({
//             type: "POST",
//             url: frontEndAjax.ajaxurl,
//             data: {action: "on_register_save_recipient",nonce_ajax : frontEndAjax.nonce,
//             person_name:person_name,person_number:person_number,personalize:personalize,active_status:active_status},
//             dataType : "json",
//             }).done(
//                   function(data){                        
//                   console.log(data);
//                       // window.location.reload();
//                   });

            
//        }
//        else{
//         alert(terms);
//         alert("no");
//         return false;
//       }
//     });
// });
//save recipients ends

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

function orderCancel(order_id){
  
  jQuery.ajax({
    type: "POST",
    url: frontEndAjax.ajaxurl,
    data: {action: "order_cancel",nonce_ajax : frontEndAjax.nonce,
    order_id:order_id},
    dataType : "json",
    }).done(
          function(data){                        
          console.log(data);
               window.location.reload();
          });
}    


// Export Bulk Orders tables
$(document).ready(function() {
  if ( $.fn.dataTable.isDataTable( '#bulk_orders_table' ) ) {
      table = $('#bulk_orders_table').DataTable();
  }
  else {
  var table = $('#bulk_orders_table').DataTable( {
      dom: 'Bfrtip',
      responsive: true,
      columnDefs: [
        { orderable: false, targets: [4] }
      ],
      buttons: [
          {
          extend: 'csv',
          className: 'userReportcsv',
          // titleAttr: 'Click to download report in .csv format',
          //Name the CSV
          filename: 'Bulk_Order_Report',
          text: 'Export CSV',
          exportOptions: {
              columns: [0, 1, $("#contactName"), $("#contactMail"), $("#contactPhn"), $("#deliveryDate")]
          },
          //Function which customize the CSV (input : csv is the object that you can preprocesss)
          customize: function (csv) {
                  //Split the csv to get the rows
                  var split_csv = csv.split("\n");
  
                  //Remove the row one to personnalize the headers
                  split_csv[0] = '"Contact Name","Contact Email","Contact Phone","deliveryDate"';
  
                  //For each row except the first one (header)
                  $.each(split_csv.slice(1), function (index, csv_row) {
                          //Split on quotes and comma to get each cell
                          var csv_cell_array = csv_row.split('","');
  
                  });
  
                  //Join the rows with line breck and return the final csv (datatables will take the returned csv and process it)
                  csv = split_csv.join("\n");
                  return csv;
          }
          },
          {
              text: 'Export PDF',
              extend: 'pdfHtml5',
              orientation: 'landscape',
              // titleAttr: 'Click to download report in .pdf format',
              pageSize: 'LEGAL',
              filename: 'Bulk_Order_Report',
              className: 'userReportcsv pdf_export',
              exportOptions: {
                  modifier: {
                      page: 'all'
                  },
                  columns: [0, 1, $("#contactName"), $("#contactMail"), $("#contactPhn"), $("#deliveryDate")]
              }
          }
      ]
  } );
  }
});

$(document).ready(function() {
  if ( $.fn.dataTable.isDataTable( '#open_orders' ) ) {
      table = $('#open_orders').DataTable();
  }
  else {
      var today = new Date();
      var dd = String(today.getDate()).padStart(2, '0');
      var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
      var yyyy = today.getFullYear();
      
      var d = new Date();
      var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
      var PDF_title = 'Virtual Vouchers - Open Orders Report ('+currentDate+')';

      today = dd + '-' + mm + '-' + yyyy;
      var table = $("#open_orders").DataTable({
      "order": [[ 0, "desc" ]],
      // paging: false,
      dom: "Bfrtip",
      destroy: true,
      columnDefs: [
          { orderable: false, targets: [4] }
       ],
      // searching: false,
      buttons: [
          {
          extend: 'csv',
          className: 'userReportcsv',
          // titleAttr: 'Click to download report in .csv format',
          //Name the CSV
          filename: 'Orders_Report'+today,
          text: 'Export CSV',
          exportOptions: {
            columns: "thead th:not(.noExport)",
            //columns: [0, 1, $("#orderIdcol"), $("#usernameCol"),$("#mobnumCol"), $("#remtimeCol"), $("#ItemsSold"), $("#servicefee"),$("#vat"), $("#amountCol"), $("#orderstatusCol"), $(".CustomerEmail") ],
          },
          //Function which customize the CSV (input : csv is the object that you can preprocesss)
          customize: function (csv) {
                  //Split the csv to get the rows
                  var split_csv = csv.split("\n");
  
                  //Remove the row one to personnalize the headers
                  split_csv[0] = '"Order Id","Username","Mobile Number","Remaining Time","Order Value","No of Items sold","Service Fee","VAT","Order Status","Customer Email"';
  
                  //For each row except the first one (header)
                  $.each(split_csv.slice(1), function (index, csv_row) {
                          //Split on quotes and comma to get each cell
                          var csv_cell_array = csv_row.split('","');
  
                  });
  
                  //Join the rows with line breck and return the final csv (datatables will take the returned csv and process it)
                  csv = split_csv.join("\n");
                  return csv;
          }
          },
          {
              title: PDF_title, 
              text: 'Export PDF',
              extend: 'pdfHtml5',
              orientation: 'landscape',
              // titleAttr: 'Click to download report in .pdf format',
              pageSize: 'LEGAL',
              filename: 'Orders_Report'+today,
              className: 'userReportcsv pdf_export',
              exportOptions: { 
                // columns:[0,1,2,3,6,7,8,9,10,11,12,13,14,15,16,17,18],
                columns: [0, 1, $("#orderIdcol"), $("#usernameCol"),$("#mobnumCol"), $("#remtimeCol"), $("#ItemsSold"), $("#servicefee"),$("#vat"), $("#amountCol"), $("#orderstatusCol"), $(".CustomerEmail") ],
                  modifier: {
                      page: 'all',
                  }
              }
          }]
      });
  }
});