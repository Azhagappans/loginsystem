$(document).ready(function(){
if($(".menu-wrapper ul > li").hasClass("active") ){
    $(".menu-wrapper ul > li.active").find(".panel-collapse").toggleClass("show");
} 
$(".um-form-field").focusin(function(){
    
    $(this).parents(".um-field").addClass("label-top");
});
$(".um-form-field").focusout(function(){
    
    $(this).parents(".um-field").removeClass("label-top");
    
    if($(this).val().length>0)
    {
        $(this).parents(".um-field").addClass('label-top');
    }
    else
    {
        $(this).parents(".um-field").removeClass('label-top');  
    }

})



$(document).on("click",".cod_place_order ",function() {
    
});

$(document).on("click","#tc-accept1 ",function() {
    
    $('#overlay').show();
        $.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "accept_terms_condition",nonce_ajax : frontEndAjax.nonce,voucher:'voucher'},
        }).done(
            function(data){
            $('#overlay').hide(); 
            $('#exampleModalCenter-new').hide();     
        });

});


$(document).on("click","#bulk-order-save ",function() {
    $('#hidden_bulk_order_save').val('saveorder');
    $('#place_order').trigger('click');
});

$("select").focusin(function(){
    $(this).parents(".um-field").addClass("label-top");

})


$("select").focusout(function(){
    $(this).parents(".um-field").removeClass("label-top");
    if($(this).val().length>0)
    {
        $(this).parents(".um-field").addClass('label-top');
    }
    else
    {
        $(this).parents(".um-field").removeClass('label-top');  
    }

})
$(".um-form-field").each(function(){
    if($(this).val()){
    $(this).parents(".um-field").addClass("label-top");
    }
})

function checkForInput(){
if ($(".um-form-field").val().length > 0) {
$(this).parents("um-field").addClass("label-top")
} else {
    $(this).parents("um-field").removeClass('label-top');
}
}

$('.um-form-field').on('change keyup', function() {
checkForInput(this);  
// $(this).parents(".um-field").addClass("label-top");
});

$(document).on("click","#bulk-order-cancel ",function() {
//$('#bulk-order-cancel').on('click', function() {
    $('#overlay').show();
    jQuery.ajax({
        type: "POST",
        url: frontEndAjax.ajaxurl,
        data: {action: "delete_cart_items",nonce_ajax : frontEndAjax.nonce},
        //dataType : "json",
        }).done(
    function(data){        
      window.location.href=home_url+'/bulk-order-import/';
    });
   
})

$('.delete_retailer').click(function() {
    if (confirm('Are you sure?')) {
      var url = $(this).attr('data-deleteurl');
      window.location.href=url;
    }
});

$(".um-form-field").keypress(function(){
  valLength = $(this).val().length ;
    setInterval(function(){
        if(valLength < 1){
            $(this).parents(".um-field").addClass("no-value");
        }
    },1000)
})

});

$('.custom-register-form .um-form-field').removeAttr('placeholder');

$('.um-field-checkbox .um-field-label').remove();

$('.custom-register-form .select2-selection').removeAttr('placeholder');

// Delete recipient details.
$(document).ready(function(){
$('.delete_recipient').each( function() {
    $(this).on('click', function() {
        var recipient_id = $(this).attr("id");
        var delete_alert = confirm('Do you want to delete this recipient?');
        if ( delete_alert == true) {
            $("#overlay").fadeIn(300);
            jQuery.ajax({
                type: "POST",
                url: frontEndAjax.ajaxurl,
                data: {action: "delete_recipient",nonce_ajax : frontEndAjax.nonce,
                recipient_id:recipient_id},
                dataType : "json",
                }).done(
                function(data){        
                    setTimeout(function(){
                        $("#overlay").fadeOut(300);
                      });      
                    console.log(data);
                    window.location.reload();
                });
        } else {
            alert('User not deleted.');
        }
    })
})
})

// To view recepient
$(document).ready(function(){
    $('.view_recipient').click( function(){
        
        var view_id = $(this).attr("id");
        jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "view_recipient",nonce_ajax : frontEndAjax.nonce,
            recipient_id:view_id},
            dataType : "json",
            }).done(
            function(data){          
                console.log(data);
                // window.location.reload();
            });
    })

    //adding error message
    
})

//update
$(document).ready(function(){
    $('.modalEdit').on('click', function(){
        $('#modalEdit').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function() {
            return $(this).text();
        }).get();
        console.log(data);

        $('#recipient_name').val(data[0]);
        $('#recipient_num').val(data[1]);
        $('#personalize_yes').val(data[2]);    
    });
})

let inputTags  = document.getElementsByTagName('input');

for(let i = 0; i < inputTags.length;  i++){
    if(inputTags[i].hasAttribute("required")){
        inputTags[i].labels[0].innerHTML += ' <span class="text-danger"> * </span>';
    }   
}

//update receipient
function updateModal(id){
    var person_name = $("#recipient_name_"+id).val();
    var person_number = $("#recipient_num_"+id).val();
    var personalize = $("input[name='personalize_val_"+id+"']:checked").val();
    var active_status = $("input[name='active_val_"+id+"']:checked").val();
    
    if(person_name == '') {
        $("#update_name_error_"+id).css('display','block');
        
    } 
    else{
        $("#update_name_error_"+id).css('display','none');
    } 
    if(person_number == '') {
        $("#update_num_error_"+id).css('display','block');
        
    }else{
        $("#update_num_error_"+id).css('display','none');
    }
    
    if( (person_name != '') && (person_number != '') ) {
        // var update_alert = confirm('Do you want to update this recipient?');
        // if(update_alert == true) {
        // alert("#recipient_name_"+id);
        $("#overlay").fadeIn(300);
        jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "update_recipient",nonce_ajax : frontEndAjax.nonce,recipient_id:id,
            person_name:person_name,person_number:person_number,personalize:personalize,active_status:active_status},
            dataType : "json",
            }).done(
            function(data){           setTimeout(function(){
                $("#overlay").fadeOut(300);
              });    
                Swal.fire("Recipient Updated");
                console.log(data);
                window.location.reload();
            });
            
        // } else {
        //     alert('User not updated.');
        // }
    }
    
  }
//update recipients ends

  
$(document).ready(function(){
    if (window.location.href.match("/?um_action=edit")) {
        $('.profile_actions').css("display", "none");
    }
})


// Set default date
jQuery(document).ready(function($) {
    $("#vat_date_from").datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    $("#vat_date_to").datepicker({ dateFormat: 'yy-mm-dd', showButtonPanel: true});
});
// $("datetimepicker2").datepicker({ changeYear: true, dateFormat: 'dd/mm/yy', showOn: 'none', showButtonPanel: true,  minDate:'0d' });

function editModal(id){
    $("#vat_date_from_"+id).datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    $("#vat_date_to_"+id).datepicker({ dateFormat: 'yy-mm-dd', showButtonPanel: true});
    
    $("#vat_date_from_"+id).on("change", function(){
   
        var start= $(this).datepicker("getDate");
        
       $("#vat_date_to_"+id).datepicker('destroy');
       $("#vat_date_to_"+id).datepicker({ minDate:  ($(this).datepicker("getDate")), dateFormat: 'yy-mm-dd', showButtonPanel: true});
    
    });
}

Date.prototype.addDays = function(days) {
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
  }


$("#vat_date_from").on("change", function(){
   
    var start= $(this).datepicker("getDate");
    
   $("#vat_date_to").datepicker('destroy');
   $("#vat_date_to").datepicker({ minDate:  ($(this).datepicker("getDate")), dateFormat: 'yy-mm-dd', showButtonPanel: true});

});

//save vat starts
$(document).ready(function(){
    $("#save_vat").click(function(){
        var vat_rate = $("#vat_rate").val();
        var vat_date_from = $("#vat_date_from").val();
        var vat_date_to = $("#vat_date_to").val();
        
       
      
        
        
        if(vat_rate == '') {
            $("#vat_rate_error").css('display','block');  
        } 
        else{
            $("#vat_rate_error").css('display','none');
        } 
        if(vat_date_from == '') {
            $("#vat_date_from_error").css('display','block'); 
        }else{
            $("#vat_date_from_error").css('display','none');
        }

        
        if( (vat_rate != '') && (vat_date_from != '') ) {
            jQuery.ajax({
                type: "POST",
                url: frontEndAjax.ajaxurl,
                data: {action: "add_vat_date_exist_validate",nonce_ajax : frontEndAjax.nonce},
                dataType : "json",
                }).done(
                function(data){  
                  var q=0;
                  var p=0;
                  for (let i = 0; i < data.length; i++) {
                    var date_from_exist = JSON.stringify(data[i].date_from);
                    var date_to_exist = JSON.stringify(data[i].date_to);
                    var date_from = JSON.parse(date_from_exist);
                    var date_to = JSON.parse(date_to_exist);
                    if(vat_date_from >= date_from && vat_date_from <= date_to  )
                    {
                      p++;
                    }
                    if(vat_date_to >= date_from && vat_date_to <= date_to  )
                    {
                      q++;
                    }
                     
                  }
                  if(p > 0 || q > 0){
                    if(p > 0 ){
                      $("#vat_date_from_exist_error").css('display','block');
                    }
                    else{
                      $("#vat_date_from_exist_error").css('display','none');
                    }
                    if(q > 0 ){
                      $("#vat_date_to_exist_error").css('display','block');
                    }else{
                      $("#vat_date_to_exist_error").css('display','none');
                    }
                    
                  }else{
                    $("#vat_date_to_exist_error").css('display','none');
                    $("#vat_date_from_exist_error").css('display','none');
                    $("#vat_date_from_error").css('display','none');
                    $("#vat_rate_error").css('display','none');
                    $("#overlay").fadeIn(300);
                    jQuery.ajax({
                        type: "POST",
                        url: frontEndAjax.ajaxurl,
                        data: {action: "save_vat",nonce_ajax : frontEndAjax.nonce,
                        vat_rate:vat_rate,vat_date_from:vat_date_from,vat_date_to:vat_date_to},
                        dataType : "json",
                        }).done(
                        function(data){ 
                            setTimeout(function(){
                                $("#overlay").fadeOut(300);
                              });         
                            Swal.fire("VAT Added");
                            console.log(data);
                            window.location.reload();
                        });
                  }
                });
        };
      });  
  });
//save vat ends

//update vat starts
function updateVatModal(id){
    var vat_rate = $("#vat_rate_"+id).val();
    var vat_date_from = $("#vat_date_from_"+id).val();
    var vat_date_to = $("#vat_date_to_"+id).val();

    if(vat_rate == '') {
        $("#vat_rate_error_"+id).css('display','block');  
    } 
    else{
        $("#vat_rate_error_"+id).css('display','none');
    } 
    if(vat_date_from == '') {
        $("#vat_date_from_error_"+id).css('display','block'); 
    }else{
        $("#vat_date_from_error_"+id).css('display','none');
    }
    // if(vat_date_to == '') {
    //     $("#vat_date_to_error_"+id).css('display','block');  
    // }else{
    //     $("#vat_date_to_error_"+id).css('display','none');
    // }
    
    if( (vat_rate != '') && (vat_date_from != '') ) {

        jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "update_vat_date_exist_validate",nonce_ajax : frontEndAjax.nonce,id:id},
            dataType : "json",
            }).done(
            function(data){  
              var q=0;
              var p=0;
              for (let i = 0; i < data.length; i++) {
                var date_from_exist = JSON.stringify(data[i].date_from);
                var date_to_exist = JSON.stringify(data[i].date_to);
                var date_from = JSON.parse(date_from_exist);
                var date_to = JSON.parse(date_to_exist);
                if(vat_date_from >= date_from && vat_date_from <= date_to  )
                {
                  p++;
                }
                if(vat_date_to >= date_from && vat_date_to <= date_to  )
                {
                  q++;
                }
                 
              }
              if(p > 0 || q > 0){
                if(p > 0 ){
                  $("#vat_date_from_exist_error_"+id).css('display','block');
                }
                else{
                  $("#vat_date_from_exist_error_"+id).css('display','none');
                }
                if(q > 0 ){
                  $("#vat_date_to_exist_error_"+id).css('display','block');
                }else{
                  $("#vat_date_to_exist_error_"+id).css('display','none');
                }
                
              }else{
                $("#vat_date_to_exist_error_"+id).css('display','none');
                $("#vat_date_from_exist_error_"+id).css('display','none');
                $("#vat_date_from_error_"+id).css('display','none');
                $("#vat_rate_error_"+id).css('display','none');
                
                $("#overlay").fadeIn(300);
                jQuery.ajax({
                    type: "POST",
                    url: frontEndAjax.ajaxurl,
                    data: {action: "update_vat_details",nonce_ajax : frontEndAjax.nonce,
                    id:id, vat_rate:vat_rate, date_from:vat_date_from, date_to:vat_date_to},
                    dataType : "json",
                    }).done(
                    function(data){  
                        setTimeout(function(){
                            $("#overlay").fadeOut(300);
                        });                 
                        Swal.fire("VAT Updated");
                        console.log(data);
                        window.location.reload();
                    });
              }
            });

        
    }
  }
//update vat ends


//Users table export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '#report_table' ) ) {
        table = $('#report_table').DataTable();
    }
    else {
        var d = new Date();
        var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
        var PDF_title = 'Virtual Vouchers - User Report ('+currentDate+')';

        var table = $("#report_table").DataTable({
            // paging: false,
            dom: "Bfrtip",
            destroy: true,
            // searching: false,
            buttons: [
                {
                    extend: 'csv',
                    className: 'userReportcsv',
                    filename: 'Users_Report',
                    text: 'Export CSV',
                    exportOptions: { 
                        columns: [0,1,2,3,4,5,6,7,8,9,10,11],
                        modifier: {
                            page: 'all'
                        }
                    },
                    customize: function (csv) {
                        var split_csv = csv.split("\n");
                        $.each(split_csv.slice(1), function (index, csv_row) {
                            var csv_cell_array = csv_row.split('","');    
                        });
                        csv = split_csv.join("\n");
                        return csv;
                    }
                },
                {
                    title: PDF_title,
                    text: 'Export PDF',
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    pageSize: 'LEGAL',
                    filename: 'Users_Report',
                    className: 'userReportcsv pdf_export',
                    exportOptions: {
                        columns: [0,1,2,3,4,5,6,7,8,9,10,11],
                        modifier: {
                            page: 'all'
                        }
                    },
                }
            ]
        });
    }
});

//Retailer table export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '.retailer-table' ) ) {
        table = $('.retailer-table').DataTable({columnDefs: [
            { orderable: false, targets: 11 }
        ]});
    }
    else {
        var d = new Date();
        var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
        var PDF_title = 'Virtual Vouchers - Retailer Report ('+currentDate+')';

        var table = $(".retailer-table").DataTable({
            dom: "Bfrtip",
            destroy: true,
            columnDefs: [
                { orderable: false, targets: 11 }
            ],
            buttons: [{
                extend: 'csv',
                className: 'userReportcsv',
                filename: 'Retailer_Management',
                text: 'Export CSV',
                exportOptions: {
                modifier: {
                        page: 'all'
                    }
                },
                customize: function (csv) {
                    var split_csv = csv.split("\n");
                    split_csv[0] = '"Retailer Name","Sales Contact Person","Contact Number","Description","Order Lead Time","Voucher Denominations","Name of Bank","Branch","Account Type","Account Number","Branch Code"';
                
                    $.each(split_csv.slice(1), function (index, csv_row) {
                        var csv_cell_array = csv_row.split('","');                    
                    });                 
                    csv = split_csv.join("\n");
                    return csv;
                }
            },
            {
                title: PDF_title,
                text: 'Export PDF',
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                filename: 'Retailer_Management',
                className: 'userReportcsv pdf_export',
                exportOptions: {
                    columns: "thead th:not(.noExport)",
                    modifier: {
                        page: 'all'
                    }
                }
            }]
        });
    }
});



$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#example tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    } );
 
    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api().columns().every( function () {
                var that = this;
 
                $( 'input', this.footer() ).on( 'keyup change clear', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        }
    });
 
} );


//inventory table export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '.voucher-number-required-table' ) ) {
        table = $('.voucher-number-required-table').DataTable({
        "order": [[ 0, "asc" ]],
        columnDefs: [
            { }
         ]
    } );
    }
    else {
    var table = $(".voucher-number-required-table").DataTable({
        // paging: false,
        dom: "Bfrtip",
        order: [[ 0, "asc" ]],
        columnDefs: [
            { }
         ],
        destroy: true,
        // searching: false,
        buttons: [
           
            ]
        });
    }
});

//inventory table export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '.voucher-number-issue-table' ) ) {
        table = $('.voucher-number-issue-table').DataTable({
        "order": [[ 0, "asc" ]],
        columnDefs: [
            {  }
         ],
         sarching: false,
    } );
    }
    else {
    var table = $(".voucher-number-issue-table").DataTable({
        // paging: false,
        dom: "Bfrtip",
        order: [[ 0, "asc" ]],
        columnDefs: [
            {  }
         ],
        destroy: true,
        sarching: false,
        buttons: [
            {
            extend: 'csv',
            className: 'userReportcsv voucher-number-issue-table',
            filename: 'Inventory_Error',
            text: 'Export CSV',
            exportOptions: {
              //  columns: [1,2],
            modifier: {
                    page: 'all'
                }
            },
            //Function which customize the CSV (input : csv is the object that you can preprocesss)
            customize: function (csv) {
                var split_csv = csv.split("\n");
                split_csv[0] = '"Line Number","Error","Retailer","Value","Voucher Number"';
                $.each(split_csv.slice(1), function (index, csv_row) {
                    var csv_cell_array = csv_row.split('","');
                });
                csv = split_csv.join("\n");
                return csv;
            }
            },
            {
                text: 'Export PDF',
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                filename: 'Inventory_Error',
                className: 'userReportcsv voucher-number-issue-table pdf_export',
                exportOptions: {
                    modifier: {
                        page: 'all'
                    }
                }
            }]
        });
    }
});



//inventory table export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '.inventory-table' ) ) {
        table = $('.inventory-table').DataTable({
        "order": [[ 0, "desc" ]],
        columnDefs: [
            { orderable: false, targets: 4 }
         ]
    } );
    }
    else {
    var table = $(".inventory-table").DataTable({
        // paging: false,
        dom: "Bfrtip",
        order: [[ 0, "desc" ]],
        columnDefs: [
            { orderable: false, targets: 4 }
         ],
        destroy: true,
        // searching: false,
        buttons: [
           
            ]
        });
    }
});

//inventory table export new
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '.inventory-table-export' ) ) {
        table = $('.inventory-table-export').DataTable({
        "order": [[ 0, "desc" ]]
    } );
    }
    else {
        var d = new Date();
        var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
        var PDF_title = 'Virtual Vouchers - Inventory Report ('+currentDate+')';

    var table = $(".inventory-table-export").DataTable({
        paging: false,
        dom: "Bfrtip",
        order: [[ 0, "desc" ]],
        //searching: false,
        buttons: [
            {
            extend: 'csv',
            className: 'userReportcsv new-product-import',
            // titleAttr: 'Click to download report in .csv format',
            //Name the CSV
            filename: 'Inventory_Management',
            text: 'Export CSV',
            exportOptions: {
              //  columns: [1,2],
            modifier: {
                    page: 'all'
                }
            },
            //Function which customize the CSV (input : csv is the object that you can preprocesss)
            customize: function (csv) {
                var split_csv = csv.split("\n");
                split_csv[0] = '"Retailer","Voucher Number","Value","Expiry Date","Pin Number","Bulk Reserved","Status"';
                $.each(split_csv.slice(1), function (index, csv_row) {
                    var csv_cell_array = csv_row.split('","');
                });
                csv = split_csv.join("\n");
                return csv;
            }
            },
            {
                text: 'Export PDF',
                extend: 'pdfHtml5',
                orientation: 'landscape',
                title: PDF_title,
                // title: 'Inventory Export – Virtual Vouchers',
                // titleAttr: 'Click to download report in .pdf format',
                pageSize: 'LEGAL',
                filename: 'Inventory_Management',
                className: 'userReportcsv inventory-table-export pdf_export',
                exportOptions: {
                    modifier: {
                        page: 'all'
                    }
                }
            }]
        });
    }

    $("#export-inventory").on("click", function() {
        table.button( '.new-product-import' ).trigger();
    });

    $(document).on("search.dt",".inventory-table ",function() {
        var value = $('#inventory-table_filter input').val();
        table.search(value).draw() ;
    }); 


});

//Filter by date
var minDate1, maxDate1;
var miniDate1, maxiDate1;
//product info table export new
$(document).ready(function() {
	
	minDate1 = $('#dlo_from_report').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    maxDate1 = $('#dlo_to_report').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
	
    if ( $.fn.dataTable.isDataTable( '.product-table-export' ) ) {
        table = $('.product-table-export').DataTable({
        "order": [[ 0, "desc" ]]
    } );
    }
    else {
        var d = new Date();
        var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
        var PDF_title = 'Virtual Vouchers - Inventory Report ('+currentDate+')';
        var table = $(".product-table-export").DataTable({

        //paging: false,
        dom: "Bfrtip",
        order: [[ 0, "desc" ]],
        //searching: false,
        buttons: [
            {
            extend: 'csv',
            className: 'userReportcsv new-product-import',
            // titleAttr: 'Click to download report in .csv format',
            //Name the CSV
            filename: 'Inventory_Export',
            text: 'Export CSV',
            exportOptions: {
              //  columns: [1,2],
            modifier: {
                    page: 'all'
                }
            },
            //Function which customize the CSV (input : csv is the object that you can preprocesss)
            customize: function (csv) {
                    //Split the csv to get the rows
                    var split_csv = csv.split("\n");
    
                    //Remove the row one to personnalize the headers
                    split_csv[0] = '"Retailer","Expiry Date","Pin Number","Voucher Number","Value",Bulk Reserved","Status"';
    
                    //For each row except the first one (header)
                    $.each(split_csv.slice(1), function (index, csv_row) {
                            //Split on quotes and comma to get each cell
                            var csv_cell_array = csv_row.split('","');
    
                    });
    
                    //Join the rows with line breck and return the final csv (datatables will take the returned csv and process it)
                    csv = split_csv.join("\n");
                    return csv;
            }
            },
            {
                title: PDF_title,
                text: 'Export PDF',
                extend: 'pdfHtml5',
                message: function() {
                    var dateRange = '';
                    var datefilters = '';
                    var statussfilters = '';
                    var retailersfilters = '';
                    var searchfilters = '';
                    var searchvalue = $('#search_hidden').val();
                   
                    if($('#filteredData_report').val() == 1) {
                        var toDate = d.getFullYear() + "/" + (("0" + (d.getMonth() + 1)).slice(-2)) + "/" + (("0" + (d.getDate())).slice(-2));
                        if($('#dlo_to_report').val() != '') {
                            var tod = new Date($('#dlo_to_report').val());
                            toDate = tod.getFullYear() + "/" + (("0" + (tod.getMonth() + 1)).slice(-2)) + "/" + (("0" + (tod.getDate())).slice(-2));
                        }
                        if($('#dlo_from_report').val() != '') {
                            var fd = new Date($('#dlo_from_report').val());
                            var fromDate = fd.getFullYear() + "/" + (("0" + (fd.getMonth() + 1)).slice(-2)) + "/" + (("0" + (fd.getDate())).slice(-2));
                            var symbol = '';
                            if(searchvalue != '' || $('#filter_retailer').val() != '' || $('#filter_status').val() != ''){
                                symbol = " /";
                            }
                            datefilters = "Expiry date from ("+fromDate+") to ("+toDate+")"+symbol;
                        }
                        if($('#filter_status').val() != ''){
                            var symbol = '';
                            if(searchvalue != '' || $('#filter_retailer').val() != ''){
                                symbol = " /";
                            }
                            statussfilters = "Status ("+$('#filter_status').val()+")"+symbol;
                        }
                        if($('#filter_retailer').val() != ''){
                            if(searchvalue != ''){
                                symbol = " /";
                            }
                            retailersfilters = "Retailer ("+$('#filter_retailer').val()+")"+symbol;
                        }
                        if(searchvalue != ''){
                            searchfilters = "Search By ("+searchvalue+")";
                        }
                        dateRange = "Filtered By : "+datefilters+statussfilters+retailersfilters+searchfilters;
                    }

                    
                    return dateRange
                },
                orientation: 'landscape',
                // titleAttr: 'Click to download report in .pdf format',
                pageSize: 'LEGAL',
                filename: 'Inventory_Export',
                className: 'userReportcsv inventory-table-export pdf_export',
                exportOptions: {
                    modifier: {
                        page: 'all'
                    }
                }
            }],
            footerCallback: function ( row, data, start, end, display ) {
                    var api = this.api(), data;
                    
                    var intVal = function ( i ) {
                        return typeof i === 'string' ?
                            i.replace(/[\R,]/g, '')*1 :
                            typeof i === 'number' ?
                                i : 0;
                    };
                    valueTotalSum = api
                        .column(4, { search:'applied'})
                        .data()
                        .reduce( function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0 );
                        valueTotalSum = valueTotalSum.toFixed(2);
                        valueTotalSum = valueTotalSum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    jQuery('#valueTotalSum').html('R'+valueTotalSum); 
                }
        });
    }
    $("#export-inventory").on("click", function() {
        table.button( '.new-product-import' ).trigger();
    });

    $('#product-table-export').on('search.dt', function() {
        var value = $('#product-table-export_filter input').val();
        $('#search_hidden').val(value);
    }); 

    // Refilter the table
    $('#filter_status').on('change', function () {
        $('#filteredData_report').val(1);
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var value = $('#filter_status').val();
                var status = data[6];
                if ((value == '0')||(value === status)) {
                    return true;
                }
                return false;
            }
        );
        table.draw();
    });
    $('#filter_retailer').on('change', function () {
        $('#filteredData_report').val(1);
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var value = $('#filter_retailer').val();
                var retailer = data[0];
                if (( value == '0')||( value === retailer)) {
                    return true;
                }
                return false;
            }
        );
        table.draw();
    });
	
	// Refilter the table
	$('.filter_by_reports').on('click', function () {
        $('#filteredData_report').val(1);
		$.fn.dataTable.ext.search.push(
			function( settings, data, dataIndex ) {
				var mini1 = minDate1.datepicker("getDate");
				var maxi1 = maxDate1.datepicker("getDate");
				var date = new Date( data[1] );
                var text = '';
                var maxtext = maxi1;

                if(maxi1 === null){
                }else{ 
                    var day  = maxi1.getDate()+1;  
                    var month = maxi1.getMonth()+1;              
                    var year =  maxi1.getFullYear();
                    var maxi1 = new Date(year+'-'+month+'-'+day);
                }

				if (
					( mini1 === null && maxi1 === null ) ||
					( mini1 === null && date <= maxi1 ) ||
					( mini1 <= date  && maxi1 === null ) ||
					( mini1 <= date  && date <= maxi1 )
				) {
					return true;
				}
				return false;
			}
		);
		table.draw();
	});
	
    $(document).on("click",".report_filters_reset",function() {
       $('#filteredData_report').val(0);
       $('#filter_retailer').val('0');
       $('#filter_status').val('0');
	   $('#dlo_from_report').val('');
       $('#dlo_to_report').val('');
       table.search('').draw() ;
       //$('.product-table-export').DataTable().search('').draw();
       $('#filter_retailer').trigger('change');
    });


});

//Filter by date
var minDate, maxDate;
var miniDate, maxiDate;

$(document).ready(function() {
    // Create date inputs
    // miniDate = new DateTime($('#minid'), {
    //     format: 'YYYY-MM-DD'
    // });
    // maxiDate = new DateTime($('#maxid'), {
    //     format: 'YYYY-MM-DD'
    // });
    miniDate = $('#minid').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    maxiDate = $('#maxid').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});

    // DataTables initialisation
    var table = $('#report_table').DataTable();

    $('#regiRedo').on('click', function () {
        $.fn.dataTable.ext.afnFiltering.pop();
        $('#minid').val('');
        $('#maxid').val('');
        table.draw();
    });
 
    // Refilter the table
    $('#regiFilter').on('click', function () {
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var mini = miniDate.datepicker("getDate");
                var maxi = maxiDate.datepicker("getDate");
                var date = new Date( data[9] );
                //console.log(date);
                if(maxi === null){
                }else{
                    var day  = maxi.getDate()+1;  
                    var month = maxi.getMonth()+1;              
                    var year =  maxi.getFullYear();
                    var maxi = new Date(year+'-'+month+'-'+day);
                }
                if (
                    ( mini === null && maxi === null ) ||
                    ( mini === null && date <= maxi ) ||
                    ( mini <= date  && maxi === null ) ||
                    ( mini <= date  && date <= maxi )
                ) {
                    return true;
                }
                return false;
            }
        );
    table.draw();
});

    // Create date inputs
    // minDate = new DateTime($('#dlo_from'), {
    //     format: 'YYYY-MM-DD'
    // });
    // maxDate = new DateTime($('#dlo_to'), {
    //     format: 'YYYY-MM-DD'
    // });
    minDate = $('#dlo_from').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    maxDate = $('#dlo_to').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
 
    // DataTables initialisation
    var table = $('#report_table').DataTable();

    $('#dloRedo').on('click', function () {
        $.fn.dataTable.ext.afnFiltering.pop();
        $('#dlo_from').val('');
        $('#dlo_to').val('');
        table.draw();
    });
 
    // Refilter the table
    $('#dloFilter').on('click', function () {
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var min = minDate.datepicker("getDate");
                var max = maxDate.datepicker("getDate");
                var date = new Date( data[10] );

                if(max === null){
                }else{
                    var day  = max.getDate()+1;  
                    var month = max.getMonth()+1;              
                    var year =  max.getFullYear();
                    var max = new Date(year+'-'+month+'-'+day);
                }

                if (
                    ( min === null && max === null ) ||
                    ( min === null && date <= max ) ||
                    ( min <= date   && max === null ) ||
                    ( min <= date   && date <= max )
                ) {
                    return true;
                }
                return false;
            }
        );
        table.draw();
    });
});

// assigning datatables
$(document).ready(function() {
    // Service fee datatable
    if ( $.fn.dataTable.isDataTable( '#service_fee_table' ) ) {
        ser_table = $('#service_fee_table').DataTable();
    }
    else {
    var ser_table = $('#service_fee_table').DataTable({
        "order": [[ 0, "asc" ], [2, 'asc']],
        columnDefs: [
            { orderable: false, targets: 4 }
         ]
    }); 
    }

    // Open Orders datatable
    var remaining_table = $('#open_orders1').DataTable({
        "order": [[ 2, "asc" ]],
        columnDefs: [
            { orderable: false, targets: 4 }
         ]
    });

    // Vat fee datatable
    if ( $.fn.dataTable.isDataTable( '#vat_table' ) ) {
        vat_table = $('#vat_table').DataTable();
    }
    else {
    var vat_table = $('#vat_table').DataTable({
        columnDefs: [
            { orderable: false, targets: 3 }
         ],
         "order": [[ 1, "desc" ]]
    }); 
    }

    if ( $.fn.dataTable.isDataTable( '#my_account_orders' ) ) {
        acc_order_table = $('.my_account_orders').DataTable();
    }
    else {
    var acc_order_table = $('.my_account_orders').DataTable({
        columnDefs: [
            { orderable: false, targets: [1,2,4,5] }
         ],
         "order": [[ 0, "desc" ]]
    });
    };
});



//Orders report export
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '#orders_table' ) ) {
        table = $('#orders_table').DataTable();
    }
    else {
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();

        today = dd + '-' + mm + '-' + yyyy;
        var table = $("#orders_table").DataTable({
        "order": [[ 0, "desc" ]],
        // paging: false,
        dom: "Bfrtip",
        destroy: true,
        columnDefs: [
            { orderable: false, targets: [4] }
         ],
        // searching: false,
        buttons: [
            {
            extend: 'csv',
            className: 'userReportcsv',
            // titleAttr: 'Click to download report in .csv format',
            //Name the CSV
            filename: 'Orders_Report'+today,
            text: 'Export CSV',
            exportOptions: {
                // columns: [0, 1, $("#orderIdcol"), $("#usernameCol"), $("#dateCreatedCol"), $("#amountCol"), $(".ItemsSold"), $(".OrderStatus"), $(".CustomerFirstName"), $(".CustomerLastName"), $(".CustomerUsername"), $(".CustomerEmail"), $(".CustomerCountry"), $(".CustomerCity"), $(".product_det"), $(".recpt_name"), $(".recpt_num")]
                //columns:[0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18]
                columns: "thead th:not(.noExport)",
            },
            //Function which customize the CSV (input : csv is the object that you can preprocesss)
            customize: function (csv) {
                    //Split the csv to get the rows
                    var split_csv = csv.split("\n");
    
                    //Remove the row one to personnalize the headers
                    split_csv[0] = '"Order Id","Status","Username","Date","Amount","No.of Items sold","Sub Total","Service Fee","VAT","Order Status","Customer First Name","Customer Last Name","Customer Email"';
    
                    //For each row except the first one (header)
                    $.each(split_csv.slice(1), function (index, csv_row) {
                            //Split on quotes and comma to get each cell
                            var csv_cell_array = csv_row.split('","');
    
                    });
    
                    //Join the rows with line breck and return the final csv (datatables will take the returned csv and process it)
                    csv = split_csv.join("\n");
                    return csv;
            }
            },
            {
                text: 'Export PDF',
                extend: 'pdfHtml5',
                orientation: 'landscape',
                // titleAttr: 'Click to download report in .pdf format',
                pageSize: 'LEGAL',
                filename: 'Orders_Report'+today,
                className: 'userReportcsv pdf_export',
                exportOptions: { columns:[0,1,2,3,4,6,7,8,9,10,12],
                    modifier: {
                        page: 'all',
                    }
                }
            }]
        });
    }
});

//Filter by date
var OrderfromDate, OrdertoDate;


$(document).ready(function() {
    // Create date inputs
    // OrderfromDate = new DateTime($('#orderDateFrom'), {
    //     format: 'YYYY-MM-DD'
    // });

    // OrdertoDate = new DateTime($('#orderDateTo'), {
    //     format: 'YYYY-MM-DD'
    // });
    OrderfromDate = $('#orderDateFrom').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    OrdertoDate = $('#orderDateTo').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    // DataTables initialisation
    var Otable = $('#orders_table').DataTable();

    $('#orderReset').on('click', function () {
        $('#orderDateFrom').val('');
        $('#orderDateTo').val('');
        $.fn.dataTable.ext.afnFiltering.pop();
        Otable.search( '' ).columns().search( '' ).draw();
        Otable.draw();
       
    });
 
    // Refilter the table
    $('#orderFilter').on('click', function () {
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var min = OrderfromDate.datepicker("getDate");
                var max = OrdertoDate.datepicker("getDate");
                var date = new Date( data[2] );
                
                if(max === null){
                }else{  
                    var day  = max.getDate()+1;  
                    var month = max.getMonth()+1;              
                    var year =  max.getFullYear();
                    var max = new Date(year+'-'+month+'-'+day);
                }
                if (
                    ( min === null && max === null ) ||
                    ( min === null && date <= max ) ||
                    ( min <= date   && max === null ) ||
                    ( min <= date   && date <= max )
                ) {
                    return true;
                }
                return false;
            }
        );
        Otable.draw();
    });
});

//Filter by Price
$(document).ready(function() { 
    // DataTables initialisation
    var Vtable = $('#report_table').DataTable();

    $('#Reset').on('click', function () {
        $.fn.dataTable.ext.afnFiltering.pop();
        $('#priceMin').val('');
        $('#priceMax').val('');
        Vtable.draw();
    });
 
    // Refilter the table
    $('#filter').on('click', function () {
        $.fn.dataTable.ext.search.push(
        function( settings, data, dataIndex ) {
            var min = parseInt($('#priceMin').val());
            var max = parseInt($('#priceMax').val());
            var price_td = data[11]; // use data for the price column
            if(price_td != ''){
                price_td = price_td;
            }else{
                price_td = 'R0';
            }
            price = price_td.replace('R', '');
            price = parseFloat(price);
            console.log(price);
            if ( 
                ( isNaN( min ) && isNaN( max ) ) ||
                ( isNaN( min ) && price <= max ) ||
                ( min <= price   && isNaN( max ) ) ||
                ( min <= price   && price <= max ) 
                )
            {
                return true;
            }
            return false;
        }
    );
    Vtable.draw();
    });

    $("#reset_filter").on("click", function() {
        Vtable.draw();
    });

});


// Export Payment tables
$(document).ready(function() {
        if ( $.fn.dataTable.isDataTable( '#payment_report' ) ) {
            table = $('#payment_report').DataTable();
        }
        else {
            var d = new Date();
            var currentDate = d.getFullYear() + "/" + (d.getMonth()+1) + "/" + d.getDate();
            var PDF_title = 'Virtual Vouchers - Payment Report ('+currentDate+')';
    
            /*$('#from').val('');
            $('#to').val('');*/
            
            var table = $('#payment_report').DataTable( {
                dom: 'Bfrtip',
                "order": [[ 0, "desc" ]],
                // searching: false,
                buttons: [
                    {
                        extend: 'csv',
                        className: 'userReportcsv',
                        // titleAttr: 'Click to download report in .csv format',
                        //Name the CSV
                        filename: 'Payment_Report',
                        text: 'Export CSV',
                        exportOptions: {
                            columns: [0, 1, $("#orderIdCol"), $("#orderTotalCol"), $("#datePaidCol"), $("#timePaidCol"), $("#numItemSold"), $("#orderStatus"), $("#customerFirstName"), $("#customerLastName"), $("#userName"), $("#customerEmail"), $("#customerCountry"), $("#customerCity")]
                        },
                        //Function which customize the CSV (input : csv is the object that you can preprocesss)
                        customize: function (csv) {
                            //Split the csv to get the rows
                            var split_csv = csv.split("\n");
            
                            //Remove the row one to personnalize the headers
                            split_csv[0] = '"Order Id","Order Total","Date Paid","Time Paid","No.of Items sold","Order Status","Customer First Name","Customer Last Name","Customer User Name","Customer Email","Customer Country","Customer City"';
            
                            //For each row except the first one (header)
                            $.each(split_csv.slice(1), function (index, csv_row) {
                                    //Split on quotes and comma to get each cell
                                    var csv_cell_array = csv_row.split('","');
            
                            });
            
                            //Join the rows with line breck and return the final csv (datatables will take the returned csv and process it)
                            csv = split_csv.join("\n");
                            return csv;
                        }
                    },
                    {
                        title: PDF_title,                
                        text: 'Export PDF',
                        extend: 'pdfHtml5',
                        message: function() {
                            var dateRange = '';
                            if($('#filteredData').val() == 1) {
                                var toDate = d.getFullYear() + "/" + (("0" + (d.getMonth() + 1)).slice(-2)) + "/" + (("0" + (d.getDate())).slice(-2));
                                if($('#to').val() != '') {
                                    var tod = new Date($('#to').val());
                                    toDate = tod.getFullYear() + "/" + (("0" + (tod.getMonth() + 1)).slice(-2)) + "/" + (("0" + (tod.getDate())).slice(-2));
                                }
                                if($('#from').val() != '') {
                                    var fd = new Date($('#from').val());
                                    var fromDate = fd.getFullYear() + "/" + (("0" + (fd.getMonth() + 1)).slice(-2)) + "/" + (("0" + (fd.getDate())).slice(-2));
                                    dateRange = "Filtered By : "+fromDate+" - "+toDate;
                                }
                            }
                            
                            return dateRange
                        },
                        orientation: 'landscape',
                        // titleAttr: 'Click to download report in .pdf format',
                        pageSize: 'LEGAL',
                        filename: 'Payment_Report',
                        className: 'userReportcsv pdf_export',
                        exportOptions: {
                            modifier: {
                                page: 'all'
                            }
                        },
                        customize: function(doc) {
                            doc.styles.message = {
                                fontSize: '13',
                                alignment: 'center'
                            }   
                        }  
                    }
                ],
                "footerCallback": function ( row, data, start, end, display ) {
                    var api = this.api(), data;
                    
                    var intVal = function ( i ) {
                        return typeof i === 'string' ?
                            i.replace(/[\R,]/g, '')*1 :
                            typeof i === 'number' ?
                                i : 0;
                    };
                    
                    orderTotalSum = api
                        .column(1, { search:'applied'})
                        .data()
                        .reduce( function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0 );

                    serviceFeeSum = api
                        .column(2, { search:'applied'})
                        .data()
                        .reduce( function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0 );
                    
                    vatSum = api
                        .column(3, { search:'applied'})
                        .data()
                        .reduce( function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0 );
                    
                    vatSum = vatSum.toFixed(2);
                    vatSum = vatSum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

                    serviceFeeSum = serviceFeeSum.toFixed(2);
                    serviceFeeSum = serviceFeeSum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

                    orderTotalSum = orderTotalSum.toFixed(2);
                    orderTotalSum = orderTotalSum.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

                    jQuery('#orderTotalSum').html('R'+orderTotalSum);
                    jQuery('#serviceFeeSum').html('R'+serviceFeeSum);
                    jQuery('#vatSum').html('R'+vatSum);
                }
            });
        }
    });

//Filter by date
var fromDate, toDate;


$(document).ready(function() {
    // Create date inputs
    // fromDate = new DateTime($('#from'), {
    //     format: 'YYYY-MM-DD'
    // });
    // toDate = new DateTime($('#to'), {
    //     format: 'YYYY-MM-DD'
    // });

    fromDate = $('#from').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});
    toDate = $('#to').datepicker({  dateFormat: 'yy-mm-dd', showButtonPanel: true});

    // DataTables initialisation
    var table = $('#payment_report').DataTable();

    $('#filterReset').on('click', function () {
        $.fn.dataTable.ext.afnFiltering.pop();
        // table.search( '' ).columns().search( '' ).draw();
        table.draw();
        $('#from').val('');
        $('#to').val('');
        $('#filteredData').val(0);
    });
 
    // Refilter the table
    $('#filterSub').on('click', function () {
        $('#filteredData').val(1);
        $.fn.dataTable.ext.search.push(
            function( settings, data, dataIndex ) {
                var min = fromDate.datepicker("getDate");
                var max = toDate.datepicker("getDate");
                var date = new Date( data[4] );
                if(max === null){
                }else{     
                    var day  = max.getDate()+1;  
                    var month = max.getMonth()+1;              
                    var year =  max.getFullYear();
                    var max = new Date(year+'-'+month+'-'+day);
                }
                if (
                    ( min === null && max === null ) ||
                    ( min === null && date <= max ) ||
                    ( min <= date   && max === null ) ||
                    ( min <= date   && date <= max )
                ) {
                    return true;
                }
                return false;
            }
        );
        table.draw();
    });
});

// My orders 
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '#checkout_tbl' ) ) {
        my_orders = $('#checkout_tbl').DataTable();
    }
    else {
    var my_orders = $('#checkout_tbl').DataTable();
    };

});

// Bulk orders 
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '#bulk_orders_table' ) ) {
        bulk = $('#bulk_orders_table').DataTable();
    }
    else {
        var bulk = $('#bulk_orders_table').DataTable({
            responsive: true,
            columnDefs: [
                { orderable: false, targets: [4] }
            ]
        });
    };
});

// Bulk orders 
$(document).ready(function() {
    if ( $.fn.dataTable.isDataTable( '#bulk_orders_import_table' ) ) {
        bulk = $('#bulk_orders_import_table').DataTable({lengthChange : false});
    }
    else {
        var bulk = $('#bulk_orders_import_table').DataTable({
            responsive: true,
            lengthChange : false,
            columnDefs: [
                { orderable: false, targets: [4] }
            ]
        });
    };
});

// My orders 
$(document).ready(function() { 
    $("form[name='bulk_order_form']").validate({
        // Specify validation rules
        rules: {
            contact_name: "required",
            contact_email: "required",
            contact_phone: "required",
            expected_date: "required",
            your_message: "required",
            contact_phone: {
              required: true,
              minlength: 9
            },
            contact_email: {
              required: true,
              email: true
            },
        },
        // Specify validation error messages
        messages: {
        contact_name: "Please enter contact name",
        contact_email: "Please enter contact email",
        contact_phone: "Please enter phone number",
        expected_date: "Please enter expected delivery date",
        your_message: "Please enter your message",
        contact_phone: {
          required: "Please enter phone number",
          minlength: "Invalid Entry",
        },
        contact_email: "Please enter a valid email address"
        },
        submitHandler: function(form) {
          form.submit();
          var name = $(".contact_name").val();
          var email = $(".contact_email").val();
          var number = $(".contact_phone").val();
          var exp_date = $(".expected_date").val();
          var message = $(".your_message").val();
       
          jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "bulk_order_mail",nonce_ajax : frontEndAjax.nonce,name:name,email:email,number:number,exp_date:exp_date,message:message},
            dataType : "json",
            }).done(
            function(data){      
            });
        }
    });
});

// Country Code / Flag Script for Mobile Number fields
jQuery(document).ready(function() {
    var mble_inputs = document.querySelectorAll("#mobile_number-14, #mobile_number-16, #mob_num, .mob_num, .contact_phone");
    for (var i = 0; i < mble_inputs.length; i++) {
        // console.log(mble_inputs[i]);

        window.intlTelInput(mble_inputs[i], {
            separateDialCode: true,
            allowDropdown: false,
            preferredCountries: ["za"],
            initialCountry: "za"
        });
        jQuery(mble_inputs[i]).attr("maxlength", "9");
    }
});

// Import and export 
$(document).ready(function() { 
    $("form[name='import_file_form']").validate({
        // Specify validation rules
        rules: {
            files: "required",
        },
        // Specify validation error messages
        messages: {
        files: "Please upload file"
        },
        submitHandler: function(form) {
          form.submit();
        }
    });
});