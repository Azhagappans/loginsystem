<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package voucher
 */
$custom_logo_id = get_theme_mod( 'custom_logo' );
$image = get_field('login_logo','option');
?>
<div class="sidebar-wrapper min-sidebar">
	<div class="menu-top">
		<div class="sidebar-logo-wrap">
			<a href="<?php echo get_home_url(); ?>">
				<img class="logo-lg img-fluid" src="<?php echo $image; ?>">
			</a>
			<a href="<?php echo get_home_url(); ?>">
				<img class="logo-sm img-fluid" src="<?php echo get_site_icon_url(); ?>" >
			</a>
		</div>

		<div class="menu-wrapper">
			<div class="menu-main-menu-container">
				<?php $user = wp_get_current_user();
					$roles = $user->roles;
					if(($roles[0] == "administrator" ) || ($roles[0] == "manager" )) {
						wp_nav_menu(array(
							'theme_location'=>'primary',
							'menu_class' 	=> 'list-unstyled'
						));
					}
					else {
						wp_nav_menu(array(
							'menu'=>'sub-menu',
							'menu_class' => 'list-unstyled'
						));
					}
				?>
			</div>
		</div>
	</div>

	<div class="bottom-nav">
		<div class="copyrights">
			<p>©2021 MCi IT. All rights reserved.</p>
		</div>
	</div>
	<div class="sidebar-toggle active">
		<span class="icon"><i class="fa fa-angle-left" aria-hidden="true"></i></span>
	</div>
</div>