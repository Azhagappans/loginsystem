

<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: Recipients
 */
 get_header();
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
           
                <div class="row">
                <div class="col-12">
                <select class="status_filter filter_btn">
                    <option value='Yes'>Active</option>
                    <option value='No'>Inactive</option>
                </select>
                    <button class='btn pull-right rec_common_btn' id="add_recipient" data-toggle="modal" data-target="#myModal">Add Recipient</button>
                    
                        <!--Add recipient form Modal -->
                    <div class="modal fade" id="myModal" data-backdrop="static" role="dialog" >
                        <div class="modal-dialog">
                        
                        <!-- Modal content-->
                        <div class="modal-content" id="model-content">
                            <div class="modal-header">
                            <h4 class="modal-title">Add Recipient</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="person_name"> Recipient Name</label>
                                    <input type="text" class="form-control person_name rec_common_input" id="person_name" placeholder="Name" required>
                                    <span id="save_name_error" class ="save_name_error" style="display:none;">Please enter the name.</span>
                                </div>
                                <div class="form-group">
                                    <label for="mob_num">Mobile Number</label>
                                    <input type="text" pattern="[0-9]{9}" class="form-control rec_common_input" id="mob_num" placeholder="Mobile Number" name="rec_number" required>
                                    <span id="save_num_error" class ="save_num_error" style="display:none;">Please enter the number.</span>
                                </div>
                                <div class="form-group">
                                    <label class='col-4' for="personalize">Personalize</label>
                                    <input class='col-4' type="radio" id="personalize_yes" name="personalize" value="Yes" checked>
                                    Yes
                                    <input class='col-4' type="radio" id="personalize_no" name="personalize" value="No">
                                    No
                                </div>
                                <div class="form-group">
                                    <label class='col-4' for="active">Active</label>
                                    <input class='col-4' type="radio" id="active_yes" name="active" value="Yes" checked>
                                    Yes
                                    <input class='col-4' type="radio" id="active_no" name="active" value="No">
                                    No
                                </div>
                            </div>
                            <div class="modal-footer">
                                <div class="recipient_submit_btn">
                                    <button type="button" class="btn btn-default button rec_common_btn" id="recipient_save" >Save</button>
                                    <button type="button" class="btn btn-default rec_common_btn" id="recipient_cancel" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                        
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <table class="table table-bordered list_table tbl_yes datatable_class" id ="active_status_content_yes">
                        <thead>
                        <tr>
                            <th scope="col" width="25%">Recipient</th>
                            <th scope="col" width="25%">Mobile Number</th>
                            <th scope="col" width="25%">Personalize SMS</th>
                            <th scope="col" width="25%">Actions</th>
                        </tr>
                        </thead>
                        <tbody class="recipient_content">
                        <?php
                        global $wpdb;
                        $current_user_id = get_current_user_id();
                        $rec_sql ="SELECT * FROM `wp_recipients` WHERE `rec_user_id` ='$current_user_id' AND `active_status` = 'Yes' ORDER BY `recipient_name` ASC";
                        $recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
                        foreach($recipients as $value){ ?>
                        <form action="" method="POST">
                            <tr>
                            <td><?php echo $value->recipient_name; ?></td>
                            <td><?php echo $value->recipient_number; ?></td>
                            <td><?php echo $value->personalize; ?></td>
                            
                            <td>
                                <!-- <button type="button" class="btn btn-primary recept_btn" data-toggle="modal" title="Click to view recipient details" data-target="#modalViewRecipient<?= $value->recipient_id; ?>" id="<?php echo $value->recipient_id; ?>"><i class="fa fa-eye"></i></button> -->

                            <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#modalEditRecipient<?= $value->recipient_id; ?>" id="<?php echo $value->recipient_id; ?>" title="" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>

                            <button type="button" class="btn btn-danger recept_btn" name="recipient_id" data-toggle="modal" id="<?php echo $value->recipient_id; ?>" title="" data-original-title="Delete" class="red-tooltip" onclick="confirmDeleteModal('<?php echo $value->recipient_id; ?>')"><i class="fa fa-trash"></i></button></td>
                            </tr>
                            <!--View recipient Modal -->
                                <div class="modal fade" data-backdrop="static" id="modalViewRecipient<?= $value->recipient_id; ?>" role="dialog">
                                    <div class="modal-dialog">
                                    
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h4 class="modal-title">View Recipient</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="Student">Recipient Name :</label><?php echo $value->recipient_name; ?><br>
                                                <label for="Student">Recipient Number :</label><?php echo $value->recipient_number; ?>
                                                <br><label for="Student">Personalize :</label><?php echo $value->personalize; ?><br>
                                                <label for="Student">Active Status :</label><?php echo $value->active_status; ?>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default rec_common_btn" id="recipient_cancel" data-dismiss="modal">Ok</button>
                                        </div>
                                    </div>
                                    
                                    </div>
                                </div>
                            <!--View recipient Modal -->
                            <!-- Recipient details Modal -->
                                <div class="modal fade" data-backdrop="static" id="modalEditRecipient<?= $value->recipient_id; ?>" role="dialog">
                                    <div class="modal-dialog"> 
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Recipient Details </h4>
                                            </div>
                                            <div class="modal-body">
                                            <form action="" method="post" name="recipient_form" id="recipient_form" onsubmit="return validateForm(<?php echo $value->recipient_id; ?>)">
                                                <div class="form-group">
                                                    <label for="recipient_name_<?php echo $value->recipient_id; ?>"> Recipient Name</label>
                                                    <input type="text" class="form-control person_name rec_common_input" name="recipient_name_<?php echo $value->recipient_id; ?>" id="recipient_name_<?php echo $value->recipient_id; ?>" placeholder="Name" value="<?php echo $value->recipient_name; ?>" required>
                                                    <span id="update_name_error_<?php echo $value->recipient_id; ?>" class="update_name_error" style="display:none;">Please Enter the name.</span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="recipient_num_<?php echo $value->recipient_id; ?>">Mobile Number</label>
                                                    <input type="text" pattern="[0-9]{9}" class="form-control mob_num rec_common_input" name="recipient_num_<?php echo $value->recipient_id; ?>" id="recipient_num_<?php echo $value->recipient_id; ?>" placeholder="Mobile Number" value="<?php echo $value->recipient_number; ?>" required onkeypress="return isNumberKey(<?php echo $value->recipient_id; ?>)">
                                                    <span id="update_num_error_<?php echo $value->recipient_id; ?>" class="update_num_error" style="display:none;">Please Enter the number. </span>
                                                </div>
                                                <div class="form-group">
                                                    <label class='col-4' for="personalize_val_<?php echo $value->recipient_id; ?>">Personalize</label>
                                                    <?php if($value->personalize == "Yes") { ?>
                                                    <input type="radio" class='col-4' id="personalize_yes_<?php echo $value->recipient_id; ?>" name="personalize_val_<?php echo $value->recipient_id; ?>" value="Yes" checked>
                                                     Yes
                                                    <input type="radio" class='col-4' id="personalize_no_<?php echo $value->recipient_id; ?>" name="personalize_val_<?php echo $value->recipient_id; ?>" value="No" >
                                                    No
                                                    <?php } else {?>
                                                    <input type="radio" class='col-4' id="personalize_yes_<?php echo $value->recipient_id; ?>" name="personalize_val_<?php echo $value->recipient_id; ?>" value="Yes" >
                                                    Yes
                                                    <input type="radio" class='col-4' id="personalize_no_<?php echo $value->recipient_id; ?>" name="personalize_val_<?php echo $value->recipient_id; ?>" value="No" checked>
                                                    No
                                                    <?php } ?>
                                                </div>
                                                <div class="form-group">
                                                    <label  class='col-4' for="active_val_<?php echo $value->recipient_id; ?>">Active</label>
                                                    <?php if($value->active_status == "Yes") { ?>
                                                    <input class='col-4' type="radio" id="active_yes_<?php echo $value->recipient_id; ?>" name="active_val_<?php echo $value->recipient_id; ?>" value="Yes" checked>
                                                    Yes
                                                    <input class='col-4' type="radio" id="active_no_<?php echo $value->recipient_id; ?>" name="active_val_<?php echo $value->recipient_id; ?>" value="No">
                                                    No
                                                    <?php } else {?>
                                                        <input class='col-4' type="radio" id="active_yes_<?php echo $value->recipient_id; ?>" name="active_val_<?php echo $value->recipient_id; ?>" value="Yes">
                                                    Yes
                                                    <input class='col-4' type="radio" id="active_no_<?php echo $value->recipient_id; ?>" name="active_val_<?php echo $value->recipient_id; ?>" value="No" checked>
                                                    No
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="recipient_submit_btn">
                                                    <button type="submit" class="btn btn-default button rec_common_btn" id="recipient_update"  onclick="updateModal('<?php echo $value->recipient_id; ?>')">Update</button>
                                                    <button type="button" class="btn btn-default rec_common_btn" id="update_cancel" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            <!-- Recipient details Modal -->
                        </form>
                        <?php } ?>
                        
                        </tbody>
                    </table>
                    <table class="table table-bordered list_table tbl_no" id ="active_status_content_no">
                        <thead>
                        <tr>
                            <th scope="col" width="25%">Recipient</th>
                            <th scope="col" width="25%">Mobile Number</th>
                            <th scope="col" width="25%">Personalize SMS</th>
                            <th scope="col" width="25%">Actions</th>
                        </tr>
                        </thead>
                        <tbody class="recipient_content">
                        <?php
                        global $wpdb;
                        $current_user_id = get_current_user_id();
                        $rec_sql ="SELECT * FROM `wp_recipients` WHERE `rec_user_id` ='$current_user_id' AND  `active_status` = 'No' ORDER BY `recipient_name` ASC ";
                        $recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
                        foreach($recipients as $value){ ?>
                        <form action="" method="POST">
                            <tr>
                            <td><?php echo $value->recipient_name; ?></td>
                            <td><?php echo $value->recipient_number; ?></td>
                            <td><?php echo $value->personalize; ?></td>
                            
                            <td>
                                <!-- <button type="button" class="btn btn-primary recept_btn" data-toggle="modal" title="Click to view recipient details" data-target="#modalViewRecipient<?= $value->recipient_id; ?>" id="<?php echo $value->recipient_id; ?>"><i class="fa fa-eye"></i></button> -->

                            <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#modalEditRecipient<?= $value->recipient_id; ?>" id="<?php echo $value->recipient_id; ?>" title="Edit"><i class="fa fa-edit"></i></button>

                            <button type="button" class="btn btn-danger recept_btn" name="recipient_id" data-toggle="modal" id="<?php echo $value->recipient_id; ?>" title="Delete" onclick="confirmDeleteModal('<?php echo $value->recipient_id; ?>')"><i class="fa fa-trash"></i></button></td>
                            </tr>
                            <!--View recipient Modal -->
                                <div class="modal fade" id="modalViewRecipient<?= $value->recipient_id; ?>" role="dialog">
                                    <div class="modal-dialog">
                                    
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h4 class="modal-title">View Recipient</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="Student">Recipient Name :</label><?php echo $value->recipient_name; ?><br>
                                                <label for="Student">Recipient Number :</label><?php echo $value->recipient_number; ?>
                                                <br><label for="Student">Personalize :</label><?php echo $value->personalize; ?><br>
                                                <label for="Student">Active Status :</label><?php echo $value->active_status; ?>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default rec_common_btn" id="cancel" data-dismiss="modal">Ok</button>
                                        </div>
                                    </div>
                                    
                                    </div>
                                </div>
                            <!--View recipient Modal -->
                            <!-- Recipient details Modal -->
                                <div class="modal fade" id="modalEditRecipient<?= $value->recipient_id; ?>" role="dialog">
                                    <div class="modal-dialog"> 
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Recipient Details </h4>
                                            </div>
                                            <div class="modal-body">
                                            <form action="" method="post" name="recipient_form">
                                                <div class="form-group">
                                                    <label for="recipient_name"> Recipient Name</label>
                                                    <input type="text" class="form-control person_name rec_common_input" name="recipient_name_<?php echo $value->recipient_id; ?>" id="recipient_name_<?php echo $value->recipient_id; ?>" placeholder="Name" value="<?php echo $value->recipient_name; ?>">
                                                    <span id="update_name_error_<?php echo $value->recipient_id; ?>" class="update_name_error" style="display:none;"> Please Enter the name.</span>                                                </div>
                                                <div class="form-group">
                                                    <label for="recipient_num">Mobile Number</label>
                                                    <input type="number" pattern="[0-9]{9}" class="form-control mob_num rec_common_input" name="recipient_num_<?php echo $value->recipient_id; ?>" id="recipient_num_<?php echo $value->recipient_id; ?>" placeholder="Mobile Number" value="<?php echo $value->recipient_number; ?>">
                                                    <span id="update_num_error_<?php echo $value->recipient_id; ?>" class="update_num_error" style="display:none;">Please Enter the number. </span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="personalize_val">Personalize</label>
                                                    <?php if($value->personalize == "Yes") { ?>
                                                    <input type="radio" id="personalize_yes" name="personalize_val_<?php echo $value->recipient_id; ?>" value="Yes" checked>
                                                    Yes
                                                    <input type="radio" id="personalize_no" name="personalize_val_<?php echo $value->recipient_id; ?>" value="No" >
                                                    No
                                                    <?php } else {?>
                                                    <input type="radio" id="personalize_yes" name="personalize_val_<?php echo $value->recipient_id; ?>" value="Yes" >
                                                    Yes
                                                    <input type="radio" id="personalize_no" name="personalize_val_<?php echo $value->recipient_id; ?>" value="No" checked>
                                                    No
                                                    <?php } ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="active_val">Active</label>
                                                    <?php if($value->active_status == "Yes") { ?>
                                                    <input type="radio" id="active_yes" name="active_val_<?php echo $value->recipient_id; ?>" value="Yes" checked>
                                                    Yes
                                                    <input type="radio" id="active_no" name="active_val_<?php echo $value->recipient_id; ?>" value="No">
                                                    No
                                                    <?php } else {?>
                                                        <input type="radio" id="active_yes" name="active_val_<?php echo $value->recipient_id; ?>" value="Yes">
                                                    Yes
                                                    <input type="radio" id="active_no" name="active_val_<?php echo $value->recipient_id; ?>" value="No" checked>
                                                    No
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="recipient_submit_btn">
                                                    <button type="submit" class="btn btn-default button rec_common_btn" id="recipient_update"  onclick="updateModal('<?php echo $value->recipient_id; ?>')">Update</button>
                                                    <button type="button" class="btn btn-default rec_common_btn" id="recipient_cancel" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            <!-- Recipient details Modal -->
                        </form>
                        <?php } ?>
                        
                        </tbody>
                    </table>

                    <a href="<?php echo get_home_url(); ?>" id="return_to_order" class='btn pull-right rec_common_btn'>Return to orders</a>
                    </div>
                </div>
        
        </div>
    </div>
</div>
<!-- Recipient delete Modal -->
<div id="deleteModal" class="modal fade" role='dialog'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title">Delete </h4>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this item?</p>
                
            </div>
            <div class="modal-footer">
                <button id='deletecancel' type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <span id= 'deleteButton'></span>
            </div>
            
        </div>
    </div>
</div>
<!-- Recipient delete Modal -->

<div id="overlay">
    <div class="cv-spinner">
        <span class="spinner"></span>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); }?>