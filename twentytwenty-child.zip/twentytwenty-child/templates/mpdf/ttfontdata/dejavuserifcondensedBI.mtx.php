<?php
$name='DejaVuSerifCondensed-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 939.0,
  'Descent' => -236.0,
  'CapHeight' => 939.0,
  'Flags' => 262212,
  'FontBBox' => '[-815 -389 1579 1235]',
  'ItalicAngle' => -11.0,
  'StemV' => 165.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/home/wkreport/public_html/wp-content/plugins/report-generation/mpdf/ttfonts/DejaVuSerifCondensed-BoldItalic.ttf';
$TTCfontID='0';
$originalsize=294584;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedBI';
$panose=' 0 0 2 6 8 6 5 3 5 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>