<?php 
/*
Template Name: checkout
*/
?>
<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
<?php get_header(); ?>
			<div class="main-content-area">
				<div class="page-inner-wrapper">
					<div class="place-new-order-page">				
						<div class="row space-30"></div>
						<div class="voucher-display">
							<div class="white-bg-wrap1">
								<div class="row">
									<?php  the_content();?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php get_footer(); ?>
		<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); }?>