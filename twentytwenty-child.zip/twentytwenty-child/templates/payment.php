<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
<?php
/**
* Template Name: payment
 */
 get_header();
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
            <!-- <div class="container"> -->
                <div class="row">
                    <div class="col-md-12 filter_tbl">
                        <input type="hidden" id="filteredData" name="filteredData" value="0">
                        <table cellspacing="5" cellpadding="5" class="borderless pay_table_filter">
                            <tbody>
                                <tr>
                                    <td>Date From:</td>
                                    <td><input type="text" id="from" name="from" class="date_input_filters"></td>
                                    <td>Date To:</td>
                                    <td><input type="text" id="to" name="to" class="date_input_filters"></td>
                                    <td><button type="" id="filterSub" class="action-btn" data-toggle="modal" title="Filter"><i class="fa fa-filter"></i></button></td>
                                    <td><button type="" id="filterReset" class="action-btn" data-toggle="modal" title="Reset"><i class="fa fa-repeat"></i></button></td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellspacing="5" cellpadding="5" class="borderless" style="margin-bottom: 20px;">
                            <tbody>
                                <tr>
                                    <td width="20%">Order Total : <div style="display: inline-block; font-weight: bold;" id="orderTotalSum"></div></td>
                                    <td width="20%">Service Fee : <div style="display: inline-block; font-weight: bold;" id="serviceFeeSum"></div></td>
                                    <td width="20%">VAT : <div style="display: inline-block; font-weight: bold;" id="vatSum"></div></td>
                                    <td width="0%"></td>
                                    <td width="0%"></td>
                                    <td width="0%"></td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered list_table column_height" id="payment_report">
                                <thead>
                                <tr>
                                    <th scope="col" width="15%" id="orderIdCol">Order ID</th>
                                    <th scope="col" width="20%" id="orderTotalCol">Order Total</th>
                                    <th scope="col" width="15%" id="servicefee">Service Fee</th>
                                    <th scope="col" width="15%" id="vat">VAT</th>
                                    <th scope="col" width="20%" id="datePaidCol">Date Paid</th>
                                    <th scope="col" width="15%" id="timePaidCol">Time Paid</th>
                                    <th scope="col" width="0%" class="table_hide" id="numItemSold">No.of Items sold</th>
                                    <th scope="col" width="0%" class="table_hide" id="subtotal">Sub Total</th>                                    
                                    <th scope="col" width="0%" class="table_hide" id="orderStatus">Order Status</th>
                                    <th scope="col" width="0%" class="table_hide" id="customerFirstName">Customer First Name</th>
                                    <th scope="col" width="0%" class="table_hide" id="customerLastName">Customer Last Name</th>
                                    <th scope="col" width="0%" class="table_hide" id="userName">Customer User Name</th>
                                    <th scope="col" width="0%" class="table_hide" id="customerEmail">Customer Email</th>
                                    <th scope="col" width="0%" class="table_hide" id="customerCountry">Customer Country</th>
                                    <th scope="col" width="0%" class="table_hide" id="customerCity">Customer City</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    global $wpdb;
                                    $rec_sql = "SELECT * FROM wp_wc_order_stats INNER JOIN wp_wc_customer_lookup ON wp_wc_customer_lookup.customer_id=wp_wc_order_stats.customer_id WHERE wp_wc_order_stats.status IN ('wc-processing','wc-completed')";
                                    $recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
                                    // print_r($recipients);
                                    foreach($recipients as $value){ 
                                        $s = $value->date_created;
                                        $dt = new DateTime($s);

                                        $date = $dt->format('Y-m-d');
                                        $time = $dt->format('H:i:s');
                                     ?>
                                    <tr>
                                        <td><a href="/voucher/my-account/view-order/<?php echo $value->order_id; ?>/"><?php echo  $value->order_id; ?></a></td>
                                        <td>R<?php echo numberformat($value->net_total); ?></td>
                                        <td>
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'Service Fee' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo 'R'.numberformat($fee_result[0]->meta_value);                                             
                                            ?>
                                        </td>
                                        <td>
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'VAT' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo 'R'.numberformat($fee_result[0]->meta_value);
                                            ?>
                                        </td>
                                        <td><?php echo $date; ?></td>
                                        <td><?php echo $time; ?></td>
                                        <td class="table_hide"><?php echo $value->num_items_sold; ?></td>
                                        <td class="table_hide">
                                            <?php 
                                            $order = wc_get_order( $value->order_id );
                                            echo 'R'.numberformat($order->get_subtotal()); 
                                            ?>
                                        </td>                                        
                                        <td class="table_hide"><?php echo $value->status; ?></td>
                                        <td class="table_hide"><?php echo $value->first_name; ?></td>
                                        <td class="table_hide"><?php echo $value->last_name; ?></td>
                                        <td class="table_hide"><?php echo $value->username; ?></td>
                                        <td class="table_hide"><?php echo $value->email; ?></td>
                                        <td class="table_hide"><?php echo $value->country; ?></td>
                                        <td class="table_hide"><?php echo $value->city; ?></td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <!-- </div> -->
        </div>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'log-in/'); }?>