<?php 
if (get_current_user_id()) {
	// display navbar here
?>
<?php
/**
* Template Name: view-open-orders
 */
 get_header();
 $order_id = $_GET['view_id'];
 $order = wc_get_order( $order_id );
 $order_items = $order->get_items();
?>
<div class="woo-open-order">
<div class="main-content-area payment_report woocommerce">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap white_bg">
        	<div class="container-open-orders">
			<div class="row">
	<div class="order_summary col-md-12 p-4 voucher-display">		
		<div class="white-bg-wrap">			
			<ul class="order_details1">
				<li class="order">
					<h3>General Information</h3>
				<li class="order">
					<strong><?php esc_html_e( 'Order Number : ', 'woocommerce' ); ?></strong>
					<?php echo esc_html( $order->get_order_number() ); ?>
				</li>
				<li class="date">
					<strong><?php esc_html_e( 'Order Date : ', 'woocommerce' ); ?></strong>
					<?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?>
				</li>
				<li class="order">
					<strong><?php esc_html_e( 'Order Status : ', 'woocommerce' ); ?></strong>
					<?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>
				</li>
				<li class="order">
					<?php
					$pdf_url = wp_nonce_url( admin_url( 'admin-ajax.php?action=generate_wpo_wcpdf&template_type=invoice&order_ids=' . $order->get_order_number(). '&my-account'), 'generate_wpo_wcpdf' );
					?>
					<?php 
					if($order->get_status()!="pending"){ ?>
					<p><a href="<?php echo $pdf_url; ?>" target="_blank">Download Invoice <i class="fa fa-download"></i></a></p>
					<?php } ?>
				</li>
			</ul>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12 p-4 voucher-display">
		<div class="white-bg-wrap">
			<h3>Order Details</h3>
			<table class="woocommerce-checkout-review-order-table shop_table" id="checkout_tbl_checkout">
				<thead>
					<tr>
						<th class="product-name"><?php esc_html_e( 'Recipient', 'woocommerce' ); ?></th>
						<th class="product-name"><?php esc_html_e( 'Mobile Number', 'woocommerce' ); ?></th>
						<th class="product-name"><?php esc_html_e( 'Retailer', 'woocommerce' ); ?></th>
						<th class="product-price"><?php esc_html_e( 'Amount', 'woocommerce' ); ?></th>
						<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></th>
						<th class="product-subtotal"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php		
					$new_fees = array();
					foreach($order_items as $item_id => $item ) {
						$product_id = $item['product_id'];		
						$terms = get_the_terms($product_id, 'retailer');
						foreach($terms as $term) {
							$new_fees[$term->term_id]['price'] = $new_fees[$term->term_id]['price']+$item['subtotal'];
							$new_fees[$term->term_id]['name'] = $term->name;
							$product_cat = $term->name;
						}			
						?>
						<tr class="woocommerce-cart-form__cart-item">
							<td class="Recipient-name" data-title="<?php esc_attr_e('Recipient', 'woocommerce'); ?>">
								<?php echo wc_get_order_item_meta($item_id, 'recipient', true); ?>
							</td>	
							<td class="Recipient-number" data-title="<?php esc_attr_e('Recipient Number', 'woocommerce'); ?>">
								<?php echo wc_get_order_item_meta($item_id, 'recipient_number', true); ?>
							</td>
							<td class="product-name" data-title="<?php esc_attr_e('Product', 'woocommerce'); ?>">
								<?php echo $product_cat; ?>
							</td>
							<td class="product-price" data-title="<?php esc_attr_e('Price', 'woocommerce'); ?>">
								<?php echo "R".numberformat($item['subtotal']); ?>
							</td>
							<td class="product-quantity" data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
								<?php echo $item['quantity']; ?>
							</td>
							<td class="product-subtotal" data-title="<?php esc_attr_e('Subtotal', 'woocommerce'); ?>">
								<?php echo "R".numberformat($item['subtotal']); ?>
							</td>
						</tr>
						<?php
					}
					?>		
				</tbody>
				</table>
				<table id="orders_tax_area" class="woocommerce-checkout-review-order-table shop_table orders_foot_area">
				<?php
					function searchForId($id, $array) {
						foreach ($array as $key => $val) {
							if ($val['label'] === $id) {
								return $key;
							}
						}
						return null;
					}
					
					$orderDetails = $order->get_order_item_totals();
					if(count($orderDetails) == 3){ ?>
						<script>jQuery('#orders_tax_area').addClass('extra_column')</script>
					<?php }
					if(count($orderDetails) == 4){ ?>
						<script>jQuery('#orders_tax_area').addClass('extra_column_vat')</script>
					<?php }

					$find_servicefee = searchForId('Service Fee:', $orderDetails);
					if(!$find_servicefee){
						$servicefee_data =  array (
							'label' => 'Service Fee:',
							'value' => 'R0'
						);
						$orderDetails["service_fee"] = $servicefee_data;
					}

					$find_vatfee = searchForId('VAT:', $orderDetails);
					if(!$find_vatfee){
						$vatfee_data =  array (
							'label' => 'VAT:',
							'value' => 'R0'
						);
						$orderDetails["vat"] = $vatfee_data;
					}

					// foreach($orderDetails as $orderDetail) {
					// 	// print_r($orderDetail);
					// 	$orderLabel = str_replace(':', '', $orderDetail['label']);
					// 	if($orderLabel != 'Payment method') {
					// 		$trCls = 'cart-subtotal1';
					// 		if($orderLabel == 'Total') {
					// 			$trCls = 'order-total1';
					// 		}
							
					foreach($orderDetails as $orderDetail) {
						$orderLabel = str_replace(':', '', $orderDetail['label']);
						if($orderLabel != 'Payment method') {
							$trCls = 'cart-subtotal';
							if($orderLabel == 'Total') {
								$trCls = 'order-total';
							}
							?>
							<tr class="<?php echo $trCls; ?>" >
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th <?php if($orderLabel == 'Service Fee') { ?>id="MiniLeftNav"<?php }?>>
								<?php echo $orderLabel;
								// if($orderLabel == "Subtotal"){ echo $orderLabel; } 
								// if($orderLabel == "Service Fee"){ echo $orderLabel; } 
								?>
									<?php
									if($orderLabel == 'Service Fee') { ?>
										<a class="navtext" >
											<i style="background:white; color:#f5862a;" class="fa fa-info-circle"></i>
											<span>
												<?php				
												echo "<table>";
												foreach($new_fees as $key => $service) {
													$price = $service['price'];
													$ser_fee = "SELECT service_fee FROM wp_service_fee WHERE retailer_id = $key AND $price BETWEEN feevalue_from AND feevalue_to";
													$servicefee = $wpdb->get_results($wpdb->prepare($ser_fee));
													if($servicefee[0]->service_fee != '') {
														echo "<tr>";
														echo "<td>";
														echo $service['name'];
														echo "</td>";
														echo "<td>";
														echo $servicefee[0]->service_fee ."%";
														echo "</td>";
														echo "<td>";
														echo "R".numberformat($price);
														echo "</td>";
														echo "</tr>";
													}										
												}
												echo "</table>";
												?>
											</span>
										</a>
										<?php 
									} ?>
								</th>
								
								<td><?php echo $orderDetail['value']; ?></td>
							</tr>
							<?php
						}			
					}
					?>
				<!-- </tfoot> -->
				</table>
				<table id="tax_area" style="display:none;">
					<?php
					function searchForIdq($id, $array) {
						foreach ($array as $key => $val) {
							if ($val['label'] === $id) {
								return $key;
							}
						}
						return null;
					}
					
					$orderDetails = $order->get_order_item_totals();

					$find_servicefee = searchForId('Service Fee:', $orderDetails);
					if(!$find_servicefee){
						$servicefee_data =  array (
							'label' => 'Service Fee:',
							'value' => 'R0'
						);
						$orderDetails["service_fee"] = $servicefee_data;
					}

					$find_vatfee = searchForId('VAT:', $orderDetails);
					if(!$find_vatfee){
						$vatfee_data =  array (
							'label' => 'VAT:',
							'value' => 'R0'
						);
						$orderDetails["vat"] = $vatfee_data;
					}

					foreach($orderDetails as $orderDetail) {
						// print_r($orderDetail);
						$orderLabel = str_replace(':', '', $orderDetail['label']);
						if($orderLabel != 'Payment method') {
							$trCls = 'cart-subtotal1';
							if($orderLabel == 'Total') {
								$trCls = 'order-total1';
							}
							?>
							<tr>
								<td <?php if($orderLabel == 'Service Fee') { ?>id="MiniLeftNav"<?php }?>><?php echo $orderLabel; ?>
								<?php
									if($orderLabel == 'Service Fee') { ?>
										<a class="navtext" >
											<i style="background:white; color:#f5862a;" class="fa fa-info-circle"></i>
											<span>
												<?php				
												echo "<table>";
												foreach($new_fees as $key => $service) {
													$price = $service['price'];
													$ser_fee = "SELECT service_fee FROM wp_service_fee WHERE retailer_id = $key AND $price BETWEEN feevalue_from AND feevalue_to";
													$servicefee = $wpdb->get_results($wpdb->prepare($ser_fee));
													if($servicefee[0]->service_fee != '') {
														echo "<tr>";
														echo "<td>";
														echo $service['name'];
														echo "</td>";
														echo "<td>";
														echo $servicefee[0]->service_fee ."%";
														echo "</td>";
														echo "<td>";
														echo "R".numberformat($price);
														echo "</td>";
														echo "</tr>";
													}										
												}
												echo "</table>";
												?>
											</span>
										</a>
										<?php 
									} ?></td>
								<td><?php echo $orderDetail['value']; ?></td>
							</tr>
							
							<?php
						}			
					}
					?>
				</table>
			<!-- </table> -->
			<div class="tax_area1" style="float:right; margin:30px;display:none;">
			<table>
				<?php
					global $wpdb;			
					$cou = $order->get_order_item_totals();
					$count = count($cou);
					//echo "<pre>";
					//print_r($count);exit;
					//echo "</pre>";
					if($count == 3){
						foreach ( $cou as $key => $total ) { ?>
							<?php if($key == "cart_subtotal"){?>
								<?php if($total['label'] == "Subtotal:"){?>
									
									<tr><td><strong><span id="subtotal">Subtotal:</span></strong></td>
									<td><span id="subtotal_value"><?php echo numberformat($total['value']); ?></span><br></td></tr>
									
									<?php } ?>
									<?php } 
						}?>
						<tr><td><strong class="vat-zero"><span id="subtotal">Service Fee:</span></strong></td>
						<td><span class="vat-zero" id="subtotal_value">R<?php echo 0; ?></span></td></tr><br class = "vat-zero">
						<tr><td><strong class="vat-zero"><span id="subtotal">VAT:</span></strong></td>
						<td><span class="vat-zero" id="subtotal_value">R<?php echo 0; ?></span></td></tr><br class = "vat-zero">
						<?php foreach ( $cou as $key => $total ) { ?>
							<?php if($total['label'] == "Total:"){?>
							
								<tr><td><strong><span id="subtotal">Total:</span></strong></td>
								<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr>
							
							<?php } ?>
							<?php } ?>
					<?php } elseif($count == 4){
						foreach ( $cou as $key => $total ) { ?>
							<?php if($key == "cart_subtotal"){?>
								<?php if($total['label'] == "Subtotal:"){?>
									
									<strong><span id="subtotal">Subtotal:</span></strong>
									<span id="subtotal_value"><?php echo $total['value']; ?></span><br>
									
									<?php } ?>
									<?php } ?>
									<?php if($total['label'] == "Service Fee:"){?>
							
											<tr <?php if($orderLabel == 'Service Fee:') { ?>id="MiniLeftNav"<?php }?>><td><strong><span id="subtotal">Service Fee:</span></strong></td>
											<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr><br>
										
										<?php } 
						}?>
						
						<tr><td><strong class="vat-zero"><span id="subtotal">VAT:</span></strong></td>
						<td><span class="vat-zero" id="subtotal_value">R<?php echo 0; ?></span></td></tr><br class = "vat-zero">
						<?php foreach ( $cou as $key => $total ) { ?>
							<?php if($total['label'] == "Total:"){?>
							
								<tr><td><strong><span id="subtotal">Total:</span></strong></td>
								<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr>
							
							<?php } ?>
							<?php } ?>
					<?php } else {
						foreach ( $cou as $key => $total ) {
							// print_r($key);
							
							?>
							<?php if($key == "cart_subtotal"){?>
							<?php if($total['label'] == "Subtotal:"){?>
								
								<tr><td><strong><span id="subtotal">Subtotal:</span></strong></td>
								<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr><br>
								
								<?php } ?>
								<?php } ?>
							
							<?php if($total['label'] == "Service Fee:"){?>
							
								<tr><td><strong><span id="subtotal">Service Fee:</span></strong></td>
								<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr><br>
							
							<?php } ?>

							<?php if($total['label'] == "VAT:"){?>
								
								
								<tr><td><strong><span id="subtotal">VAT:</span></strong></td>
									<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr><br>
								
								<?php } else{?>
									<?php if(($key != "cart_subtotal") && ($key != "payment_method") && ($key != "order_total")){?>
									
									<tr class = "vat-zero"><td><strong class="vat-zero"><span id="subtotal">VAT:</span></strong></td>
									<td><span class="vat-zero" id="subtotal_value">R<?php echo 0; ?></span></td></tr><br class = "vat-zero">
								
								<?php  } ?>
							<?php } ?>



								<?php if($total['label'] == "Total:"){?>
								
									<tr><td><strong><span id="subtotal">Total:</span></strong></td>
									<td><span id="subtotal_value"><?php echo $total['value']; ?></span></td></tr>
								
								<?php } ?>
								
							<!-- <span id="<?php echo esc_html( $total['label'] ); ?>"><strong><?php echo esc_html( $total['label'] ); ?></strong></span>
							<span><?php echo ( 'payment_method' === $key ) ? esc_html( $total['value'] ) : wp_kses_post( $total['value'] );?></span><br> -->
							
							
							<!-- <span id="service_fee">Service Fee:</span>
							<span id="vat">VAT:</span>
							<span id="payast_total">PayFast Total:</span> -->
							<!-- <table>
											<tr>
												<th scope="row"><?php echo esc_html( $total['label'] ); ?></th>
												<td><?php echo ( 'payment_method' === $key ) ? esc_html( $total['value'] ) : wp_kses_post( $total['value'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
											</tr>
						</table> -->
											<?php
						} 
					}
					if($count == 5) {?>
						<style>.vat-zero { display : none !important; }</style>
					<?php } ?>
					</table>
				</div>
		</div>
		
	</div>
	<div class="col-md-12 p-4">
	<button class="btn pull-right rec_common_btn return_list back_btn" onclick="window.history.go(-1); return false;">Back</button></div>
</div>
            </div>   
        </div>
    </div>
</div>


					</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>