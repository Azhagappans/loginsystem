<?php 
/*
Template Name: edit-profile
*/
?>
<?php 
if (get_current_user_id()) {
	// display navbar here
?>

<?php 
$logo = get_field('login_logo','option');
?>

<?php 
if ( is_page( 'edit-account'  ) ) {
    echo 'good';
    exit;
} else {
    // none of the page about us, contact or management is in view
}
?>

<?php get_header('login'); ?>
<section class="login-screen register-screen edit-profile-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<div class="login-wrapper register-wrapper" id="edit-profile-wrapper">
					<div class="logo-wrap">
					<?php if($logo) { ?><a href="<?php echo get_home_url(); ?>"><img src="<?php echo $logo; ?>" class="img-fluid"></a><?php }; ?>
					<!-- <a href="#"><img src="<?php //echo get_stylesheet_directory_uri(); ?>/assets/images/logo-login.png" class="img-fluid"></a> -->
					</div>
					<h2 class="mb-2"><?php echo get_the_title(); ?></h2>
					<?php echo do_shortcode(get_the_content()); ?>
					<div class="profile_actions">
						<a href="<?php echo get_home_url(); ?>" class='btn rec_common_btn return_btn'>Return to orders</a>
						<a class="btn rec_common_btn return_btn" href="<?php echo get_home_url(); ?>/my-profile/<?php echo $update; ?>/?um_action=edit">Edit</a>	
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


    </div>
<?php get_footer(); ?>
</section>

<?php
// display navbar here
}
else {
	wp_redirect('http://202.129.196.139:3444/voucher/'); 
}
?>