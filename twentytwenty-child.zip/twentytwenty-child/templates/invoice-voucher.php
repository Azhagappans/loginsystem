<?php 
/*
Template Name: Invoice Voucher
*/
include('mpdf/mpdf.php');

$logo = home_url().'/wp-content/uploads/2021/06/logo-small.png';

if(isset($_GET['i'])){
	$order_id = base64_decode($_GET['i']);
}
$order = wc_get_order( $order_id );

$order_id  = $order->get_id(); // Get the order ID
$parent_id = $order->get_parent_id(); // Get the parent order ID (for subscriptions…)

$user_id   = $order->get_user_id(); // Get the costumer ID
$user      = $order->get_user(); // Get the WP_User object

$order_status  = $order->get_status(); // Get the order status (see the conditional method has_status() below)
$currency      = $order->get_currency(); // Get the currency used  
$payment_method = $order->get_payment_method(); // Get the payment method ID
$payment_title = $order->get_payment_method_title(); // Get the payment method title
$date_created  = $order->get_date_created(); // Get date created (WC_DateTime object)
$date_modified = $order->get_date_modified(); // Get date modified (WC_DateTime object)

$orders = new WC_Order($order->get_order_number());
$order_data = $order->get_data(); // The Order data
$cart_tax = $order_data['cart_tax'];

$neworder = wc_get_order($order->get_order_number());

// Get the currency symbol
$currency_symbol = get_woocommerce_currency_symbol( get_woocommerce_currency() );
// Get order subtotal
$order_subtotal = $orders->get_subtotal();
// Get the correct number format (2 decimals)
$order_subtotal = number_format( $order_subtotal, 2 );

$order_total = $orders->get_total();
$order_total = number_format( $order_total, 2 );

$shippingtotal = $orders->get_shipping_total();


$billing_country = $order->get_billing_country(); // Customer billing country
$output = '';
$loops = '';

$item_fee = new WC_Order_Item_Fee();
// Iterating through each WC_Order_Item_Product objects
foreach ($neworder->get_items() as $item_key => $item ){

    ## Using WC_Order_Item methods ##

    // Item ID is directly accessible from the $item_key in the foreach loop or
    $item_id = $item->get_id();

    $item_meta_data = $item->get_meta_data();

 
    ## Using WC_Order_Item_Product methods ##

    $product      = $item->get_product(); // Get the WC_Product object

    $product_id   = $item->get_product_id(); // the Product id
    $variation_id = $item->get_variation_id(); // the Variation id

    $item_type    = $item->get_type(); // Type of the order item ("line_item")

    $item_name    = $item->get_name(); // Name of the product
    $quantity     = $item->get_quantity();  
    $tax_class    = $item->get_tax_class();
    $line_subtotal     = $item->get_subtotal(); // Line subtotal (non discounted)
    $line_subtotal_tax = $item->get_subtotal_tax(); // Line subtotal tax (non discounted)
    $line_total        = $item->get_total(); // Line total (discounted)
    $line_total_tax    = $item->get_total_tax(); // Line total tax (discounted)

    ## Access Order Items data properties (in an array of values) ##
    $item_data    = $item->get_data();

    $product_name = $item_data['name'];
    
    $product_id   = $item_data['product_id'];
    $variation_id = $item_data['variation_id'];
    $quantity     = $item_data['quantity'];
    
    $tax_class    = $item_data['tax_class'];
    $line_subtotal     = $item_data['subtotal'];
    $line_subtotal_tax = $item_data['subtotal_tax'];
    $line_total        = $item_data['total'];
    
    $line_total_tax    = $item_data['total_tax'];

    foreach($item_meta_data as $meta_array){  
    	if($meta_array->key == 'recipient'){
    		$receipient = $meta_array->value;
    	}
    }

    $loops .= '<tr>
			    <td style="border: 1px solid #000; text-align:center;">'.$receipient.'</td>
			    <td style="border: 1px solid #000; text-align:center;">'.$product_name.'</td>
			    <td style="border: 1px solid #000; text-align:center;">'.$quantity.'</td>
			    <td style="border: 1px solid #000; text-align:center;">'.$currency_symbol.number_format($line_total,2).'</td>
			  </tr>';

}

$output .= '<div class="invoice-box" style="max-width: 800px;margin: auto;padding: 30px;border: 1px solid #eee;	box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);font-size: 16px;line-height: 24px;font-family: Helvetica, Arial, sans-serif;color: #555;">
			<table cellpadding="0" cellspacing="0" style="width: 100%;line-height: inherit;text-align: left;">
				<tr class="top" >
					<td colspan="2" style="padding:20px 0 20px 0;">
						<table style="width: 100%;line-height: inherit;text-align: left;">
							<tr>
								<td class="title">
									<img src="'.$logo.'" style="float: left;" />
									<h2 style="margin: 22px;"> <span style="color: #193f72; font-weight: 200;">Virtual</span><br><span style="color:#f5862a">Vouchers</span></h2>
								</td>

								<td>
									Date: '.date('M d, Y H:i:s', strtotime($date_created)).'<br>
									Invoice Number: #'.$order->get_order_number().' 
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr >
					<td colspan="2" style="padding:10px 0 0 0;">
						<table style="width: 100%;">
							<tr>
								<hr>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="information" >
					<td colspan="2" style="padding:10px 0 0 0;">
						<table style="width: 80%;line-height: inherit;text-align: left;">
							<tr>
								<td>
									To:<br>
									Company Name<br />
									Company Address<br />
									VAT Number
								</td>
								<td style="text-align: right;">
									From:<br>
									Address <br />
									VAT Number<br />
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr >
					<td colspan="2" style="padding:10px 0 0px 0;">
						<table style="width: 100%;">
							<tr>
								<hr>
							</tr>
						</table>
					</td>
				</tr>
				<tr >
					<td colspan="2" style="padding:10px 0 0px 0;">
						<table style="width:100%;border-collapse: collapse;">
						  <tr>
						    <th style="border: 1px solid #000">Retailer</th>
						    <th style="border: 1px solid #000">Value</th>
						    <th style="border: 1px solid #000">Quantity</th>
						    <th style="border: 1px solid #000">Line Total</th>
						  </tr>
						  '.$loops.'
						   <tr>
						    <td style="border: 1px solid #000; text-align:center;">Service Fee</td>
						    <td style="border: 1px solid #000; text-align:center;"></td>
						    <td style="border: 1px solid #000; text-align:center;">1</td>
						    <td style="border: 1px solid #000; text-align:center;">'.$currency_symbol.$cart_tax.'</td>
						  </tr> 
						</table>
					</td>
				</tr>
				<tr class="information" >
					<td colspan="2" style="padding:10px 0 0 0;">
						<table style="width: 80%;line-height: inherit;text-align: left;">
							<tr>
								<td>
									
								</td>
								<td style="text-align: right;">
									Subtotal: '.$currency_symbol.$order_subtotal.'<br>
									VAT @ 15%:<br />
									Total: '.$currency_symbol.$order_total.'<br />
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			
		</div>';

$mpdf=new mPDF( '',                          // mode (default '')
				'A4',  0, '',               // format ('A4', '' or...), font size(default 0), font family
				10, 10, 16, 16,     9,  9,  //(margins) left, right, top, bottom, HEADER, FOOTER
				'L');
$mpdf->setFooter('Page {PAGENO} of {nb}');
//$mpdf->WriteHTML($output);
$mpdf->WriteHTML($output);
$mpdf->SetDisplayMode('fullpage');

$PdfPath = 'Voucher.pdf';
$mpdf->Output($PdfPath, 'D');