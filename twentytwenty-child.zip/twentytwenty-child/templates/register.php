<?php 
/*
Template Name: register
*/
?>
<?php 
if (!get_current_user_id()) {
	// display navbar here
 ?>
<?php 
$logo = get_field('login_logo','option');
?>

<?php get_header('login'); ?>

<section class="login-screen register-screen">
		<div class="container">
			<div class="row">
				<div class="col-md-12 ">
					<div class="login-wrapper register-wrapper">
						<div class="logo-wrap">
						<?php if($logo) { ?><a href="#"><img src="<?php echo $logo; ?>" class="img-fluid"></a><?php }; ?>
						<!-- <a href="#"><img src="<?php //echo get_stylesheet_directory_uri(); ?>/assets/images/logo-login.png" class="img-fluid"></a> -->
						</div>
						<h2 class="mb-2"><?php echo get_the_title(); ?></h2>
						<?php
if(isset($_POST["user_password-14"]))
{
$password=$_POST["user_password-14"];
echo "<input type='hidden' id='hidden_password' name='hidden_password' value='".$password."'>";
}
?>
	<!-- <select value="ZAF" data-role="country-selector"></select> -->
	<!-- <div style='text-align:center;'>
	
	<select id="country" class="form-control" ></select> </br></br>
	<select  class="form-control" id ="state"></select>  
	
</div> -->
					<?php echo do_shortcode(get_the_content()); ?>
				</div>
			</div>
		</div>
	</div>
</section>



<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/'); }?>