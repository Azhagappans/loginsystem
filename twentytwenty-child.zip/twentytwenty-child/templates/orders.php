

<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: orders
 */
 get_header();
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
        <div class="container-fin-order">
            <div class="row">
            <div class="col-12 final_order_tbl">
                    <table cellspacing="5" cellpadding="5" class="borderless">
                        <tbody>
                            <tr>
                                <td>Date From:</td>
                                <td><input type="text" id="orderDateFrom" name="orderDateFrom" class="date_input_filters" ></td>
                                <td>Date To:</td>
                                <td><input type="text" id="orderDateTo" name="orderDateTo" class="date_input_filters"></td>
                                <td><button type="" id="orderFilter" class="action-btn" data-toggle="modal" title="Filter"><i class="fa fa-filter"></i></button></td>
                                <td><button type="" id="orderReset" class="action-btn" data-toggle="modal" title="Reset"><i class="fa fa-repeat"></i></button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
					<div class="table-responsive">
                    <table class="table table-bordered list_table column_height orders_table"  id="orders_table">
                        <thead>
                            <tr>
                                <th scope="col" width="20%" id="orderIdcol">Order Id</th>
                                <th scope="col" width="20%" id="orderStatus">Status</th>
                                <th scope="col" width="20%" id="usernameCol">Username</th>
                                <th scope="col" width="20%" id="dateCreatedCol">Date</th>
                                <th scope="col" width="20%" id="amountCol">Amount</th>
                                <th scope="col" width="20%" class="actions noExport" >Action</th>
                                <th scope="col" width="0%" class="table_hide ItemsSold" id="">No.of Items sold</th>
                                <th scope="col" width="0%" class="table_hide" id="subtotal">Sub Total</th>
                                <th scope="col" width="0%" class="table_hide" id="servicefee">Service Fee</th>
                                <th scope="col" width="0%" class="table_hide" id="vat">VAT</th>
                                <th scope="col" width="0%" class="table_hide OrderStatus" id="">Order Status</th>
                                <th scope="col" width="0%" class="table_hide CustomerFirstName" id="">Customer First Name</th>
                                <th scope="col" width="0%" class="table_hide CustomerLastName" id="">Customer Last Name</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerUsername" id="">Customer User Name</th>
                                <th scope="col" width="0%" class="table_hide CustomerEmail" id="">Customer Email</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerCountry" id="">Customer Country</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerCity" id="">Customer City</th>
                                <th scope="col" width="0%" class="table_hide noExport product_det" id="">Product</th>
                                <th scope="col" width="0%" class="table_hide noExport recpt_name" id="">Recipient Name</th>
                                <th scope="col" width="0%" class="table_hide noExport recpt_num" id="">Recipient Number</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                global $wpdb;
                                $query_sql ="SELECT *  FROM `wp_wc_order_stats` AS a  INNER JOIN `wp_wc_customer_lookup` AS b ON a.customer_id=b.customer_id ;";
                                $users = $wpdb->get_results( $wpdb->prepare($query_sql));
                                // print_r($users);
                                foreach($users as $value){
                                $order = wc_get_order( $value->order_id );  
                                $s = $value->date_created;
                                $dt = new DateTime($s);

                                $date = $dt->format('Y-m-d');
                                $time = $dt->format('H:i:s');

                                $dc = $value->date_created;
                                $created = new DateTime($dc);
                                $dc_disp = $created->format('Y-m-d')
                            ?>
                                <tr>
                                    <td><?php echo $value->order_id; ?></td>
                                    <td><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></td>
                                    <td><?php echo $value->first_name; ?>  <?php echo $value->last_name; ?></td>
                                    <td><?php echo $date; ?></td>
                                    <td data-search="<?php echo 'R'.($value->total_sales); ?>"><?php echo 'R'.numberformat($value->total_sales); ?></td>
                                    <td>
                                        <?php $view_link = $value->order_id;?>
                                        <a href="voucher/view-open-order/?view_id=<?php echo $view_link;?>" class="btn_view_open_order woocommerce-button button pay" id="btn_view_open_order"><button type="button" class="btn btn-primary recept_btn action-btn" data-toggle="modal" title="View"><i class="fa fa-eye"></i></button></a>
                                    </td>
                                    <td class="table_hide"><?php echo $value->num_items_sold; ?></td>
                                    <td class="table_hide">
                                            <?php 
                                            $order = wc_get_order( $value->order_id );
                                            echo numberformat($order->get_subtotal()); 
                                            ?>
                                        </td>
                                        <td class="table_hide">
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'Service Fee' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo 'R'.numberformat($fee_result[0]->meta_value);                                             
                                            ?>
                                        </td>
                                        <td class="table_hide">
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'VAT' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo 'R'.numberformat($fee_result[0]->meta_value);
                                            ?>
                                        </td>
                                    <td class="table_hide"><?php echo $value->status; ?></td>
                                    <td class="table_hide"><?php echo $value->first_name; ?></td>
                                    <td class="table_hide"><?php echo $value->last_name; ?></td>
                                    <td class="table_hide"><?php echo $value->username; ?></td>
                                    <td class="table_hide"><?php echo $value->email; ?></td>
                                    <td class="table_hide"><?php echo $value->country; ?></td>
                                    <td class="table_hide"><?php echo $value->city; ?></td>
                                    <?php //foreach ($order->get_items() as $item_id => $item ) { ?>  
                                    <td class="table_hide"><?php //echo $product_name = $item->get_name(); ?> x <?php //echo $quantity = $item->get_quantity(); ?></td>    
                                    <td class="table_hide"><?php //echo $recipient = $item->get_meta( 'recipient', true ); ?></td>
                                    <td class="table_hide"><?php //echo $recipient = $item->get_meta( 'recipient_number', true ); ?></td>
                                    <?php //} ?> 
                                </tr>
                                <!-- Modal -->
                                <div class="modal fade order_det_modal" id="exampleModalLong<?php echo $value->order_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLongTitle">Order Details</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <?php 
                                            $order = wc_get_order( $value->order_id ); 
                                            $order_data = $order->get_data(); 
                                            $order_payment_method = $order_data['payment_method']; 
                                        ?>
                                        <?php
                                            $notes = $order->get_customer_order_notes();
                                        ?>
                                        <div class="modal-body">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col">
                                                        <p><strong>Order Id : </strong><?php echo $value->order_id; ?></p><br>
                                                        <p><strong>Customer First Name : </strong><?php echo $value->first_name; ?></p>
                                                        <p><strong>Customer Last Name : </strong><?php echo $value->last_name; ?></p><br>
                                                        <p><strong>Customer Email : </strong><?php echo $value->email; ?></p><br>
                                                        <p><strong>Order Date : </strong><?php echo $date; ?></p><br>
                                                        <p><strong>Order Status : </strong><?php echo $order->get_status(); ?></p><br>
                                                        <?php foreach ($order->get_items() as $item_id => $item ) { ?>  
                                                        <p><strong>Product : </strong><?php echo $product_name = $item->get_name(); ?> x <?php echo $quantity = $item->get_quantity(); ?></p>    
                                                        <p><strong>Recipient Name : </strong><?php echo $recipient = $item->get_meta( 'recipient', true ); ?></p>
                                                        <p><strong>Recipient Number : </strong><?php echo $recipient = $item->get_meta( 'recipient_number', true ); ?></p>
                                                        <p><strong>SubTotal : </strong><?php echo $product_name = $item->get_subtotal(); ?></p><br>
                                                        <?php } ?>                                                        
                                                        <p><strong>Payment Method : </strong><?php echo $order_payment_method; ?></p><br> 
                                                        <p><strong>Order Total : </strong><b>R<?php echo $value->total_sales; ?></b></p><br> 
                                                        <?php //$order->get_line_tax() ?>                                               
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default rec_common_btn order_det_close" data-dismiss="modal">Close</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
						</tbody>
                    </table>
                    </div>
                </div>
                </div>
                </div>   
        </div>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); }?>