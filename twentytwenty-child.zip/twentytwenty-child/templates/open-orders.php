<?php 
if (get_current_user_id()) {
	// display navbar here
?>
<?php
/**
* Template Name: open-orders
 */
 get_header();
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap white_bg">
        <div class="container-open-orders">
            <div class="row">
                <div class="col-12">
					<table class="table table-bordered list_table"  id="open_orders">
                        <thead>
                            <tr>
                                <th scope="col" width="20%" id="orderIdcol">Order Id</th>
                                <th scope="col" width="20%" id="usernameCol">Username</th>
                                <th scope="col" width="20%" id="mobnumCol">Mobile Number</th>
                                <th scope="col" width="20%" id="remtimeCol">Remaining Time</th>
                                <th scope="col" width="20%" id="amountCol">Order Value</th>
                                <th scope="col" width="15%" class="noExport" id="actions">Actions</th>
                                <th scope="col" width="0%" class="table_hide ItemsSold" id="ItemsSold">No.of Items sold</th>
                                <th scope="col" width="0%" class="table_hide noExport" id="">Time</th>
                                <th scope="col" width="0%" class="table_hide noExport" id="subtotal">Sub Total</th>
                                <th scope="col" width="0%" class="table_hide" id="servicefee">Service Fee</th>
                                <th scope="col" width="0%" class="table_hide" id="vat">VAT</th>
                                <th scope="col" width="0%" class="table_hide OrderStatus" id="orderstatusCol">Order Status</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerFirstName" id="">Customer First Name</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerLastName" id="">Customer Last Name</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerUsername" id="">Customer User Name</th>
                                <th scope="col" width="0%" class="table_hide CustomerEmail" id="">Customer Email</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerCountry" id="">Customer Country</th>
                                <th scope="col" width="0%" class="table_hide noExport CustomerCity" id="">Customer City</th>
                                <th scope="col" width="0%" class="table_hide noExport product_det" id="">Product</th>
                                <th scope="col" width="0%" class="table_hide noExport recpt_name" id="">Recipient Name</th>
                                <th scope="col" width="0%" class="table_hide noExport recpt_num" id="">Recipient Number</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                global $wpdb;
                                $query_sql ="SELECT *  FROM `wp_wc_order_stats` AS a  INNER JOIN `wp_wc_customer_lookup` AS b ON a.customer_id=b.customer_id WHERE a.status = 'wc-pending' ;";
                                $users = $wpdb->get_results( $wpdb->prepare($query_sql));
                                // print_r($users);
                                foreach($users as $value){ 
									
                            ?>
                                <tr>
                                    <td><?php echo $value->order_id; ?></td>
                                    <td><?php echo $value->first_name; ?>  <?php echo $value->last_name; ?></td>
                                    <td>
                                        <?php 
                                        $ordered = wc_get_order( $value->order_id );
                                        $customer_id = $ordered->get_customer_id();
                                        echo $user_number = get_user_meta( $customer_id, 'mobile_number', true );
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $date2 = date_i18n('Y-m-d H:i:s');
                                        $datetime1 = new DateTime($date2);
                                        $minutes_to_add = 360;
                                        $hours = $value->date_created;
                                        $time = new DateTime($hours);
                                        $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
                                        $stamp = $time->format('M d, Y H:i:s');
                                        $datetime2 = new DateTime($stamp);
                                        $interval = $datetime1->diff($datetime2);
                                        echo $elapsed = $interval->format('%h hours %i minutes');
                                        ?>
                                    </td>
                                    <td>R<?php echo $value->net_total; ?></td>
									<td>
									<?php
									$actions = wc_get_account_orders_actions( $value->order_id );
                                    /*
									if ( ! empty( $actions ) ) {
										echo '<a href="' . esc_url( $actions['pay']['url'] ) . '" class="woocommerce-button button pay' . sanitize_html_class( $key ) . '">
                                        <button type="button" class="btn btn-primary recept_btn action-btn" data-toggle="modal" title="Checkout"><i class="fa fa-shopping-cart"></i></button></a>';
									}
                                    */ 
                                    $view_link = $value->order_id;?>
                                    <a href="voucher/view-open-order/?view_id=<?php echo $view_link;?>" class="btn_view_open_order woocommerce-button button pay" id="btn_view_open_order"><button type="button" class="btn btn-primary recept_btn action-btn" data-toggle="modal" title="View"><i class="fa fa-eye"></i></button></a>
                                    <?php
									// if ( ! empty( $actions['view']['url'] ) ) {
									// 	echo '<a href="' . esc_url( $actions['view']['url'] ) . '" class="woocommerce-button button pay btn_view_open_order' . sanitize_html_class( $key ) . '">
									// 	<button type="button" class="btn btn-primary recept_btn action-btn" data-toggle="modal" title="View"><i class="fa fa-eye"></i></button></a>';
									// }
                                    // if ( ! empty( $actions['cancel']['url'] ) ) {
                                    //     echo '<a href="' . esc_url( $actions['cancel']['url'] ) . '" class="woocommerce-button button ' . sanitize_html_class( $key ) . '">
                                    //     <button type="button" class="btn btn-primary recept_btn action-btn" data-toggle="modal" title="Cancel order"><i class="fa fa-times"></i></button></a>';
                                    // }
									?>
									</td>
                                    <td class="table_hide"><?php echo $value->num_items_sold; ?></td>
                                    <td class="table_hide"><input type="hidden" id="createdTime<?php echo $value->order_id; ?>"  value="<?php echo $value->date_created; ?>"></td>
                                    <td class="table_hide">
                                            <?php 
                                            $order = wc_get_order( $value->order_id );
                                            echo $order->get_subtotal(); 
                                            ?>
                                        </td>
                                        <td class="table_hide">
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'Service Fee' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo $fee_result[0]->meta_value;                                             
                                            ?>
                                        </td>
                                        <td class="table_hide">
                                            <?php 
                                            $servicefee_sql ="SELECT * FROM wp_woocommerce_order_items m2
                                            JOIN wp_woocommerce_order_itemmeta m1 ON( m1.`order_item_id` = m2.`order_item_id`)
                                            where m2.order_id ='$value->order_id' AND m2.order_item_name = 'VAT' AND m1.meta_key='_fee_amount'";
                                            $fee_result = $wpdb->get_results( $wpdb->prepare($servicefee_sql));
                                            echo $fee_result[0]->meta_value;
                                            ?>
                                        </td>
                                    <td class="table_hide"><?php echo $value->status; ?></td>
                                    <td class="table_hide"><?php echo $value->first_name; ?></td>
                                    <td class="table_hide"><?php echo $value->last_name; ?></td>
                                    <td class="table_hide"><?php echo $value->username; ?></td>
                                    <td class="table_hide"><?php echo $value->email; ?></td>
                                    <td class="table_hide"><?php echo $value->country; ?></td>
                                    <td class="table_hide"><?php echo $value->city; ?></td>
                                    <?php //foreach ($order->get_items() as $item_id => $item ) { ?>  
                                    <td class="table_hide"><?php //echo $product_name = $item->get_name(); ?> x <?php //echo $quantity = $item->get_quantity(); ?></td>    
                                    <td class="table_hide"><?php //echo $recipient = $item->get_meta( 'recipient', true ); ?></td>
                                    <td class="table_hide"><?php //echo $recipient = $item->get_meta( 'recipient_number', true ); ?></td>
                                </tr>
                                <script>
                                    function func() {
                                        var dateValue = document.getElementById("createdTime"+<?php echo $value->order_id; ?>).value;

                                        var date = Math.abs((new Date().getTime() / 1000).toFixed(0));

                                        var dates = new Date(dateValue).getTime() + (6 * 60 * 60 * 1000);
                                        date2 = Math.abs((dates / 1000).toFixed(0));

                                        var diff = date2 - date;

                                        var hours = Math.floor(diff / 3600) % 24;
                                        var minutes = Math.floor(diff / 60) % 60;
                                        var seconds = diff % 60;


                                        var hoursStr = hours;
                                        if (hours < 10) {
                                            hoursStr = "0" + hours;
                                        }

                                        var minutesStr = minutes;
                                        if (minutes < 10) {
                                            minutesStr = "0" + minutes;
                                        }

                                        var secondsStr = seconds;
                                        if (seconds < 10) {
                                            secondsStr = "0" + seconds;
                                        }

                                        if (hours < 0 && minutes < 0 && seconds < 0) {
                                            daysStr = "00";
                                            hoursStr = "00";
                                            minutesStr = "00";
                                            secondsStr = "00";

                                            console.log(hours, minutes, seconds);
                                            if (typeof interval !== "undefined") {
                                                clearInterval(interval);
                                            }
                                        }

                                        document.getElementById("remTime"+<?php echo $value->order_id; ?>).innerHTML =  hoursStr + " hours " + minutesStr + " minutes " ;
                                    }

                                    func();
                                    var interval = setInterval(func, 1000);

                                </script>
                            <?php } ?>
						</tbody>
                    </table>
                    </div>
                </div>
                </div>   
        </div>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>