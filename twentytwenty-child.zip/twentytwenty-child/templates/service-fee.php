

<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: service-fee
 */
 get_header();
?>
<div class="main-content-area">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap white_bg">
			<div class="row">
				<div class="col-12">
			
					<!-- <button class='btn pull-right rec_common_btn' id="add_service_tax" data-toggle="modal" data-target="#service_tax_model">Add Service Fee</button> -->
					
						<!--Add recipient form Modal -->
					<div class="modal fade" id="service_tax_model" data-backdrop="static" role="dialog" >
						<div class="modal-dialog">
						
						<!-- Modal content-->
						<div class="modal-content" id="model-content">
							<div class="modal-header">
							<h4 class="modal-title">Add Service Fee</h4>
							</div>
							<div class="modal-body">
								<div class="form-group">
										<label for="retailer"> Retailer</label>
									<select name="retailer" class="form-control retailer rec_common_input" id="retailer">
										<option value="0">Please Select Retailer</option>
										<?php
												global $wpdb;
												$country = array(
													'post_type' => 'product',
													'taxonomy' => 'retailer',
													'hide_empty' => false,
													'orderby' => 'name',
													'order'   => 'ASC'
													);
				
													// $countries = get_categories($country);
												$retailers = get_categories( $country );
												$retailer ="SELECT `ID`,`post_title` FROM `wp_posts` WHERE `post_type` ='product' AND `post_status`='publish' ORDER BY `post_title` ASC";
												// $retailers = $wpdb->get_results( $wpdb->prepare($retailer));                                                          
												foreach($retailers as $value) { ?>
												<option id="<?php echo $value->term_id;?>" value="<?php echo $value->term_id;?>"><?php echo $value->name;
												?></option>
											<?php } ?>
									</select>
										<span id="retailer_error" class ="service_tax_error" style="display:none;">Please select the retailer.</span>
								</div>
								<div class="form-group">
									<label for="service_fee"> Service Fee %</label>
									<input type="text" class="form-control service_fee rec_common_input" id="service_fee" placeholder="Service Fee %" required>
									<span id="service_fee_error" class ="service_tax_error" style="display:none;">Please enter the service fee.</span>
									<span id="service_fee_number_error" class ="service_tax_error" style="display:none;">Please enter the valid service fee.</span>
								</div>
								

								<div class="form-group">
									<label for="value_from"> Value From</label>
									<input type="text" class="form-control value_from rec_common_input" id="value_from" value="0.0" placeholder="Value From" >
									<span id="value_from_error" class ="service_tax_error" style="display:none;">Please enter the starting value.</span>
									<span id="value_from_number_error" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
									<span id="value_from_exist_error" class ="service_tax_error" style="display:none;">This value already exists.</span>
								</div>
									
								<div class="form-group">
									<label for="value_to"> Value To</label>
									<input type="text" class="form-control value_to rec_common_input" id="value_to" placeholder="Value To" >
									<span id="value_to_error" class ="service_tax_error" style="display:none;">Please enter the ending value.</span>
									<span id="value_to_number_error" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
									<span id="value_to_number_less_error" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
									<span id="value_to_exist_error" class ="service_tax_error" style="display:none;">This value already exists.</span>
								</div>
							</div>
							<div class="modal-footer">
								<div class="recipient_submit_btn">
									<button type="button" class="btn btn-default button rec_common_btn" id="service_fee_save" >Save</button>
									<button type="button" class="btn btn-default rec_common_btn" id="service_fee_cancel" data-dismiss="modal">Cancel</button>
								</div>
							</div>
						</div>
						
						</div>
					</div>
				</div>

				<div class="col-md-12">
					<button class='btn pull-right rec_common_btn' id="add_service_tax" data-toggle="modal" data-target="#service_tax_model">Add Service Fee</button>
					<div class="table-responsive">
						<table class="table table-bordered list_table" id ="service_fee_table">
							<thead>
								<tr>
									<!-- <th scope="col"> </th> -->
									<th scope="col" width="20%">Retailer</th>
									<th scope="col" width="15%">Service Fee</th>
									<th scope="col" width="15%">Value From</th>
									<th scope="col" width="20%">Value To</th>
									<th scope="col" width="30%">Actions</th>
								</tr>
								</thead>
								<tbody class="service_fees_table">
								<?php
								
									global $wpdb;
									
									$rec_sql ="SELECT * FROM `wp_service_fee`;";
									$recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
									foreach($recipients as $value){ ?>
										<form action="" method="POST">
										<?php
											global $wpdb;
											$country = array(
												'post_type' => 'product',
												'taxonomy' => 'retailer',
												// 'hide_empty' => false,
												'orderby' => 'name',
												'order'   => 'ASC'
												);

												// $countries = get_categories($country);
											$retailers = get_categories( $country );
											$retailer ="SELECT `post_title` FROM `wp_posts` WHERE `post_type` ='product' AND `post_status`='publish' AND `ID` = $value->retailer_id ORDER BY `post_title` ASC";
											// $retailers = $wpdb->get_results( $wpdb->prepare($retailer));    
											// print_r($retailers);
																									
										?>
												
											<tr>
											<!-- <td> </td> -->
											<td>
												<?php  
												foreach($retailers as $item){ 
													if($item->term_id == $value->retailer_id){ 
														echo $item->name; 
													}
												}?>
											</td>
											<td><?php echo $value->service_fee; ?>%</td>
											<td>R<?php echo numberformat($value->feevalue_from); ?></td>
											<td>R<?php echo numberformat($value->feevalue_to); ?></td>
											
											<td>
												
											<button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#duplicate_service_tax_model<?php echo $value->id ?>" id="<?php echo $value->id ?>" title="" data-original-title="Duplicate" class="red-tooltip"><i class="fa fa-copy"></i></button>
											<button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#update_service_tax_model<?php echo $value->id ?>" id="<?php echo $value->id ?>" title="" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>
												<button type="button" class="btn btn-danger recept_btn" name="recipient_id" data-toggle="modal" id="<?php echo $value->id ?>" title="" data-original-title="Delete" class="red-tooltip" onclick="confirmserviceDeleteModal('<?php echo $value->id ?>')"><i class="fa fa-trash"></i></button>
											</td>
											</tr>

											<!-- Update Service Modal -->
											<div class="modal fade" id="update_service_tax_model<?php echo $value->id ?>" data-backdrop="static" role="dialog" >
												<div class="modal-dialog">
													<div class="modal-content" id="model-content">
														<div class="modal-header">
														<h4 class="modal-title">Update Service Fee</h4>
														</div>
														<div class="modal-body">
														<div class="form-group">
																<label for="retailer"> Retailer</label>
															<select name="retailer_<?php echo $value->id; ?>" require class="form-control retailer rec_common_input" id="retailer_<?php echo $value->id; ?>">
															<!-- <option id="<?php echo $value->id ;?>" value="<?php echo $value->id ;?>"><?php foreach($retailers as $item){ if($item->term_id == $value->retailer_id){ echo $item->name; }}?></option> -->
																<?php
															global $wpdb;
															$country = array(
																'post_type' => 'product',
																'taxonomy' => 'retailer',
																'orderby' => 'name',
																'order'   => 'ASC'
																);
							
																// $countries = get_categories($country);
															$retailers = get_categories( $country );
															$retailer ="SELECT `ID`,`post_title` FROM `wp_posts` WHERE `post_type` ='product' AND `post_status`='publish' ORDER BY `post_title` ASC";
															// $retailers = $wpdb->get_results( $wpdb->prepare($retailer));                                                          
															foreach($retailers as $name) { ?>
															<option id="<?php echo $name->term_id;?>" <?php if($name->term_id == $value->retailer_id){echo "selected"; }?>  value="<?php echo $name->term_id;?>" name="<?php echo $name->term_id;?>"><?php echo $name->name ?></option>
														<?php } ?>
															</select>
																<span id="retailer_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please select the retailer.</span>
															</div>
															<div class="form-group">
																<label for="service_fee_<?php echo $value->id; ?>"> Service Fee %</label>
																<input type="text" class="form-control service_fee rec_common_input" id="service_fee_<?php echo $value->id; ?>" placeholder="Service Fee %" value="<?php echo $value->service_fee; ?>" required>
																<span id="service_fee_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the service fee.</span>
																<span id="service_fee_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid service fee.</span>
															</div>
															

															<div class="form-group">
																<label for="value_from_<?php echo $value->id; ?>"> Value From</label>
																<input type="text" class="form-control value_from rec_common_input" id="value_from_<?php echo $value->id; ?>" placeholder="Value From" value="<?php echo $value->feevalue_from; ?>" >
																<span id="value_from_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the starting value.</span>
																<span id="value_from_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="value_from_exist_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">This value already exists.</span>
															</div>
															
															<div class="form-group">
																<label for="value_to_<?php echo $value->id; ?>"> Value To</label>
																<input type="text" class="form-control value_to rec_common_input" id="value_to_<?php echo $value->id; ?>" placeholder="Value To" value="<?php echo $value->feevalue_to; ?>" >
																<span id="value_to_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the ending value.</span>
																<span id="value_to_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="value_to_number_less_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="value_to_exist_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">This value already exists.</span>
															</div>
														</div>
														<div class="modal-footer">
															<div class="recipient_submit_btn">
																<button type="button" class="btn btn-default button rec_common_btn" id="service_fee_update_<?php echo $value->id; ?>" onclick="updateServiceModal('<?php echo $value->id; ?>')" >Update</button>
																<button type="button" class="btn btn-default rec_common_btn" id="service_fee_cancel_<?php echo $value->id; ?>" data-dismiss="modal">Cancel</button>
															</div>
														</div>
													</div>
												</div>
											</div>
											<!-- Update Service Modal -->
											<!-- Duplicate Service Modal -->
											<div class="modal fade" id="duplicate_service_tax_model<?php echo $value->id ?>" data-backdrop="static" role="dialog" >
												<div class="modal-dialog">
													<div class="modal-content" id="model-content">
														<div class="modal-header">
														<h4 class="modal-title">Duplicate Service Fee</h4>
														</div>
														<div class="modal-body">
														<div class="form-group">
																<label for="retailer"> Retailer</label>
															<select name="duplicate_retailer_<?php echo $value->id; ?>" require class="form-control retailer rec_common_input" id="duplicate_retailer_<?php echo $value->id; ?>">
															<!-- <option id="<?php echo $value->id ;?>" value="<?php echo $value->id ;?>"><?php foreach($retailers as $item){ if($item->term_id == $value->retailer_id){ echo $item->name; }}?></option> -->
																<?php
															global $wpdb;
															$country = array(
																'post_type' => 'product',
																'taxonomy' => 'retailer',
																'orderby' => 'name',
																'order'   => 'ASC'
																);
							
																// $countries = get_categories($country);
															$retailers = get_categories( $country );
															$retailer ="SELECT `ID`,`post_title` FROM `wp_posts` WHERE `post_type` ='product' AND `post_status`='publish' ORDER BY `post_title` ASC";
															// $retailers = $wpdb->get_results( $wpdb->prepare($retailer));                                                          
															foreach($retailers as $name) { ?>
															<option id="<?php echo $name->term_id;?>" <?php if($name->term_id == $value->retailer_id){echo "selected"; }?>  value="<?php echo $name->term_id;?>" name="<?php echo $name->term_id;?>"><?php echo $name->name ?></option>
														<?php } ?>
															</select>
																<span id="duplicate_retailer_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please select the retailer.</span>
															</div>
															<div class="form-group">
																<label for="duplicate_service_fee_<?php echo $value->id; ?>"> Service Fee %</label>
																<input type="text" class="form-control service_fee rec_common_input" id="duplicate_service_fee_<?php echo $value->id; ?>" placeholder="Service Fee %" value="<?php echo $value->service_fee; ?>" required>
																<span id="duplicate_service_fee_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the service fee.</span>
																<span id="duplicate_service_fee_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid service fee.</span>
															</div>
															

															<div class="form-group">
																<label for="duplicate_value_from_<?php echo $value->id; ?>"> Value From</label>
																<input type="text" class="form-control value_from rec_common_input" id="duplicate_value_from_<?php echo $value->id; ?>" placeholder="Value From" value="<?php echo $value->feevalue_from; ?>" >
																<span id="duplicate_value_from_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the starting value.</span>
																<span id="duplicate_value_from_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="duplicate_value_from_exist_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">This value already exists.</span>
															</div>
															
															<div class="form-group">
																<label for="duplicate_value_to_<?php echo $value->id; ?>"> Value To</label>
																<input type="text" class="form-control value_to rec_common_input" id="duplicate_value_to_<?php echo $value->id; ?>" placeholder="Value To" value="<?php echo $value->feevalue_to; ?>" >
																<span id="duplicate_value_to_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the ending value.</span>
																<span id="duplicate_value_to_number_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="duplicate_value_to_number_less_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">Please enter the valid value.</span>
																<span id="duplicate_value_to_exist_error_<?php echo $value->id; ?>" class ="service_tax_error" style="display:none;">This value already exists.</span>
															</div>
														</div>
														<div class="modal-footer">
															<div class="recipient_submit_btn">
																<button type="button" class="btn btn-default button rec_common_btn" id="duplicate_service_fee_update_<?php echo $value->id; ?>" onclick="duplicateServiceModal('<?php echo $value->id; ?>')" >Duplicate</button>
																<button type="button" class="btn btn-default rec_common_btn" id="duplicate_service_fee_cancel_<?php echo $value->id; ?>" data-dismiss="modal">Cancel</button>
															</div>
														</div>
													</div>
												</div>
											</div>
											<!-- Duplicate Service Modal -->
										</form>
										<?php } ?>
								</tbody>
							</table>
					</div>
			
				<!-- <a href="<?php echo get_home_url(); ?>" id="return_to_order" class='btn pull-right rec_common_btn'>Return to orders</a> -->
				</div>
			</div>
        </div>
    </div>
</div>

<!-- Recipient delete Modal -->
<div id="serviceDeleteModal" class="modal fade" role='dialog'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title">Delete </h4>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this item?</p>
                
            </div>
            <div class="modal-footer">
                <button id='deletecancel' type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <span id= 'serviceDeleteButton'></span>
            </div>
            
        </div>
    </div>
</div>

<div id="overlay">
    <div class="cv-spinner">
        <span class="spinner"></span>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); }?>