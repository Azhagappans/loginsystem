

<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: vat-fee
 */
 get_header();
?>
<div class="main-content-area">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap white_bg vat_white_bg">
           
                <div class="row">
                    <div class="col-12">
                        <!-- <button class='btn pull-right rec_common_btn' id="add_vat_rate" data-toggle="modal" data-target="#vat_rate_model">Add VAT</button> -->
                            <!--Add recipient form Modal -->
                        <div class="modal fade" id="vat_rate_model" data-backdrop="static" role="dialog" >
                            <div class="modal-dialog"> 
                            <!-- Modal content-->
                            <div class="modal-content" id="model-content">
                                <div class="modal-header">
                                <h4 class="modal-title">Add VAT</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="vat_rate"> VAT RATE %</label>
                                        <input type="number" class="form-control rec_common_input" id="vat_rate" placeholder="VAT Rate" required>
                                        <span id="vat_rate_error" class ="vat_rate_error update_num_error" style="display:none;">Please enter the VAT%.</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="vat_date_from"> Date from</label>
                                        <input type="text" class="form-control rec_common_input vat_date_field" id="vat_date_from" placeholder="Choose any date" required>
                                        <span id="vat_date_from_error" class ="vat_date_from_error update_num_error" style="display:none;">Please choose starting date.</span>
                                        <span id="vat_date_from_exist_error" class ="vat_date_from_error update_num_error" style="display:none;">This date already exists.</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="vat_date_to"> Date to</label>
                                        <input type="text" class="form-control rec_common_input vat_date_field" id="vat_date_to" placeholder="Choose any date">
                                        <span id="vat_date_to_error" class ="vat_date_to_error update_num_error" style="display:none;">Please choose ending date.</span>
                                        <span id="vat_date_to_exist_error" class ="vat_date_from_error update_num_error" style="display:none;">This date already exists.</span>
                                    </div>
                                    
                                </div>
                                <div class="modal-footer">
                                    <div class="recipient_submit_btn">
                                        <button type="button" class="btn btn-default button rec_common_btn" id="save_vat" >Save</button>
                                        <button type="button" class="btn btn-default rec_common_btn" id="recipient_cancel" data-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                            </div>
                            
                            </div>
                        </div>
                    </div>
                    <br> <br> <br>
                    <div class="col-12">
                    <button class='btn pull-right rec_common_btn' id="add_vat_rate" data-toggle="modal" data-target="#vat_rate_model">Add VAT</button>
                        <div class="table-responsive">
                        <table class="table table-bordered list_table" id ="vat_table">
                            <thead>
                            <tr>
                                <!-- <th scope="col"> </th> -->
                                <th scope="col" width="20%">VAT Rate</th>
                                <th scope="col" width="20%">Date From</th>
                                <th scope="col" width="20%">Date To</th>
                                <th scope="col" width="20%">Actions</th>
                                <th scope="col" width="20%" class="table_hide">Vat Id</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            
                                global $wpdb;
                                
                                $rec_sql ="SELECT * FROM `wp_vat` ORDER BY `id` DESC;";
                                $recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
                                foreach($recipients as $value){ ?>
                                    <form action="" method="POST">
                                    <?php
                                        global $wpdb;
                                        $retailer ="SELECT `post_title` FROM `wp_posts` WHERE `post_type` ='product' AND `post_status`='publish' AND `ID` = $value->retailer_id ORDER BY `post_title` ASC";
                                        $retailers = $wpdb->get_results( $wpdb->prepare($retailer));                                                          
                                    ?> 
                                            
                                        <tr>
                                        <!-- <td> </td> -->
                                        <td><?php echo  $value->vat_rate; ?></td>
                                        <td><?php echo $value->date_from; ?></td>
                                        <td><?php echo $value->date_to; ?></td>
                                        <td class="table_hide"><?php echo $value->id; ?></td>
                                        <td>
                                        <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" data-target="#update_vat_rate_model<?php echo  $value->id; ?>" id="edit_<?php echo  $value->id; ?>" title="" onclick="editModal('<?php echo  $value->id; ?>')" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>
                                        <button type="button" class="btn btn-danger recept_btn" name="recipient_id" data-toggle="modal" id="<?php echo  $value->id; ?>" title="" data-original-title="Delete" class="red-tooltip" onclick="confirmVatDeleteModal('<?php echo  $value->id; ?>')"><i class="fa fa-trash"></i></button></td>
                                        </tr>

                                        <!-- Recipient details Modal -->
                                        <div class="modal fade" id="update_vat_rate_model<?php echo  $value->id; ?>" data-backdrop="static" role="dialog" >
                                            <div class="modal-dialog"> 
                                            <!-- Modal content-->
                                                <div class="modal-content" id="model-content">
                                                    <div class="modal-header">
                                                    <h4 class="modal-title">Update VAT</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="vat_rate_<?php echo  $value->id; ?>"> VAT RATE %</label>
                                                            <input type="number" class="form-control rec_common_input" id="vat_rate_<?php echo  $value->id; ?>" placeholder="VAT RATE" value="<?php echo $value->vat_rate; ?>" required>
                                                            <span id="vat_rate_error_<?php echo  $value->id; ?>" class ="vat_rate_error update_num_error" style="display:none;">Please enter the VAT%.</span>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="vat_date_from_<?php echo  $value->id; ?>"> Date from</label>
                                                            <input type="text" class="form-control rec_common_input vat_date_field" id="vat_date_from_<?php echo  $value->id; ?>" value="<?php echo $value->date_from; ?>" required>
                                                            <span id="vat_date_from_error_<?php echo  $value->id; ?>" class ="vat_date_from_error update_num_error" style="display:none;">Please choose starting date.</span>
                                                            <span id="vat_date_from_exist_error_<?php echo  $value->id; ?>" class ="vat_date_from_error update_num_error" style="display:none;">This date already exists.</span>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="vat_date_to_<?php echo  $value->id; ?>"> Date to</label>
                                                            <input type="text" class="form-control rec_common_input vat_date_field" id="vat_date_to_<?php echo  $value->id; ?>" value="<?php echo $value->date_to; ?>">
                                                            <span id="vat_date_to_error_<?php echo  $value->id; ?>" class ="vat_date_to_error update_num_error" style="display:none;">Please choose ending date.</span>
                                                            <span id="vat_date_to_exist_error_<?php echo  $value->id; ?>" class ="vat_date_from_error update_num_error" style="display:none;">This date already exists.</span>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="modal-footer">
                                                        <div class="recipient_submit_btn">
                                                            <button type="button" class="btn btn-default button rec_common_btn" id="update_vat" onclick="updateVatModal('<?php echo $value->id; ?>')">Update</button>
                                                            <button type="button" class="btn btn-default rec_common_btn" id="recipient_update_cancel" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Recipient details Modal -->
                                    </form>
                                    <?php } ?>
                            </tbody>
                        </table>
                        </div>
                        <!-- <a href="<?php echo get_home_url(); ?>" id="return_to_order" class='btn pull-right rec_common_btn'>Return to orders</a> -->
                    </div>
                </div>
              
        </div>
    </div>
</div>

<!-- Recipient delete Modal -->
<div id="vatDeleteModal" class="modal fade" role='dialog'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title">Delete </h4>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this item?</p>
                
            </div>
            <div class="modal-footer">
                <button id='deletecancel' type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <span id= 'vatDeleteButton'></span>
            </div>
            
        </div>
    </div>
</div>
<div id="overlay">
    <div class="cv-spinner">
        <span class="spinner"></span>
    </div>
</div>
<!-- Recipient delete Modal -->
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/log-in/'); }?>