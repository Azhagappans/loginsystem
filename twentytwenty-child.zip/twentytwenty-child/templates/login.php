<?php 
if (!get_current_user_id()) {
	// display navbar here
 ?>
<?php get_header('login'); ?>
<?php 
/*
Template Name: login
*/
$logo = get_field('login_logo','option');
$title = get_field('page_title','option');
?>
<section class="login-screen">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <div class="login-wrapper">
                    <div class="logo-wrap">
                        <?php if($logo) { ?><a href="#"><img src="<?php echo $logo; ?>" class="img-fluid"></a><?php }; ?>
                        <!-- <a href="#"><img src="<?php get_stylesheet_directory_uri(); ?>/assets/images/logo-login.png" class="img-fluid"></a> -->
                    </div>
                    <h2><?php echo get_the_title(); ?></h2>
                   <?php echo do_shortcode(get_the_content()); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('http://202.129.196.139:3444/voucher/'); }?>