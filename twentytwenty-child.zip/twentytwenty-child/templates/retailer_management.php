

<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: retailer_management
 */
 get_header();

if(isset($_GET['d']) && !empty($_GET['d'])){
    wp_delete_term( base64_decode($_GET['d']), 'retailer' );
    echo '<script>window.location.href="'.home_url().'/retailer-management/";</script>';
    exit;
}
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
            <div class="">
                <div class="row">
                    <div class="col-12">
                        <table cellspacing="5" cellpadding="5" class="borderless">
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
        <div class="">
            <div class="row">
                <div class="col-12">
                <button class='btn pull-right rec_common_btn add_retailer_btn' id="add_retailer" onclick="add_retailer()">Add Retailer</button>
					<table class="table table-bordered list_table retailer-table"  id="retailer-table">
                        <thead>
                            <tr>
                                <th scope="col" width="20%" id="firstNameCol">Retailer Name</th>
                                <th scope="col" width="20%" id="surnameCol">Sales Contact Person</th>
                                <th scope="col" width="20%" id="dateCreated">Contact Number</th>
                                <!-- <th scope="col" width="20%" id="lastOrderDate">Count</th> -->
                                <th scope="col" width="0%" class="table_hide" id="">Description</th>
                                <th scope="col" width="0%" class="table_hide" id="">Order Lead Time</th>
                                <th scope="col" width="0%" class="table_hide" id="">Voucher Denominations</th>
                                <th scope="col" width="0%" class="table_hide" id="">Name of Bank</th>
                                <th scope="col" width="0%" class="table_hide" id="">Branch</th>
                                <th scope="col" width="0%" class="table_hide" id="">Account Type</th>
                                <th scope="col" width="0%" class="table_hide" id="">Account Number</th>
                                <th scope="col" width="0%" class="table_hide" id="">Branch Code</th>
                                <th scope="col" width="20%" class="noExport" id="valueLastOrder">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                global $wpdb;
                                $data = array(
									'post_type' => 'product',
									'taxonomy' => 'retailer',
									'orderby' => 'name',
                                    'hide_empty'=> false,
									'order'   => 'ASC'
									);

								$retailers = get_categories($data);
                                /*echo "<pre>";
                                print_r($retailers);
                                echo "</pre>";*/
                                foreach($retailers as $term){
                                    if(!empty($term->name)){
                                ?>
                                        <tr>
                                            <td><?php echo $term->name; ?></td>
                                            <td><?php echo get_field('sales_contact_person', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td><?php echo get_field('contact_number', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <!-- <td><?php echo $term->count; ?></td> -->

                                            <td class="table_hide"><?php echo $term->description; ?></td>
                                            <td class="table_hide"><?php echo get_field('order_lead_time', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('voucher_denominations', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('name_of_bank', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('branch', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('account_type', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('account_number', $term->taxonomy.'_'.$term->term_id); ?></td>
                                            <td class="table_hide"><?php echo get_field('branch_code', $term->taxonomy.'_'.$term->term_id); ?></td>

                                            <td>
                                                <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" onclick="retailer_management('<?php echo $term->term_id; ?>')" id="<?php echo $term->term_id; ?>" title="" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>
                                                <?php
                                                if($term->count == 0){
                                                ?>
                                                 <button type="button" class="btn btn-success recipient_update recept_btn delete_retailer" data-toggle="modal" data-deleteurl="<?php echo home_url(); ?>/retailer-management/?d=<?php echo base64_encode($term->term_id); ?>" data-count="<?php echo $term->count; ?>" title="" data-original-title="Delete" class="red-tooltip"><i class="fa fa-trash"></i></button>
                                                <?php
                                                }
                                                ?>
                                        </tr>
                                    <?php 
                                    }  
                                } ?>
						</tbody>
                    </table>
                    </div>
                </div>
                </div>   
        </div>
    </div>
</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect('localhost/voucher/log-in/'); }?>