<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package voucher
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Specification Voucher System</title>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="profile" href="http://gmpg.org/xfn/11"> -->
<?php wp_head();  



$custom_logo_id = get_theme_mod( 'custom_logo' );
  $image = wp_get_attachment_image_src( $custom_logo_id, 'full');
  $first_name = wp_get_current_user()->user_firstname;
  $lastname = wp_get_current_user()->user_lastname;
  $username = wp_get_current_user()->display_name; 
  $title = get_the_title();?>
</head>
<body>



	<section class="page-wrapper">
		<?php get_sidebar(); ?>
		
<div class="main-page-wrapper min-sidebar">
			<div class="cus-header">
				<div class="row">
					<div class="col-xl-6 col-lg-5">
						<div class="page-title">
							<h2>Virtual <span class="cus-heading-color">Vouchers</span></h2>
							<?php if($title) {  if($title == "test"){ echo "<h4>Place New Order</h4>";} else{ ?><h4><?php echo $title; ?></h4><?php }}; ?>
						</div>
					</div>
					<div class="col-xl-6 col-lg-7">
						<div class="header-right">
							
							<div class="help-wrapper">
								<div class="help-icon">
									<a href="#" data-toggle="modal" data-target="#help"><span class="fa fa-info"></span></a>
								</div>
							</div>
							<div class="profile-wrap">
								<div class="dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<div class="profile-name">
										<?php if($first_name) { echo $first_name; ?> 
										<?php echo $lastname; } else { ?> 
										<?php echo $username; } ?>
										<?php /* <span><?php echo wp_get_current_user()->roles[0]; ?></span>*/ ?>
									</div>
									</a>
									<div class="dropdown-menu fade" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="<?php echo get_home_url(); ?>/my-account/edit-account"><span class="fa fa-user-o"></span>My Profile</a>
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="http://202.129.196.139:3444/voucher/sample-page/?redirect_to=http://202.129.196.139:3444/voucher/log-in/"><span class="fa fa-sign-out"></span>Log Out</a>
									</div>
								</div>
							</div>
							<div class="mob-toggle">
								<span><i class="fa fa-bars" aria-hidden="true"></i></span>
							</div>
						</div>
							
					</div>
				</div>
			</div>

			<div class="help-sidebar">
			<div class="close">
				<span class="fa fa-times"></span>
			</div>
			<div class="help-wrapper">
				<h2>Help</h2>
					<?php wp_nav_menu( array('menu-name' => 'help-menu',
					'menu_class'      => 'list-unstyled',
					'rewrite'   => array( 'slug' => '/', 'with_front' => false ), 
					) ); ?>
			</div>
		</div>