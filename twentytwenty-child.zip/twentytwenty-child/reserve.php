<?php
/**
* Template Name: reserve
 */

global $wpdb;
$order_id = 1055;
	$order = wc_get_order($order_id);
	$items = $order->get_items();
	// print_r($items);
	//getting all line items
	foreach ($order->get_items() as $item_id => $item) {
		// print_r($item);
		$recipient_name = $item->get_meta('recipient');
		$recipient_number = $item->get_meta('recipient_number');
		$personalized = $item->get_meta('personalized');
		// echo "reere";
		$voucher_amount = $item->get_total();
		// print_r($voucher_amount);
		// exit;
		$user = $order->get_user();
		$display_name = $user->display_name;

		$product = $item->get_product();
		$product_id = null;
		$product_sku = null;
		// Check if the product exists.
		if (is_object($product)) {

			$product_id = $product->get_id();

			$test = get_post_meta($product_id, 'vouchers');
			$keyCount = $test[0]."<br>";

			$voucherArray = array();
			for($i=0; $i<$keyCount; $i++) {
				//echo $i." "; 
				$reserved_meta_key = 'vouchers_'.$i.'_reserved';
				$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
				$expiry_date_field_value = '';

				$status_meta_key = 'vouchers_'.$i.'_status';
				$status_field_value = get_post_meta($product_id, $status_meta_key, true);

				if($reserved_field_value == '0' && $status_field_value == '2') {
					$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
					$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);

					$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
					$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
					
					$i." - ".$reserved_field_value." - ".$expiry_date_field_value."<br>";
					$voucherArray[$i]['key'] = $i;
					$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
					$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
				}			
			}

			
		}
		// print_r($voucherArray);
		// exit;
	
		// echo "<br>After Sorting : <br>";
		// Sort the array 
		usort($voucherArray, 'date_compare');
		
		// Print the array
		// echo "test";
		// print_r($voucherArray); 
		// echo "<br>";

		$qty = $item->get_quantity();
		// echo "Qty Based Record <br>";
		$pdt_code = array();
		$exp_date = array();
		for($j = 0; $j < $qty; $j++) {
			// print_r($voucherArray[$j])."<br>";

			$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
			$product_id;
			// update_post_meta($product_id, $updateReserved, "3" );
			$pdt_code[] = $voucherArray[$j]['voucher_number'];
			// echo $voucherArray[$j]['expiry_date'];
			
			$newDate = date("d-m-Y", strtotime($voucherArray[$j]['expiry_date']));
			$exp_date[] = $newDate;
		}
		$voucher_code = implode(", ", $pdt_code);
		print_r($exp_date[0]);

		if($exp_date[0] == ""){
			$exp_date[0] = "00/00/00";
		}
		

		// $voucher_number = get_post_meta($product_id ,'voucher_number');
		$term_obj_list = get_the_terms( $product_id, 'retailer' );
		$retailer_name =  $term_obj_list[0]->name;
		
		// require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');
		// // Your Account SID and Auth Token from twilio.com/console
		// $account_sid = 'ACc7020830ee8e933353c573aaa1633141';
		// $auth_token = 'ecf9978c42f130334a48ed8f3605f0bb';
		// // In production, these should be environment variables. E.g.:
		// // $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
		// // A Twilio number you own with SMS capabilities
		// $twilio_number = "+27600197711";
		// $client = new Client($account_sid, $auth_token);
		// if($personalized == "Yes"){
		// 	$client->messages->create(
		// 		// Where to send a text message (your cell phone?)
		// 		"'+27'.$recipient_number",
		// 		array(
		// 			'from' => $twilio_number,
		// 			'body' => "$recipient_name,you have received a $voucher_amount voucher from $display_name for $retailer_name in the amount of . Your voucher number is $voucher_code"
		// 		)
		// 	);
		// }elseif($personalized == "No"){
		// 	$client->messages->create(
		// 		// Where to send a text message (your cell phone?)
		// 		"'+27'.$recipient_number",
		// 		array(
		// 			'from' => $twilio_number,
		// 			'body' => "$recipient_name,you have received a voucher for $retailer_name in the amount of $voucher_amount. Your voucher number is $voucher_code"
		// 		)
		// 	);
		// }
	}