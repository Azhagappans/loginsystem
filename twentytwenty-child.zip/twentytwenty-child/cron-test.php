<?php
/**
* Template Name: cron-test
 */
global $wpdb;
$order_id = "1226";
	$order = wc_get_order($order_id);
	$items = $order->get_items();
	$date = $order->get_date_created("M d, YY");
	$order_Date = date("F d, Y", strtotime($date));  
	// print_r($items);
    // exit;
	//getting all line items
    $mail_array = array();
	foreach ($order->get_items() as $item_id => $item) {
		// echo $item_id;
		// echo "<br>";
		$recipient_name = $item->get_meta('recipient');
		$recipient_number = $item->get_meta('recipient_number');
		$personalized = $item->get_meta('personalized');
		$product_name = $item->get_name();
		$voucher_amount = $item->get_total();
		// echo $price = $item->get_total();
		// print_r($voucher_amount);
		// exit;
		$user = $order->get_user();
		$display_name = $user->display_name;

		$product = $item->get_product();
		$product_id = null;
		$product_sku = null;
		// Check if the product exists.
		if (is_object($product)) {

			$product_id = $product->get_id();
			$price = get_post_meta($product_id , '_price', true);
			$test = get_post_meta($product_id, 'vouchers');
			$keyCount = $test[0]."<br>";

			$voucherArray = array();
			for($i=0; $i<$keyCount; $i++) {
				//echo $i." "; 
				$reserved_meta_key = 'vouchers_'.$i.'_reserved';
				$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
				$expiry_date_field_value = '';

				$status_meta_key = 'vouchers_'.$i.'_status';
				$status_field_value = get_post_meta($product_id, $status_meta_key, true);

				if($reserved_field_value == '0' && $status_field_value == '2') {
					$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
					$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);
					if($expiry_date_field_value == ""){
						$expiry_date_field_value = "00/00/00";
					}

					$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
					$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
					
					$i." - ".$reserved_field_value." - ".$expiry_date_field_value."<br>";
					$voucherArray[$i]['key'] = $i;
					$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
					$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
				}			
			}

			
		}
		// print_r($voucherArray);
	
		// echo "<br>After Sorting : <br>";
		// Sort the array 
		usort($voucherArray, 'date_compare');
		
		// Print the array
		// print_r($voucherArray); echo "<br>";

		$qty = $item->get_quantity();
		// echo "Qty Based Record <br>";
		$pdt_code = array();
		$exp_date = array();
		// foreach($voucherArray as $key => $value)	{
			for($j = 0; $j < $qty; $j++) {
				// print_r($voucherArray[$j])."<br>";

				$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
				$product_id;
				// update_post_meta($product_id, $updateReserved, "3" );
				$pdt_code[] = $voucherArray[$j]['voucher_number'];
				if($voucherArray[$j]['expiry_date'] == "00/00/00"){
					$exp_date[] = "00/00/00";
				}else{
					$newDate = date("d-m-Y", strtotime($voucherArray[$j]['expiry_date']));
					$exp_date[] = $newDate;
				}
			}
		// }
		$voucher_code = implode(", ", $pdt_code);
		$exp_date = implode(", ", $exp_date);

		// $voucher_number = get_post_meta($product_id ,'voucher_number');
		$term_obj_list = get_the_terms( $product_id, 'retailer' );
		$retailer_name =  $term_obj_list[0]->name;
		
		require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');
		
		$account_sid = 'ACc7020830ee8e933353c573aaa1633141';
		$auth_token = 'ecf9978c42f130334a48ed8f3605f0bb';
		// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
		$twilio_number = "+27600197711";
		// $client = new Client($account_sid, $auth_token);
        
		
		// $mail_array['title'] = $title;
		// $mail_array['recipient_name'][] = $recipient_name;
		// $mail_array['recipient_number'][] = $recipient_number;
		// $mail_array['voucher_number'][] = $voucher_code;
		// $mail_array['qty'][] = $qty;
		$product_id = $item['product_id'];		
		$terms = get_the_terms($product_id, 'retailer');
		$product_cat = "";
		foreach($terms as $term) {
			$product_cat = $term->name;
			// $mail_array['pdt_cat'] = $product_cat;
		}
		$mail_array[] = array( 
			"title" => $product_name,
			"recipient_name" => $recipient_name,
			"recipient_number" => $recipient_number,
			"voucher_number" => $voucher_code,
			"price" => $price,
			"qty" => $qty,
			"pdt_cat" => $product_cat,
		);
	}
   
    $to = $order->get_billing_email();
	$subject = "Your Virtual Vouchers order has been received!";
	$txt = "<table id='template_container' style='background-color: #ffffff; border: 1px solid #dedede; box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1); border-radius: 3px;' width='600' cellspacing='0' cellpadding='0' border='0'>
	<tbody><tr>
		<td valign='top' align='center'>
			<table id='template_header' style='background-color: #96588a; color: #ffffff; border-bottom: 0; font-weight: bold; line-height: 100%; vertical-align: middle; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; border-radius: 3px 3px 0 0;' width='100%' cellspacing='0' cellpadding='0' border='0'>
				<tbody><tr>
					<td id='header_wrapper' style='padding: 36px 48px; display: block;'>
						<h1 style='font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;'>Thank you for your order</h1>
					</td></tr></tbody></table></td></tr><tr><td valign='top' align='center'><table id='template_body' width='600' cellspacing='0' cellpadding='0' border='0'><tbody><tr><td id='body_content' style='background-color: #ffffff;' valign='top'><table width='100%' cellspacing='0' cellpadding='20' border='0'><tbody><tr><td style='padding: 48px 48px 32px;' valign='top'><div id='body_content_inner' style='color: #636363; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-size: 14px; line-height: 150%; text-align: left;'><p style='margin: 0 0 16px;'>Hi ,</p><p style='margin: 0 0 16px;'>Just to let you know — we've received your order #".$order_id.", and it is now being processed:</p>

					<h2 style='color: #96588a; display: block; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-align: left;'>
					[Order #".$order_id."] (".$order_Date.")</h2>

					<div style='margin-bottom: 40px;'>
					<table class='td' style='color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;' cellspacing='0' cellpadding='0' border='0'>
					<thead>
					<tr><th class='td' scope='row' colspan='2' style='color: #636363; vertical-align: middle; padding: 12px; text-align: left; border-top-width: 4px;'>Vocuher Deatils</th>
					<th class='td' scope='col' style='color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;'>Quantity</th>
					<th class='td' scope='col' style='color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;'>Price</th></tr></thead>
				<tbody>";
		foreach($mail_array as $val){
		 $txt .= "<tr class='order_item' style='line-height:20px;'>
		<td class='td' style='color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word;'>
		<ul class='wc-item-meta' style='font-size: small; margin: 1em 0 0; padding: 0; list-style: none;'>
		
		<li style='margin: 0.5em 0 0; padding: 0;'>
		<strong class='wc-item-meta-label' style='float: left; margin-right: .25em; clear: both;'>Voucher:</strong> <p style='margin: 0;'>".$val['title']."</p></li>
		<li style='margin: 0.5em 0 0; padding: 0;'>
		<strong class='wc-item-meta-label' style='float: left; margin-right: .25em; clear: both;'>Retailer:</strong> <p style='margin: 0;'>".$val['pdt_cat']."</p></li>
		<li style='margin: 0.5em 0 0; padding: 0;'>
		<strong class='wc-item-meta-label' style='float: left; margin-right: .25em; clear: both;'>Recipient Name:</strong> <p style='margin: 0;'>".$val['recipient_name']."</p></li>
		<li style='margin: 0.5em 0 0; padding: 0;'>
		<strong class='wc-item-meta-label' style='float: left; margin-right: .25em; clear: both;'>Recipient Number:</strong> <p style='margin: 0;'>".$val['recipient_number']."</p></li>
		<li style='margin: 0.5em 0 0; padding: 0;'>
		<strong class='wc-item-meta-label' style='float: left; margin-right: .25em; clear: both;'>Voucher Number:</strong> <p style='margin: 0;'>".$val['voucher_number']."</p></li>
		</ul>
		</td><td></td>
		<td class='td' style='color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;'>".$val['qty']."</td>
		<td class='td' style='color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word;'><ul class='wc-item-meta' style='font-size: small; margin: 1em 0 0; padding: 0; list-style: none;'>".$val['price']*$val['qty']."</td></tr>";
		}
		$txt .= "</tbody></table><table style='float:right';>";
		foreach($order->get_order_item_totals() as $orderDetail) {
			$txt .= "<tr><td class='td' style='color: #636363; vertical-align: middle; padding: 12px; text-align: left; border-top-width: 4px;float:right;'><span class='woocommerce-Price-amount amount'><span class='woocommerce-Price-currencySymbol'></span>".$orderDetail['value']."</span></td><td class='td' scope='row' colspan='2' style='color: #636363; vertical-align: middle; padding: 12px; text-align: left; border-top-width: 4px; float:right;'>".$orderDetail['label']."</td></tr>";
		}
		$txt .= "</table>";
		echo $txt .="</div></div></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>";
		$headers[] = 'Content-type: text/html; charset=utf-8';
		// echo $file_path = '/voucher/wp-admin/admin-ajax.php?action=generate_wpo_wcpdf&document_type=invoice&order_ids=1226&_wpnonce=0b757fb6e3';
		// $attachment = $file_path;
		// if ( !is_object( $order ) || !isset( $email_id ) ) {
		// 	 			return $attachments;
		// 	  		}
		wp_mail("azhagappan.s@cgvakindia.com", $subject, $txt, $headers,$attachments);
	
    // print_r($mail_array);
	// echo json_encode($mail_array['title']);	
	

?>

