<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: Import and Export
 */
get_header();
global $wpdb;

$error_message = '';
$voucher_err = '';

if (isset($_POST["Upload"])){

   if (isset($_FILES["file"])){

        $target_dir = realpath(__DIR__)."/uploads/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        } 

        $name = $_FILES["file"]["name"];
        $ext = end((explode(".", $name))); # extra () to prevent notice
        if($ext == 'csv'){
            $file = fopen($target_file,"r");
            $i = 1;
            $c = 0;
            $one_insert = 0;
            $product_id_count = array();
            $product_meta_array = array();
            $terms_err = '';
            $s = 1;
            while (($data = fgetcsv($file)) !== FALSE)
            {
                if (array(null) !== $data) { // ignore blank lines
                    if($i>1){
                        $terms = $data[0];
                        // Get term by name ''news'' in Custom taxonomy.
                        $check_term = get_term_by('name', $terms, 'retailer');
                        
                        //echo $data[2].'bb<br>';

                        if(!empty($check_term)){

                            $replaces =  str_replace("R","",$data[2]);
                            $replace =  'R'.$replaces;
                            $product_check = get_posts(array(
                                                      'post_type' => 'product',
                                                      'numberposts' => -1,
                                                      'fields'=> 'ids',
                                                      'post_status' => "publish",
                                                      's' => $replace,
                                                      'tax_query' => array(
                                                        array(
                                                          'taxonomy' => 'retailer',
                                                          'field' => 'name', 
                                                          'terms' => $check_term,
                                                        )
                                                      )
                                                    ));
                            $product_id = '';
                            if(isset($product_check[0])){
                                $product_id = $product_check[0];
                            }

                            if(!empty($data[2])){
                                    if (!$product_id):
                                        $post = [
                                            'post_author' => '',
                                            'post_content' => '',
                                            'post_status' => "publish",
                                            'post_title' => wp_strip_all_tags($replace),
                                            'post_name' => $replace,
                                            'post_parent' => '',
                                            'post_type' => "product",
                                        ];
                                        //Create Post
                                        $product_id = wp_insert_post($post, $wp_error);
                                        //set Product Category
                                        wp_set_object_terms($product_id, $data[0], 'retailer');
                                        //set product type
                                        wp_set_object_terms($product_id, 'simple', 'product_type');
                                        //update_post_meta($product_id, '_sku', $product['sku']);
                                        update_post_meta($product_id, 'total_sales', '0');

                                    //product found
                                    else:
                                        $existing_product = get_posts(array(
                                                      'post_type' => 'product',
                                                      'numberposts' => -1,
                                                      'tax_query' => array(
                                                        array(
                                                          'taxonomy' => 'retailer',
                                                          'field' => 'name', 
                                                          'terms' => $data[0],
                                                        )
                                                      )
                                                    ));

                                        if(!empty($existing_product)){
                                            $post = [
                                                'ID' => $product_id,
                                                'post_title' => $replace,
                                                'post_name' => $replace,
                                                'post_content' => '',
                                            ];
                                            $product_id = wp_update_post($post, true);
                                        }else{
                                            $post = [
                                            'post_author' => '',
                                            'post_content' => '',
                                            'post_status' => "publish",
                                            'post_title' => wp_strip_all_tags($replace),
                                            'post_name' => $replace,
                                            'post_parent' => '',
                                            'post_type' => "product",
                                            ];
                                            //Create Post
                                            $product_id = wp_insert_post($post, $wp_error);
                                            //set Product Category
                                            wp_set_object_terms($product_id, $data[0], 'retailer');
                                            //set product type
                                            wp_set_object_terms($product_id, 'simple', 'product_type');
                                            update_post_meta($product_id, '_sku', '');
                                            //update_post_meta($product_id, 'total_sales', '0');
                                        }

                                    endif;
                                    
                                    $price =  str_replace("R","",$data[2]);

                                    $product_meta_array[$product_id]['line_number'][] = $s;
                                    $product_meta_array[$product_id]['value'][] = $data[2];
                                    $product_meta_array[$product_id]['retailer'][] = $data[0];

                                    $product_meta_array[$product_id]['voucher_number'][] = $data[1];
                                    $product_meta_array[$product_id]['expiry_date'][] = $data[3];
                                    $product_meta_array[$product_id]['pin_number'][] = $data[4];
                                    if(strtolower($data[5]) == 'yes'){
                                        $status = 1;
                                    }else{
                                        $status = 0;
                                    }
                                $product_meta_array[$product_id]['reserved'][] = $status;
                                $product_meta_array[$product_id]['status'][] = 1;

                                update_post_meta($product_id, '_price', $price);
                                update_post_meta($product_id, '_regular_price', $price);
                                update_post_meta($product_id, '_visibility', 'visible');
                                update_post_meta($product_id, '_stock_status', 'instock');
                                update_post_meta($product_id, '_product_attributes', array());
                                update_post_meta($product_id, '_manage_stock', "yes");
                                update_post_meta($product_id, '_backorders', "no");

                                                                
                                $c++;
                                $one_insert = 1;
                            }
                        }else{
                            //if($terms_err == ''){
                                //$terms_err = $data[0];
                                $terms_err .= '<tr><td>'.$s.'</td><td>Retailer not exist</td><td>'.$data[0].'</td><td>'.$data[2].'</td><td>'.$data[1].'</td></tr>';
                           // }else{
                               // $terms_err = $terms_err.', '.$data[0];
                            //}
                        }
                    }
                    $i++;
                    $s++; 
                }
            }
            $product_err_number = '';
            $voucher_err_number = '';
            $voucher_err_number_tr = '';
            $product_err_number_tr = '';

            if(isset($product_meta_array) && !empty($product_meta_array)){
                foreach($product_meta_array as $productid=>$meta){
                    if(isset($meta['voucher_number']) && !empty($meta['voucher_number'])){
                        $already_count = $wpdb->get_results("SELECT meta_value FROM $wpdb->postmeta WHERE (post_id = '".$productid."' AND meta_key = 'vouchers')");
                        
                        if(isset($already_count[0]->meta_value) && !empty($already_count[0]->meta_value)){
                            $voucher_count = $already_count[0]->meta_value;

                        }else{
                            $voucher_count = 0;
                        }
                        $qty_count = 0;
                        
                        foreach($meta['voucher_number'] as $key=>$value){
                            if(!empty($value)){
                                $check_voucher = $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE ( meta_value = '".$value."')");
                        
                                if(isset($check_voucher[0]) && !empty($check_voucher[0])){
                                    if(isset($value) && !empty($value)){
                                        if($voucher_err_number == ''){
                                            $voucher_err_number = $value;
                                        }else{
                                            $voucher_err_number = $voucher_err_number.', '.$value;
                                        }
                                        $voucher_err_number_tr .= '<tr><td>'.$meta['line_number'][$key].'</td><td>Duplicate voucher number</td><td>'.$meta['retailer'][$key].'</td><td>'.$meta['value'][$key].'</td><td>'.$value.'</td></tr>';
                                    }
                                }else{
                                    update_post_meta($productid, 'vouchers_'.$voucher_count.'_voucher_number', $value);
                                    update_post_meta($productid, '_vouchers_'.$voucher_count.'_voucher_number', 'field_60fec0bee33f5');

                                    update_post_meta($productid, 'vouchers_'.$voucher_count.'_expiry_date', $meta['expiry_date'][$key]);
                                    update_post_meta($productid, '_vouchers_'.$voucher_count.'_expiry_date', 'field_60f5859e4bae1');

                                    update_post_meta($productid, 'vouchers_'.$voucher_count.'_pin_number', $meta['pin_number'][$key]);
                                    update_post_meta($productid, '_vouchers_'.$voucher_count.'_pin_number', 'field_60f585ba4bae2');

                                    update_post_meta($productid, 'vouchers_'.$voucher_count.'_reserved', $meta['reserved'][$key]);
                                    update_post_meta($productid, '_vouchers_'.$voucher_count.'_reserved', 'field_60f585e04bae3');

                                    update_post_meta($productid, 'vouchers_'.$voucher_count.'_status', 1);
                                    update_post_meta($productid, '_vouchers_'.$voucher_count.'_status', 'field_613258e860ce0');

                                    $voucher_count++;
                                    $already_stock = get_post_meta( $productid, '_stock', true );
                                    if(!empty($already_stock)){
                                        update_post_meta($productid, '_stock', $already_stock+1);
                                    }else{
                                        update_post_meta($productid, '_stock', 1);
                                    }
                                    $one_insert = 1;
                                }
                                
                            }else{
                                 if($product_err_number == ''){
                                    $product_err_number = $productid;
                                }else{
                                    $product_err_number = $product_err_number.', '.$productid;
                                }
                                $product_err_number_tr .= '<tr><td>'.$meta['line_number'][$key].'</td><td>Vocuher Number Missing</td><td>'.$meta['retailer'][$key].'</td><td>'.$meta['value'][$key].'</td><td>'.$value.'</td></tr>';
                            }
                        }
                        $voucher_counts[$productid] = $voucher_count;    
                    }else{
                    }
                }
                $error_message .= '<span class="success-mesage"><strong>Product imported successfully.</strong></span><br>';
            }
        }else{
            $error_message .= '<span class="success-mesage"><strong>Please upload the right format(csv)</strong></span><br>';
            unlink($target_file);
        }
        
        $voucher_err = '';
        $product_err = '';
        $terms_error_err = '';
       /* if($terms_err != ''){
            $terms_error_err .= '<table class="error-table table table-bordered list_table dt-responsive display nowrap voucher-number-issue-table" id="voucher-number-issue-table"><thead><tr><th>Line Number</th><th>Error</th><th>Retailer</th><th>Value</th><th>Voucher Number</th></tr></thead><tbody>';
            $terms_error_err .= $voucher_err_number_tr;
            $terms_error_err .= '</tbody></table>';
        }*/
        if($voucher_err_number != '' || $terms_err != '' || $product_err_number_tr){
            //$voucher_err .= 'The following voucher numbers are already exist<br>';
            $voucher_err .= '<table class="error-table table table-bordered list_table dt-responsive display nowrap voucher-number-issue-table" id="voucher-number-issue-table"><thead><tr><th>Line Number</th><th>Error</th><th>Retailer</th><th>Value</th><th>Voucher Number</th></tr></thead><tbody>';
            $voucher_err .= $voucher_err_number_tr.$terms_err.$product_err_number_tr;
            $voucher_err .= '</tbody></table>';

        }
        /*if($product_err_number != ''){
            $product_err .= 'The following products required voucher number<br>';
            $product_err .= '<table class="error-table table table-bordered list_table dt-responsive display nowrap voucher-number-required-table" id="voucher-number-required-table"><thead><tr><th>Line Number</th><th>Error</th><th>Retailer</th><th>Value</th><th>Voucher Number</th></tr></thead><tbody>';
            $product_err .= $product_err_number_tr;
            $product_err .= '</tbody></table>';

        }
        */
        if(isset($voucher_counts) && !empty($voucher_counts)){
            foreach($voucher_counts as $key=>$value){
                update_post_meta($key, 'vouchers', $value);
                update_post_meta($key, '_vouchers', 'field_612f97c106839');           
            }
        }
        
    }else{
         echo "No file selected <br />";
    }
}

if($error_message != '' ){
?>
<style type="text/css">
.import_export{
    top: 14px ;
}
.error-message{
    min-height: 90px;
    margin-top: 30px;
}
</style>
<?php
}
?>

<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">


            <!-- <div class="container" style="position: relative;padding-top: 10px;"> -->
                <div class="error-message">
                    <?php echo $error_message; ?>
                   
                </div>
                <form action="" method="post" class="import_export" name="import_file_form" enctype="multipart/form-data">
                    <div class="row" style ="margin:10px;">                   
                        <div class="form-group" style="margin-right:10px;">
                            <!-- <label for="import">Upload CSV File<span class="text-danger"> * </span></label><br> -->
                            <input type="file" class="form-control" name="file" id="files" placeholder="Upload CSV File" accept=".csv">
                        </div>
                        <div class="form-group">
                            <label for="import" style="visibility: hidden;">submit</label>
                            <input type="submit" class="form-control" name="Upload"  id="upload_submit" value="Upload" style="line-height:0;">
                        </div>                      
                    </div>
                </form>

                <div class="row" style="margin:0;">
                    <div class="col-12">
                        <div class="table-responsive">
                            <?php
                            echo $voucher_err;
                            echo $product_err;
                            ?>
                            <table class="table table-bordered list_table dt-responsive display nowrap inventory-table"  id="inventory-table">
                                <thead>
                                    <tr>
                                        <th scope="col" width="20%" id="deliveryDate">Product Id</th>
                                        <th scope="col" width="20%" id="contactName">Retailer</th>
                                        <th scope="col" width="20%" id="contactPhn">Value</th>
                                        <th scope="col" width="20%" id="contactMail">Stock</th>
                                        <th scope="col" width="20%" class="actions" >Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $args = array( 'post_type' => 'product',
                                            'posts_per_page' => -1,
                                            'orderby'   => array(
                                                                'date' =>'DESC',
                                                                'menu_order'=>'ASC',
                                                                ));
                                    $loop = new WP_Query( $args );
                                    while ( $loop->have_posts() ) : $loop->the_post();
                                    global $product;
                                    $post_id = get_the_ID();
                                    $currency = get_woocommerce_currency_symbol();
                                    $stock_count = '';
                                    $voucher_data = get_field('vouchers', $post_id);
                                    $c = 0;
                                    if(!empty($voucher_data)){
                                        foreach($voucher_data as $data){
                                            if($data['status'] == 1 || strtolower($data['status']) == 'available'){
                                                $stock_count = ++$c;
                                            }
                                        }
                                    }
                                    ?>

                                    <tr>
                                        <td><?php echo $post_id; ?></td>
                                        <td>
                                            <?php 
                                            $terms = get_the_terms( $post_id , 'retailer' );
                                            $retailer_name =  $terms[0]->name;
                                            echo $retailer_name; ?>
                                        </td>
                                        <td data-search="<?php 
                                        if(!empty($product->price)){
                                            echo $currency.$product->price;
                                        }else{
                                            echo "-";
                                        }
                                        ?>">
                                        <?php 
                                        if(!empty($product->price)){
                                            echo $currency.numberformat($product->price);
                                        }else{
                                            echo "-";
                                        }
                                        ?>
                                    </td>
                                        <td>
                                            <?php 
                                            if(!empty($stock_count)){
                                                echo $stock_count;
                                            }else{
                                                echo "-";
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                                $retail_link = admin_url().'post.php?post='.$post_id.'&action=edit';
                                            ?>
                                            <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" onclick="window.location.href='<?php echo home_url(); ?>/report/?productid=<?php echo base64_encode($post_id); ?>;'" id="<?php echo ($post_id); ?>" title="" data-original-title="View" class="red-tooltip"><i class="fa fa-eye"></i></button>
                                            
                                            <button type="button" class="btn btn-success recipient_update recept_btn" data-toggle="modal" onclick="window.open('<?php echo $retail_link; ?>')" id="<?php echo ($post_id); ?>" title="" data-original-title="Edit" class="red-tooltip"><i class="fa fa-edit"></i></button>
                                        </td>
                                    </tr>
                                                                      
                                <?php 
                                endwhile;
                                wp_reset_query(); ?>
                                </tbody>
                            </table>

                            <table class="table table-bordered inventory-table-export"  id="inventory-table-export" style="display:none;">
                                <thead>
                                    <tr>
                                        <th class="table_hide">Retailer</th>
                                        <th class="table_hide">Voucher Number</th>
                                        <th class="table_hide">Value</th>
                                        <th class="table_hide">Expiry Date</th>
                                        <th class="table_hide">Pin Number</th>
                                        <th class="table_hide">Bulk Reserved</th>
                                        <th class="table_hide">Status</th>  
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $args = array( 'post_type' => 'product',
                                            'posts_per_page' => -1,
                                            'orderby'   => array(
                                                                'date' =>'DESC',
                                                                'menu_order'=>'ASC',
                                                                ));
                                    $loop = new WP_Query( $args );
                                    while ( $loop->have_posts() ) : $loop->the_post();
                                    global $product;
                                    $post_id = get_the_ID();
                                    $currency = get_woocommerce_currency_symbol();
                                    
                                    $voucher_data = get_field('vouchers', $post_id);
                                    if(!empty($voucher_data)){
                                        foreach($voucher_data as $data){
                                        ?>

                                            <tr>
                                                <td>
                                                    <?php 
                                                    $terms = get_the_terms( $post_id , 'retailer' );
                                                    $retailer_name =  $terms[0]->name;
                                                    echo $retailer_name; ?>
                                                </td>
                                                <td><?php echo $data['voucher_number']; ?></td>
                                                <td data-search="<?php 
                                                    if(!empty($product->price)){
                                                        echo $currency.$product->price;
                                                    }else{
                                                        echo "-";
                                                    }
                                                    ?>">
                                                    <?php 
                                                    if(!empty($product->price)){
                                                        echo $currency.numberformat($product->price);
                                                    }else{
                                                        echo "-";
                                                    }
                                                    ?>
                                                </td>
                                                <td><?php echo $data['expiry_date']; ?></td>
                                                <td><?php echo $data['pin_number']; ?></td>
                                                <td><?php if($data['reserved'] == 1){ echo 'Yes';} if($data['reserved'] == 0){ echo 'No';} ?></td>
                                                <td><?php if($data['status'] == 1){ echo 'Available';} if($data['status'] == 2){ echo 'On Hold';} ?><?php if($data['status'] == 3){ echo 'Sold';} if($data['status'] == 4){ echo 'Expired';} ?></td>
                                            </tr>                                
                                        <?php
                                        }
                                    }
                                endwhile;
                                wp_reset_query(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            <!-- </div>    -->
        </div>
    </div>
</div>

<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>