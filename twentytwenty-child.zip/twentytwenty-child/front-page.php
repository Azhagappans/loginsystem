<?php
/**
* Template Name: Place-order
 */
?>
<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>

<?php get_header();

if(isset($_POST['contact_name']) &&  !empty($_POST['contact_name']) && isset($_POST['your_message']) && !empty($_POST['your_message'])){
	require_once('insert_bulk_order.php');
}



global $current_user;

$cart_product = array();
foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
	if(isset($cart_item['product_id'])){
		$cart_product[$cart_item['product_id']] = $cart_item['quantity'];
	}
}	
?> 
<div class="main-content-area">
				<div class="page-inner-wrapper">
					<div class="place-new-order-page">
						<form class="form">
							<div class="row">
								<div class="col-md-6">
									<div class="white-bg-wrap">
										<h2 style = "display:block !important;">Choose recipient</h2>
										<div class="row">
											<div class="col-lg-6 col-md-12">
												<div class="form-group lg-mb-0">
													<!-- <label><span class="star">*</span> Choose Recipient </label> -->
													<div class="select-wrap ">
														<span class="fa fa-angle-down"></span>
														<select class="custom-select form-control recipient" name="recipient" id="recipient">
                                                            <option id="0">Please Select</option>
															<option id="<?php echo wp_get_current_user()->user_firstname; ?>"  value="<?php echo get_current_user_id(); ?>" data-id="<?php echo wp_get_current_user()->mobile_number;?>">Send to Self</option>
                                                            <?php
                                                            global $wpdb;
															$current_user_id = get_current_user_id();
															$rec_sql ="SELECT * FROM `wp_recipients` WHERE `rec_user_id` ='$current_user_id' AND `active_status` ='Yes' ORDER BY `recipient_name`";
															$recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));
															// print_r($recipients);                                                            
                                                    
															foreach($recipients as $value) { ?>
																<option id="<?php echo $value->recipient_name;?>" value="<?php echo $value->recipient_id;?>" data-id="<?php echo $value->recipient_number;?>"><?php echo $value->recipient_name;?></option>
															<?php } ?>
														</select>
														<div id ="recipient_error" style="display:none;color:red;">Please choose Valid Recipient</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-12 personalize_radio">
												<div class="form-group lg-mb-0">
													<label class="no-top">Personalize</label>
													<div class="two-fields">
														<div class="field">
															<div class="form-group">
																<div class="custom-control custom-checkbox">
																	<input type="radio" id="active_yes" name="active" value="Yes">
																	<label class="custom-control-label" for="customCheck">Yes</label>
																</div>
															</div>
														</div>
														<div class="field">
															<div class="form-group">
																<div class="custom-control custom-checkbox">
																	<input type="radio" id="active_no" name="active" value="No">
																	<label class="custom-control-label" for="customCheck">No</label>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<a href="/voucher/my-recipients/" id="add-recipient" class="btn add-recipient btn-primary" >Add Recipient</a>
										</div>
										
									</div>
								</div>
								<div class="col-md-6 voucher_select_div">
									<div class="white-bg-wrap">
										<h2 style = "display:block !important;">Select Voucher</h2>
										<div class="row">
											<div class="col-lg-6 col-md-12" id="retailer-tooltip" data-toggle="tooltip" data-placement="top" title="Select Recipient First.">
												<div class="form-group lg-mb-0">
													<!-- <label><span class="star">*</span>Select Voucher</label>  -->
													<div class="select-wrap ">
														<span class="fa fa-angle-down"></span>
														<select class="custom-select form-control retailer disabled" disabled id="retailer">
														<option value="0">Please Select Retailer</option>
															<?php
															global $wpdb;
															$retailers = get_terms( 'retailer', array(
																		'hide_empty' => true,
																		'post_type' => 'product',
																		'orderby' => 'name',
																		'order'   => 'ASC',
																		) );
                                                    
															foreach($retailers as $value) {
																$all_products = get_posts( array(
																				    'post_type' => 'product',
																				    'numberposts' => -1,
																				    'post_status' => 'publish',
																				    'orderby' => 'meta_value_num',
																				    'meta_key' => '_price',
																				    'order' => 'asc',
																				    'tax_query' => array(
																				        array(
																				            'taxonomy' => 'retailer',
																				            'field' => 'term_id',
																				            'terms' => $value->term_id, /*category name*/
																				            'operator' => 'IN',
																				            )
																				        ),
																				    ));
																$isavalible = false;
																if(isset($all_products) && !empty($all_products)){
																	foreach($all_products as $products){
																		$stock = get_post_meta( $products->ID, '_stock', true );
																		$stock_ava = true;
																		if($stock_ava == true){
																			$vouchers = get_field('vouchers', $products->ID);
																			//echo "<pre>";print_r($vouchers);echo "</pre>";
																			if(isset($vouchers) && !empty($vouchers)){
																				foreach($vouchers as $voucher){
																					$status = $voucher['status'];
	    																			$reserved = $voucher['reserved'];
	    																			//echo $status.'<br>';
	    																			if($status == 1 && $reserved == 0){
	    																				$isavalible = true;
	    																			}
																				}
																			}
																		}
																	}
																}
																if($isavalible == true){
															?>
																<option id="<?php echo $value->term_id;?>" value="<?php echo $value->term_id;?>"><?php echo $value->name;
																?></option>
															<?php
																}
															}
														?>
														</select>
														<div id ="retialer_error" style="display:none;color:red;">Please choose Valid Retailer</div>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-12 " id="value-tooltip" data-toggle="tooltip" data-placement="top" title="Select Retailer First.">
												<div class="form-group ">
													<!-- <label><span class="star">*</span>Choose value</label> -->
													<div class="select-wrap ">
														<span class="fa fa-angle-down"></span>
														<select class="custom-select form-control voucher_price disabled" disabled id="voucher_price">
														<option id="0">Please Select Value</option>
														</select>
														<div id ="voucher_error" style="display:none;color:red;">Please select voucher value</div>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="row mt-2">
													<div class="col-lg-6 col-md-12">
														<p class="info-text mb-0 available_count"></p>
														<div class="input-group quantity_area"  style="display:none;">
															<span class="input-group-btn">
																<button type="button" class="quantity-left-minus btn btn-danger btn-number"  data-type="minus" data-field="">
																<span class="glyphicon glyphicon-minus"></span>
																</button>
															</span>
															<input type="text" id="quantity" onkeyup="this.value=this.value.replace(/[^\d]/,'')" name="quantity" class="form-control input-number quantity" value="1" min="1" >
															<span class="input-group-btn" id="pluscount-max-limit" data-toggle="tooltip" data-placement="top" title="">
																<button type="button" class="quantity-right-plus btn btn-success btn-number" data-type="plus" data-field="">
																	<span class="glyphicon glyphicon-plus"></span>
																</button>
															</span>
														</div>

													</div>
													<div class="col-lg-6 col-md-12">
														<div class="page-button-wrapper mb-0 cart_btn">
														<!-- <span class ="fa fa-plus"></span> -->
															<button href="#" class="um-button addcart_btn link-button-blue" id="buy" onclick="add_cart()" disabled="disabled">Add</button>
														</div>
													</div>
												</div>
											</div>
										</div>
										
									</div>
								</div>
							</div>
							<div class="row space-30"></div>
						</form>
						<div class="voucher-display">
							<div class="white-bg-wrap">
								<div class="row">
									<div class="col-md-12">
										<?php /*
									<form name="checkout" method="post" class="checkout" action="<?php echo esc_url( $get_checkout_url ); ?>">
									<?php $order_button_text = __("Save Order", "woocommerce"); echo apply_filters( 'woocommerce_order_button_html', '<button type="submit" class="button alt" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr( $order_button_text ) . '" data-value="' . esc_attr( $order_button_text ) . '" style="float:right;">' . esc_html( $order_button_text ) . '</button>' );  */ ?>
									<!-- <div class="form-row place-order">
										<input
										type="submit" class="button alt" name="woocommerce_checkout_place_order"
										id="place_order" value="Place order" data-value="Place order" />

									</div> -->
										
										<div class="page-button-wrapper checkout_btn">
										<a href="#" id="bulk_order" class="btn btn-primary bulk_order" data-toggle="modal" data-target="#bulkordermodal">Special Order</a>
										<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>"id="checkout-button" class="checkout-button button alt wc-forward um-button">
											<?php esc_html_e( 'Checkout', 'woocommerce' ); ?></a>
										</div>
									<!-- </div>
									<div class="col-md-12"> -->
										<!--Bulk Order Modal -->
										<div class="modal fade" data-backdrop="static" id="bulkordermodal" role="dialog">
											<div class="modal-dialog">

											<!-- Modal content-->
											<div class="modal-content">
											<div class="modal-header">
											<h4 class="modal-title">Bulk Order Enquiry</h4>
											 </div>
											<div  style=" margin:auto; width:90%;">
												<h4 >
													Please provide us with your details and requirements and we will get back to you.
												</h4>	
											</div>
											<div class="subhead" style="margin-left:25px;">
												<h4  style="font-size:12px;">
													This enquiry form is for when you require:<br>
													<ul style=" margin-right:auto; ">
														<li style="font-size:12px;">
														more than 50 identical vouchers (same retailer and value) or,
														</li>
														<li style="font-size:12px;">
														vouchers from a retailer or for a value not listed.
														</li>
													</ul>
												</h4>
											</div>
											 <div class="modal-body">
											<?php //echo do_shortcode('[contact-form-7 id="515" title="Bulk order"]'); ?>
											<form action="" method="post" name="bulk_order_form" id="bulk_order_form">
												<p>
													<label>Contact Person<br>
														<input type="text" name="contact_name" value="<?php echo $current_user->data->display_name; ?>" size="40" class="wpcf7-form-control wpcf7-text contact_name" />
													</label>
												</p>
												<p>
													<label>Contact email<br>
														<input type="email" name="contact_email" value="<?php echo $current_user->data->user_email; ?>" class="wpcf7-form-control wpcf7-text contact_email" >
													</label>
												</p>
												<p>
													<label>Contact Phone Number<br>
														<input type="text" name="contact_phone" value="<?php echo wp_get_current_user()->mobile_number; ?>" class="wpcf7-form-control wpcf7-text contact_phone" >
													</label>
												</p>
												<p>
													<label>Expected Delivery Date<br>
														<input type="text" name="expected_date" value="" class="wpcf7-form-control wpcf7-text expected_date datepicker" data-date-format="mm/dd/yyyy" >
													</label>
												</p>
												<p><label> Your message<br>
											    	<span><i> Please specify Retailer, value of vouchers and quantity required</i> </span><br>
											    	<textarea name="your_message" cols="40" rows="40" class="wpcf7-form-control wpcf7-textarea your_message" ></textarea></label>
												</p>
												<p><input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit bulk_order_submit"><span class="ajax-loader"></span></p>
											</form>
											</div>

											</div>

											</div>
                               			</div>
                            <!--Bulk Order Modal -->

										<div class="table-responsive up_btn_remove">
										<?php echo do_shortcode('[woocommerce_cart]'); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="overlay">
				<div class="cv-spinner">
					<span class="spinner"></span>
				</div>
			</div>
<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>

<script type="text/javascript">
$('.datepicker').datepicker({
    //startDate: '-3d'
});
</script>
