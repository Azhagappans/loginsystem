<?php
// Email field in profile form
add_filter( 'um_user_profile_restricted_edit_fields', 'my_restrict_content_hide_metabox', 10, 1 );
function my_restrict_content_hide_metabox(
 $show ) {
    // your code here
   $arr_restricted_fields = array( 'username', 'user_login', 'user_password', '_um_last_login' );
return $arr_restricted_fields;
}

// Custom-Logo
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 190,
			'width'       => 190,
			'flex-width'  => false,
			'flex-height' => false,
		)
	);
	add_action( 'wp_enqueue_scripts', 'tt_child_enqueue_parent_styles' );
	
// Custom-Logo

	function tt_child_enqueue_parent_styles() {
	    wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
        wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri() .'/assets/css/bootstrap.min.css' );
        wp_enqueue_style( 'gfont', 'https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,500;0,600;0,700;0,800;1,200&display=swap' );
        wp_enqueue_style( 'font-awesome-style', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );
        wp_enqueue_style( 'main-style', get_stylesheet_directory_uri() .'/assets/css/style.css' );
		wp_enqueue_style( 'new-style', get_stylesheet_directory_uri() .'/assets/css/prasanth-style.css' );
        wp_enqueue_style( 'prasanna-style', get_stylesheet_directory_uri() .'/assets/css/custom_style.css' );
        wp_enqueue_style( 'country-style', get_stylesheet_directory_uri() .'/assets/css/jquery-countryselector.min.css' );
        wp_enqueue_style( 'cus-min-style', get_stylesheet_directory_uri() .'/assets/css/cus-min.css' );

		// Datatable CSS
		wp_enqueue_style( 'datatable_css', 'https://nightly.datatables.net/css/jquery.dataTables.css' );
		wp_enqueue_style( 'btn_css', 'https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css' );
		wp_enqueue_style( 'datatable-style', 'https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css' );
		wp_enqueue_style( 'datatable_btn_cdn', 'https://cdn.datatables.net/buttons/1.1.0/js/dataTables.buttons.min.js' );
		wp_enqueue_style( 'datetime-style', 'https://cdn.datatables.net/datetime/1.1.0/css/dataTables.dateTime.min.css' );
		wp_enqueue_style( 'responsive_css', 'https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.css' );

        wp_enqueue_style( 'woo-style', get_stylesheet_directory_uri() .'/assets/css/custom.css' );
        wp_enqueue_style( 'cdn-boot-style','https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css' );
        wp_enqueue_script('jquery');
		
		// Datables Scripts
		wp_enqueue_script('tel1', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', array(), '1.0.0', true );
		wp_enqueue_script('tel1', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js', array(), '1.0.0', true );
		wp_enqueue_style( 'tel-css', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css' );
		wp_enqueue_script('jquery_cdn', 'https://code.jquery.com/jquery-3.5.1.js', array(), '1.0.0', true );
		wp_enqueue_script('export_datatable_cdn', 'https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js', array(), '1.0.0', true );
		wp_enqueue_script('export_dt_btn', 'https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js', array(), '1.0.0', true );
		wp_enqueue_script('export_jszip', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js', array(), '1.0.0', true );
		wp_enqueue_script('export_pdfmake', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', array(), '1.0.0', true );
		wp_enqueue_script('export_vfs', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', array(), '1.0.0', true );
		wp_enqueue_script('export_btn', 'https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js', array(), '1.0.0', true );
		wp_enqueue_script('export_print', 'https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js', array(), '1.0.0', true );
		wp_enqueue_script('responsive_js', 'https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.js', array(), '1.0.0', true );


        wp_enqueue_script('date-cdn', 'https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js', array(),'1.0.0', true );
        wp_enqueue_script('1-cdn', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(),'1.0.0', true );
        wp_enqueue_script('2-cdn', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js', array(),'1.0.0', true );
        wp_enqueue_script('custom-cdn', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js', array(),'1.0.0', true );
        wp_enqueue_script('sweet-alert', 'https://unpkg.com/sweetalert2@7.20.1/dist/sweetalert2.all.js');
        wp_enqueue_style('modal-style-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');
        wp_enqueue_script('modal-js', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
        wp_enqueue_script('modal-pop-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js');
        wp_enqueue_script('modal-pop-js', 'https://code.jquery.com/jquery-1.11.3.min.js');
        wp_enqueue_script( 'vaildation-min-js', get_stylesheet_directory_uri() . '/assets/js/jquery.validate.min.js', array(),'1.0.0', true);
        wp_enqueue_script('bootstrap-js', get_stylesheet_directory_uri() .'/assets/js/bootstrap.min.js', array(),'1.0.0', true );
        wp_enqueue_script('custom-js', get_stylesheet_directory_uri() .'/assets/js/script.js', array(),'1.0.0', true );
        wp_enqueue_script('new-custom-js', get_stylesheet_directory_uri() .'/assets/js/prasanth-script.js', array(),'1.0.0', true );
        wp_enqueue_script('country-script-js', get_stylesheet_directory_uri() .'/assets/js/jquery.countrySelector.js', array(),'1.0.0', true );
        wp_enqueue_script('country-js', get_stylesheet_directory_uri() .'/assets/js/countries.js', array(),'1.0.0', true );
		wp_enqueue_script('datatable_js', 'https://nightly.datatables.net/js/jquery.dataTables.js', array(), '1.0.0', true );	
		// wp_enqueue_script('jquery_csv_cdn', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js', array(), '1.0.0', true );
    	wp_enqueue_script('moment_cdn', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js', array(), '1.0.0', true );
    	wp_enqueue_script('datetime_cdn', 'https://cdn.datatables.net/datetime/1.1.0/js/dataTables.dateTime.min.js', array(), '1.0.0', true );
    	wp_enqueue_script('js_datepicker_cdn', 'http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js', array(), '1.0.0', true );
    	wp_enqueue_script('btn_cdn', 'https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.js', array(), '1.0.0', true );
		wp_enqueue_script('jquery_export_cdn', 'https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js', array(), '1.0.0', true );
    	wp_enqueue_script('jquery_button_cdn', 'https://cdn.datatables.net/buttons/1.5.1/js/buttons.colVis.min.js', array(), '1.0.0', true );
		wp_enqueue_script('custom-js', get_template_directory_uri() .'/assets/js/script.js', array(), '1.0.0', true );
		wp_enqueue_script( 'btn_flash_js', 'https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js', array(), '1.0.0', true );
        wp_enqueue_script('custom-script-js', get_stylesheet_directory_uri() .'/assets/js/custom_script.js', array(),'1.0.0', true );
        
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }
        if ( !is_admin() ) {
            wp_enqueue_script( 'my-script-handle1', get_stylesheet_directory_uri() . '/assets/js/voucher.js', array(), '', true);
        //passing variables to the javascript file
        wp_localize_script('my-script-handle1', 'frontEndAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php'),
            'nonce' => wp_create_nonce('ajax_nonce')));
			
			wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css', array(), '', true);
        //passing variables to the javascript file
        wp_localize_script('bootstrap-style', 'frontEndAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php'),
            'nonce' => wp_create_nonce('ajax_nonce')));

			wp_enqueue_style( 'main-style', get_stylesheet_directory_uri() . '/assets/css/main.css', array(), '', true);
        //passing variables to the javascript file
        wp_localize_script('main-style', 'frontEndAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php'),
            'nonce' => wp_create_nonce('ajax_nonce')));
        }


	}

// Generating theme options page
add_action('acf/init', 'my_acf_op_init');

function wpse_enqueue_datepicker() {
    // Load the datepicker script (pre-registered in WordPress).
    wp_enqueue_script( 'jquery-ui-datepicker' );

    // You need styling for the datepicker. For simplicity I've linked to the jQuery UI CSS on a CDN.
    wp_register_style( 'jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css' );
    wp_enqueue_style( 'jquery-ui' );  
}
add_action( 'wp_enqueue_scripts', 'wpse_enqueue_datepicker' );

function my_acf_op_init() {

    if( function_exists('acf_add_options_page') ) {
	
		acf_add_options_page(array(
			'page_title' 	=> 'Theme General Settings',
			'menu_title'	=> 'Theme Settings',
			'menu_slug' 	=> 'theme-general-settings',
			'capability'	=> 'edit_posts',
			'redirect'		=> false
		));
	}
}

// Filter vouchers from recipient starts
function voucherlist(){
	$recipient = sanitize_text_field($_POST["recipient"]);
	$query = new WP_Query( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'tax_query'      => array( array(
			'taxonomy'   => 'product_cat',
			'field'      => 'term_id',
			// 'terms'      => $recipient,
		) )
	) );

	echo json_encode($query->posts);
	wp_die();
}
add_action( 'wp_ajax_nopriv_voucherlist', 'voucherlist' );
add_action( 'wp_ajax_voucherlist', 'voucherlist' );
// Filter vouchers from recipient ends

// Filter price from vouchers starts
function pricelist(){
	$post_id = sanitize_text_field($_POST["voucher"]);
	global $wpdb;

	$all_products = get_posts( array(
    'post_type' => 'product',
    'numberposts' => -1,
    'post_status' => 'publish',
    //'orderby' => 'meta_value_num',
    //'meta_key' => '_price',
    'order' => 'asc',
    'tax_query' => array(
        array(
            'taxonomy' => 'retailer',
            'field' => 'term_id',
            'terms' => $post_id, /*category name*/
            'operator' => 'IN',
            )
        ),
    ));
    $avalible_products = array();
    $options = '';
    $cart_product = array();
	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		if(isset($cart_item['product_id'])){
			$cart_product[$cart_item['product_id']] = $cart_item['quantity'];
		}
	}

    if(isset($all_products) && !empty($all_products)){
    	foreach($all_products as $products){
    		$vocuhers = get_field('vouchers',$products->ID);
    		if(isset($vocuhers) && !empty($vocuhers)){
    			$i = 0;
    			foreach($vocuhers as $vocuher){
    				$status = $vocuher['status'];
    				$reserved = $vocuher['reserved'];
    				//echo $reserved."reserved ";
    				//echo $status."status "; 
    				if(($status == 1 && $reserved == 0) || (strtolower($data['status']) == 'available' && $reserved == 0) ){
    					$_product = wc_get_product( $products->ID );
    					$avalible_products[$products->ID]['ID'] = $products->ID;
    					$avalible_products[$products->ID]['price'] = $_product->get_price();
    					$avalible_products[$products->ID]['count'] = ++$i;
    				}
    			}
    		}
    	}
    }

    if(isset($avalible_products) && !empty($avalible_products)){
		foreach($avalible_products as $product){
			$stock_ava = true;
			if(isset($cart_product[$product['ID']])){
				if($cart_product[$product['ID']] >= $product['count']){
					$stock_ava = false;
				}else{
					$product['count'] = $product['count']-$cart_product[$product['ID']];
				}
			}
			if($stock_ava == true){
				$options .= '<option id="'.$product['ID'].'" data-count="'.$product['count'].'" value="'.$product['ID'].'">'.$product['price'].'</option>';
			}
		}
    }else{
    	echo '0';
    }
   
   	echo $options;
	wp_die();
}

add_action( 'wp_ajax_nopriv_bulk_order_import_add', 'bulk_order_import_add' );
add_action( 'wp_ajax_bulk_order_import_add', 'bulk_order_import_add' );
//Add product to cart session starts
function bulk_order_import_add(){
	global $woocommerce;
	global $wpdb;
	if(! WC()->cart->is_empty() ){
        // WC()->cart->empty_cart();
	}
	$tablename = $wpdb->prefix.'users';
    $query_sql ="SELECT *  FROM $tablename where ID=".$_POST['bulk_order_user'];
    $bulk_order = $wpdb->get_results( $wpdb->prepare($query_sql));
    $username = '';
    $contact_phone = '';
    $contact_user_id = '';
    //echo "<pre>"; print_r($bulk_order); echo "</pre>";
    if(isset($bulk_order[0]->ID)){
    	$all_meta_for_user = get_user_meta($bulk_order[0]->ID);
  		
    	$username = $bulk_order[0]->display_name;
    	$contact_phone = '';
    	if(isset($all_meta_for_user['mobile_number'][0])){
    		$contact_phone = $all_meta_for_user['mobile_number'][0];
    	}
    	$contact_email = $bulk_order[0]->user_email;
    	$contact_user_id = $bulk_order[0]->ID;
    }
	$custom_data = array();
	if(isset($_POST['jsondata']) && !empty($_POST['jsondata'])){
		foreach($_POST['jsondata'] as $key=>$value){
			
			$qty = count($_POST['jsondata'][$key]);
			$custom_data['bulk_orders'] = $value;
			$custom_data['order_type'] = 'bulk order';
			$custom_data['add_size'] = array('recipient'=> $username ,'recipient_email'=> $contact_email ,'recipient_number'=> $contact_phone, 'personalized'=>'', 'contact_user_id' =>$contact_user_id);
			$woocommerce->cart->add_to_cart($key,$qty, '0', array(), $custom_data );
		}
	}
	WC()->session->set( 'session_order_type', 'bulk order');
	echo $woocommerce->cart->cart_contents_count;
	exit;
	
}

add_action( 'wp_ajax_nopriv_pricelist', 'pricelist' );
add_action( 'wp_ajax_pricelist', 'pricelist' );
// Filter price from vouchers end

//Add product to cart session starts
function add_cart(){
	$product_id = sanitize_text_field($_POST["productid"]);
	$user_custom_data_name = sanitize_text_field($_POST["recipient"]);
	$user_custom_data_number = sanitize_text_field($_POST["rec_number"]);
	$store_id = sanitize_text_field($_POST["store_id"]);
	$retid = sanitize_text_field($_POST["retid"]);
	$quantity = sanitize_text_field($_POST["quantity"]);
	$personalized = sanitize_text_field($_POST["personalized"]);
	// session_start();
    // $_SESSION['wdm_user_custom_data'] = $user_custom_data_values;
    // die();
	
	$count = get_post_meta($product_id ,'_stock'); 
	if($count[0] >= $quantity){

	
		$product_cart_id = WC()->cart->generate_cart_id( $product_id );
		$cart_items = array();
		if( ! WC()->cart->find_product_in_cart( $product_cart_id ) ){
			WC()->cart->add_to_cart( $product_id, $quantity,  0,array(), array('add_size' => array('recipient'=> $user_custom_data_name ,'recipient_number'=> $user_custom_data_number, 'personalized'=>$personalized  ) ));
			
			// global $woocommerce;
			// $items = $woocommerce->cart->get_cart();
			// foreach($items as $item => $values) { 
			//     $_product =  wc_get_product( $values['data']->get_id());
			// 	$product_name = $_product->get_title();
			// 	$product_value = get_post_meta($values['product_id'], '_price', true);
			//     // echo "<b>".$_product->get_title().'</b>  <br> Quantity: '.$values['quantity'].'<br>'; 
			//     // $price = get_post_meta($values['product_id'] , '_price', true);
			//     // echo "  Price: ".$price."<br>";

				$cart_items = array( "recp_id" => $store_id, "retail" => $retid, "product_value" => $product_id);
			// }
				$j = 0;
				$i = 0;
				$vouchers = get_field('vouchers', $product_id);
				if(isset($vouchers) && !empty($vouchers)){
					foreach($vouchers as $voucher){
						$status = $voucher['status'];
						$reserved = $voucher['reserved'];
						if($status == 1 && $reserved == 0){
							$update_fields[] = $i;
						}
						if($status == 1){
							$j++;
						}
					$i++;
					}
				}
				$q = 1;
				foreach($update_fields as $fields){
					if($quantity >= $q){
						//update_post_meta($product_id, 'vouchers_'.$fields.'_status', 2);
		                //update_post_meta($product_id, '_vouchers_'.$fields.'_status', 'field_613258e860ce0');
	            	}
	            	$q++;
	            }
	            $update_qty = $j-$quantity;
				//update_post_meta($product_id, '_stock', $update_qty);
			
		}
			echo json_encode($cart_items);
			wp_die();
	}
	else{
		echo json_encode(array("Error" => "Only $quantity vouchers for this value are currently available."));
		wp_die();
	}
}
add_action( 'wp_ajax_nopriv_add_cart', 'add_cart' );
add_action( 'wp_ajax_add_cart', 'add_cart' );
//Add product to cart session ends
// Display custom cart item meta data (in cart and checkout)
add_filter( 'woocommerce_get_item_data', 'display_cart_item_custom_meta_data', 10, 2 );
function display_cart_item_custom_meta_data( $item_data, $cart_item ) {
    $meta_key = 'recipient';
    if ( isset($cart_item['add_size']) && isset($cart_item['add_size'][$meta_key]) ) {
        $item_data[] = array(
            'key'       => $meta_key,
            'value'     => $cart_item['add_size'][$meta_key],
        );
    }
    return $item_data;
}

// Save cart item custom meta as order item meta data and display it everywhere on orders and email notifications.
add_action( 'woocommerce_checkout_create_order_line_item', 'save_cart_item_custom_meta_as_order_item_meta', 10, 4 );
function save_cart_item_custom_meta_as_order_item_meta( $item, $cart_item_key, $values, $order ) {
    $meta_key = 'recipient';
    if ( isset($values['add_size']) && isset($values['add_size'][$meta_key]) ) {
        $item->update_meta_data( $meta_key, $values['add_size'][$meta_key] );
    }
}
add_filter( 'woocommerce_get_item_data', 'display_cart_item_custom_meta_data1', 10, 2 );
function display_cart_item_custom_meta_data1( $item_data, $cart_item ) {
    $meta_key = 'recipient_number';
    if ( isset($cart_item['add_size']) && isset($cart_item['add_size'][$meta_key]) ) {
        $item_data[] = array(
            'key'       => $meta_key,
            'value'     => $cart_item['add_size'][$meta_key],
        );
    }
    return $item_data;
}

// Save cart item custom meta as order item meta data and display it everywhere on orders and email notifications.
add_action( 'woocommerce_checkout_create_order_line_item', 'save_cart_item_custom_meta_as_order_item_meta1', 10, 4 );
function save_cart_item_custom_meta_as_order_item_meta1( $item, $cart_item_key, $values, $order ) {
    $meta_key = 'recipient_number';
    if ( isset($values['add_size']) && isset($values['add_size'][$meta_key]) ) {
        $item->update_meta_data( $meta_key, $values['add_size'][$meta_key] );
    }
}
add_filter( 'woocommerce_get_item_data', 'display_cart_item_custom_meta_data2', 10, 2 );
function display_cart_item_custom_meta_data2( $item_data, $cart_item ) {
    $meta_key = 'personalized';
    if ( isset($cart_item['add_size']) && isset($cart_item['add_size'][$meta_key]) ) {
        $item_data[] = array(
            'key'       => $meta_key,
            'value'     => $cart_item['add_size'][$meta_key],
        );
    }
    return $item_data;
}

// Save cart item custom meta as order item meta data and display it everywhere on orders and email notifications.
add_action( 'woocommerce_checkout_create_order_line_item', 'save_cart_item_custom_meta_as_order_item_meta2', 10, 4 );
function save_cart_item_custom_meta_as_order_item_meta2( $item, $cart_item_key, $values, $order ) {
    $meta_key = 'personalized';
    if ( isset($values['add_size']) && isset($values['add_size'][$meta_key]) ) {
        $item->update_meta_data( $meta_key, $values['add_size'][$meta_key] );
    }
}

//personalize checked
function filter_personalize(){
	global $wpdb;
	$rec_id = $_POST['rec_id'];
	$rec_sql ="SELECT `personalize` FROM `wp_recipients` WHERE `recipient_id` ='$rec_id'";
	$recipients = $wpdb->get_results( $wpdb->prepare($rec_sql));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_filter_personalize', 'filter_personalize' );
add_action( 'wp_ajax_filter_personalize', 'filter_personalize' );

add_filter( 'woocommerce_cart_item_thumbnail', '__return_false' );
add_filter( 'woocommerce_cart_item_quantity', 'wc_cart_item_quantity', 10, 3 );
function wc_cart_item_quantity( $product_quantity, $cart_item_key, $cart_item ){
    if( is_cart() ){
        $product_quantity = sprintf( '%2$s <input type="hidden" name="cart[%1$s][qty]" value="%2$s" />', $cart_item_key, $cart_item['quantity'] );
    }
    return $product_quantity;
}

//Add recipients starts
function save_recipient(){
	$person_name = $_POST['person_name'];
	$person_number = $_POST['person_number'];
	$personalize = $_POST['personalize'];
	$active_status = $_POST['active_status'];

	global $wpdb;
	$current_user_id = get_current_user_id();

    $table = 'wp_recipients';
	$sql = "INSERT INTO $table (recipient_name, recipient_number, personalize, active_status, rec_user_id) VALUES 
	('$person_name', '$person_number', '$personalize', '$active_status', '$current_user_id')";
	$wpdb->query($sql);

	echo json_encode(array("success"=> "Recipient Added"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_save_recipient', 'save_recipient' );
add_action( 'wp_ajax_save_recipient', 'save_recipient' );
//Add recipients ends

//update recipients starts
function update_recipient() {
	$recipient_id = $_POST['recipient_id'];
	$active_status = $_POST['active_status'];
	$person_name = $_POST['person_name'];
	$person_number = $_POST['person_number'];
	$personalize = $_POST['personalize'];
	global $wpdb;
	
    $table = 'wp_recipients';
	$sql = "UPDATE `wp_recipients` SET recipient_name = '$person_name', recipient_number = '$person_number' , personalize = '$personalize', active_status = '$active_status' WHERE recipient_id = '$recipient_id';";
	$wpdb->query($sql);

	echo json_encode(array("success"=> "Recipient Updated"));
	wp_die();	
}
add_action( 'wp_ajax_nopriv_update_recipient', 'update_recipient' );
add_action( 'wp_ajax_update_recipient', 'update_recipient' );
//update recipients ends

//Delete recipients starts
function delete_recipient(){
	global $wpdb;
	$del_id = $_POST['rec_id'];

	$sql = "DELETE FROM `wp_recipients` WHERE recipient_id ='$del_id';";
	$wpdb->query($sql);
	echo json_encode(array("success"=> "Recipient Deleted"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_delete_recipient', 'delete_recipient' );
add_action( 'wp_ajax_delete_recipient', 'delete_recipient' );
//Delete recipients ends

// add_filter( 'woocommerce_cart_item_thumbnail', '__return_false' );
// add_filter( 'woocommerce_cart_item_quantity', 'wc_cart_item_quantity', 10, 3 );
// function wc_cart_item_quantity( $product_quantity, $cart_item_key, $cart_item ){
//     if( is_cart() ){
//         $product_quantity = sprintf( '%2$s <input type="hidden" name="cart[%1$s][qty]" value="%2$s" />', $cart_item_key, $cart_item['quantity'] );
//     }
//     return $product_quantity;
// }

// Add the custom field "mobile_number"
add_action( 'woocommerce_edit_account_form', 'update_user_data_form' );
function update_user_data_form() {
    $user = wp_get_current_user();
	$user_address = 'user-address';
	$user_city = 'user_city';
	$user_country = 'user_country';
	$company_reg_num = 'company-registration-number';
	$company_name = 'company-name';
	$vat_reg_num = 'vat-registration-number';
    ?>
        <p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
        	<label for="favorite_color"><?php _e( 'Mobile Number', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="mobile_number" id="mobile_number" value="<?php echo $user->mobile_number; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
        	<label for="user_address"><?php _e( 'Company Address', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="user_address" id="user_address" value="<?php echo $user->$user_address; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
        	<label for="user_country"><?php _e( 'Country', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="user_country" id="user_country" value="<?php echo $user->$user_country; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
        	<label for="user_city"><?php _e( 'City', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="user_city" id="user_city" value="<?php echo $user->$user_city; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
        	<label for="user_country"><?php _e( 'Company Name', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="company_name" id="company_name" value="<?php echo $user->$company_name; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
        	<label for="company-registration-number"><?php _e( 'Company Registration Number', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="company_registration_number" id="company_registration_number" value="<?php echo $user->$company_reg_num; ?>" required/>
    	</p>
		<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide" id="vat_num">
        	<label for="company-registration-number"><?php _e( 'VAT Registration Number', 'woocommerce' ); ?> <span class="required">*</span></label>
        	<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="vat_registration_number" id="vat_registration_number" value="<?php echo $user->$vat_reg_num; ?>" required/>
    	</p>
    <?php
}

// Save the custom field 'mobile_number' 
add_action( 'woocommerce_save_account_details', 'save_user_account_details', 12, 1 );
function save_user_account_details( $user_id ) {
    // For Mobile Number
    if( isset( $_POST['mobile_number'] ) )
        update_user_meta( $user_id, 'mobile_number', sanitize_text_field( $_POST['mobile_number'] ) );
	// For Company Address
	if( isset( $_POST['user_address'] ) )
        update_user_meta( $user_id, 'user-address', sanitize_text_field( $_POST['user_address'] ) );
	// For User Country
	if( isset( $_POST['user_country'] ) )
	update_user_meta( $user_id, 'user_country', sanitize_text_field( $_POST['user_country'] ) );
	// For User City
	if( isset( $_POST['user_city'] ) )
	update_user_meta( $user_id, 'user_city', sanitize_text_field( $_POST['user_city'] ) );
	// For Company Name
	if( isset( $_POST['company_name'] ) )
	update_user_meta( $user_id, 'company-name', sanitize_text_field( $_POST['company_name'] ) );
	// For Company Registration Number
	if( isset( $_POST['company_registration_number'] ) )
	update_user_meta( $user_id, 'company-registration-number', sanitize_text_field( $_POST['company_registration_number'] ) );

    // For Billing email (added related to your comment)
    if( isset( $_POST['account_email'] ) )
        update_user_meta( $user_id, 'billing_email', sanitize_text_field( $_POST['account_email'] ) );

    echo "<script>window.location.href='".home_url()."'</script>";
    exit;
}


add_action('um_submit_form_errors_hook_','um_custom_validate_username', 999, 1);
function um_custom_validate_username( $args ) {
	
	if ( isset( $args['first_name_pro'] ) && strstr( $args['first_name_pro'], 'admin' ) ) {
		UM()->form()->add_error( 'first_name_pro', 'Your username must not contain the word admin first_name_pro.' );
	}
	
}

add_filter( 'woocommerce_cart_item_removed_notice_type', '__return_false' );

function disable_checkout_button_no_shipping() { 

    
    if ( WC()->cart->get_cart_contents_count() == 0 ) {
        remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20 );
        echo '<a href="#" class="checkout-button button alt wc-forward">Proceed to checkout</a>';
    }  
}

add_action( 'woocommerce_proceed_to_checkout', 'disable_checkout_button_no_shipping', 1 );



//hook
add_action('um_submit_form_errors_hook_','um_custom_validate_password', 999, 1);
function um_custom_validate_password( $args ) {
	
}
add_filter( 'woocommerce_order_button_text', 'woo_custom_order_button_text' ); 

function woo_custom_order_button_text() {
    return __( 'Proceed to Payment', 'woocommerce' ); 
}



// Duplicate service_fee starts
function duplicate_service_details(){
	$retailer = $_POST['retailer'];
	$service_fee = $_POST['service_fee'];
	$value_from = $_POST['value_from'];
	$value_to = $_POST['value_to'];

	global $wpdb;
	$current_user_id = get_current_user_id();

    $table = 'wp_service_fee';
	$sql = "INSERT INTO $table (retailer_id, service_fee, feevalue_from, feevalue_to) VALUES 
	('$retailer', '$service_fee', '$value_from', '$value_to')";
	$wpdb->query($sql);
	
	echo json_encode(array("success"=> "Recipient Successfully duplicated"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_duplicate_service_details', 'duplicate_service_details' );
add_action( 'wp_ajax_duplicate_service_details', 'duplicate_service_details' );
// Duplicate service_fee ends

// Add service_fee starts
function save_service_fee(){
	$retailer = $_POST['retailer'];
	$service_fee = $_POST['service_fee'];
	$value_from = $_POST['value_from'];
	$value_to = $_POST['value_to'];

	global $wpdb;
	$current_user_id = get_current_user_id();

    $table = 'wp_service_fee';
	$sql = "INSERT INTO $table (retailer_id, service_fee, feevalue_from, feevalue_to) VALUES 
	('$retailer', '$service_fee', '$value_from', '$value_to')";
	$wpdb->query($sql);
	
	echo json_encode(array("success"=> "Recipient Added"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_save_service_fee', 'save_service_fee' );
add_action( 'wp_ajax_save_service_fee', 'save_service_fee' );
// Add service_fee ends

// Add vat starts
function save_vat(){
	$vat_rate = $_POST['vat_rate'];
	$vat_date_from = $_POST['vat_date_from'];
	$vat_date_to = $_POST['vat_date_to'];

	global $wpdb;
	$current_user_id = get_current_user_id();

    $table = 'wp_vat';
	$sql = "INSERT INTO $table (vat_rate, date_from, date_to) VALUES 
	('$vat_rate', '$vat_date_from', '$vat_date_to')";
	$wpdb->query($sql);
	
	echo json_encode(array("success"=> "VAT Added"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_save_vat', 'save_vat' );
add_action( 'wp_ajax_save_vat', 'save_vat' );
// Add vat ends


//Delete recipients starts
function delete_vat(){
	global $wpdb;
	$vat_id = $_POST['vat_id'];

	$sql = "DELETE FROM `wp_vat` WHERE id ='$vat_id';";
	$wpdb->query($sql);
	echo json_encode(array("success"=> "Recipient Deleted"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_delete_vat', 'delete_vat' );
add_action( 'wp_ajax_delete_vat', 'delete_vat' );
//Delete recipients ends


//Delete service starts
function delete_service(){
	global $wpdb;
	$service_id = $_POST['service_id'];

	$sql = "DELETE FROM `wp_service_fee` WHERE id ='$service_id';";
	$wpdb->query($sql);
	echo json_encode(array("success"=> "Service tax Deleted"));
	wp_die();

}
add_action( 'wp_ajax_nopriv_delete_service', 'delete_service' );
add_action( 'wp_ajax_delete_service', 'delete_service' );
//Delete service ends


/**

 * Remove the country checkout field

 */

function njengah_override_checkout_fields( $fields ) {

	unset($fields['billing']['billing_first_name']);
unset($fields['billing']['billing_last_name']);
unset($fields['billing']['billing_company']);
unset($fields['billing']['billing_address_1']);
unset($fields['billing']['billing_address_2']);
unset($fields['billing']['billing_city']);
unset($fields['billing']['billing_postcode']);
unset($fields['billing']['billing_country']);
unset($fields['billing']['billing_state']);
unset($fields['billing']['billing_phone']);
unset($fields['order']['order_comments']);
unset($fields['billing']['billing_email']);
unset($fields['account']['account_username']);
unset($fields['account']['account_password']);
unset($fields['account']['account_password-2']);
	
	return $fields;
	
	}
	
	add_filter('woocommerce_checkout_fields','njengah_override_checkout_fields');


	add_action('woocommerce_before_cart_contents', 'tf_cart_page_custom_text');
 
function tf_cart_page_custom_text() {
	$cancel = $_GET['cancel_order'];
	if($cancel){ ?>
		<a href="/voucher/" id="add-recipient" class="btn add-recipient btn-primary pull-right" >Add New Voucher</a>
	<?php }
}


//update vat starts
function update_vat_details() {
	$id = $_POST['id'];
	$vat_rate = $_POST['vat_rate'];
	$date_to = $_POST['date_to'];
	$date_from = $_POST['date_from'];
	global $wpdb;
	
    $table = 'wp_vat';
	$sql = "UPDATE `wp_vat` SET vat_rate = '$vat_rate', date_to = '$date_to' , date_from = '$date_from' WHERE id = '$id';";
	$wpdb->query($sql);

	echo json_encode(array("success"=> "VAT Updated"));
	wp_die();	
}
add_action( 'wp_ajax_nopriv_update_vat_details', 'update_vat_details' );
add_action( 'wp_ajax_update_vat_details', 'update_vat_details' );
//update vat ends

//update Service starts
function update_service_details() {
	$id = $_POST['id'];
	$retailer = $_POST['retailer'];
	$service_fee = $_POST['service_fee'];
	$value_from = $_POST['value_from'];
	$value_to = $_POST['value_to'];
	global $wpdb;
	
	$sql = "UPDATE `wp_service_fee` SET retailer_id = '$retailer', service_fee = '$service_fee', feevalue_from = '$value_from' , feevalue_to = '$value_to' WHERE id = '$id';";
	$wpdb->query($sql);

	echo json_encode(array("success"=> "Service Tax Updated"));
	wp_die();	
}
add_action( 'wp_ajax_nopriv_update_service_details', 'update_service_details' );
add_action( 'wp_ajax_update_service_details', 'update_service_details' );
//update vat ends

//Export Orders starts
// function create_custome_menu_admin(){
// 	$page_title = 'Page Title';
// 	$page_name = 'Menu Name';
// 	$page_scope = 'manage_options';
// 	$page_url = 'page-url';
// 	$page_func = 'call_back_function_name';
// 	add_menu_page($page_title, $page_name, $page_scope, $page_url, $page_func);
// }
// add_action('admin_menu', 'create_custome_menu_admin');

// function call_back_function_name(){
// 	include('payment_report.php');
// }

// if ( isset($_GET['action'] ) && $_GET['action'] == 'download_csv_file' )
// {
// 	// Query
// 	$statement = $wpdb->get_results("SELECT *  FROM `wp_wc_order_stats` INNER JOIN `wp_wc_customer_lookup` ON wp_wc_customer_lookup.customer_id=wp_wc_order_stats.customer_id;");
	
// 	// file creation
// 	$wp_filename = "Payment_report_".date("d-m-y").".csv";
	
// 	// Clean object
// 	ob_end_clean ();
	
// 	// Open file
// 	$wp_file = fopen($wp_filename,"w");
// 	$fields = array('Order ID', 'Order Total','Date & Time Paid', 'No.of Items sold', 'Shipping Total', 'Order Status', 'Customer Name');
// 	fputcsv($wp_file, $fields);
// 	// loop for insert data into CSV file
// 	foreach ($statement as $statementFet)
// 	{
// 		$wp_array = array(
// 			"OrderId"=>$statementFet->order_id,
// 			"OrderTotal"=>$statementFet->net_total,
// 			"PaidDate"=>$statementFet->date_created,
// 			"ItemsSold"=>$statementFet->num_items_sold,
// 			"ShippingTotal"=>$statementFet->shipping_total,
// 			"OrderStatus"=>$statementFet->status,
// 			"CustomerName"=>$statementFet->first_name
// 		);
// 		fputcsv($wp_file,$wp_array);
// 	}
	
// 	// Close file
// 	fclose($wp_file);
	
// 	// download csv file
// 	header("Content-Description: File Transfer");
// 	header("Content-Disposition: attachment; filename=".$wp_filename);
// 	header("Content-Type: application/csv;");
// 	readfile($wp_filename);
// 	exit;
// }
//Export Orders ends



add_action('woocommerce_cart_calculate_fees', function() {
	global $woocommerce;
	global $wpdb;
    $spfee = 0.00; // initialize special fee
	$new_fees = array();
	foreach ( WC()->cart->get_cart() as $cart_item_key => $value ) {

        $proid = $value['product_id']; //get the product id from cart
        $quantiy = $value['quantity']; //get quantity from cart
        $itmprice = $value['line_subtotal']; //get product price

		
        $terms = get_the_terms( $proid, 'retailer' ); //get taxonamy of the prducts
        if ( $terms && ! is_wp_error( $terms ) ) :
            foreach ( $terms as $term ) {
				// print_r($term);
				$new_fees[$term->term_id][] = $itmprice;
				// $new_fees['ret_name'][] = $term->name;
                $catid = $term->term_id;
            }
			
        endif;  
		
    }
	// print_r($new_fees);
	
	foreach ( $new_fees as $key => $ser ) {
		
		$ser_fee ="SELECT * FROM `wp_service_fee` WHERE `retailer_id` ='$key'";
		$servicefee = $wpdb->get_results( $wpdb->prepare($ser_fee));
		foreach($servicefee as $serv_fee){
			
			$serid = $serv_fee->retailer_id;
			$itmprice = array_sum($new_fees[$key]);
			if($key == $serid){
				if(($itmprice >= $serv_fee->feevalue_from ) && ($itmprice <= $serv_fee->feevalue_to)){
					$spfee = $spfee + $itmprice * ($serv_fee->service_fee /100) ;
				}
			}
		}

	}



	$paymentDate = date('Y-m-d');
	$paymentDate=date('Y-m-d', strtotime($paymentDate));
	//echo $paymentDate; // echos today! 
	$vat_date ="SELECT * FROM `wp_vat`";
	$vat_fee = $wpdb->get_results( $wpdb->prepare($vat_date));
	foreach ( $vat_fee as $vat ) {
		// print_r($vat);
		if (($paymentDate >= $vat->date_from) && (($paymentDate <= $vat->date_to) || ($vat->date_to ==""))){
			$vat_tax = $spfee * ($vat->vat_rate / 100);
		}
		// else{
		// 	$vat_tax = 0;  
		// }
	}
	$contractDateBegin = date('Y-m-d', strtotime("01/01/2001"));
	$contractDateEnd = date('Y-m-d', strtotime("01/01/2012"));
		
	
	WC()->cart->add_fee(__('Service Fee', 'txtdomain'), $spfee);
	WC()->cart->add_fee(__('VAT', 'txtdomain'), $vat_tax);
	});

//after register complete hook start
	
// add_action( 'um_registration_complete', 'my_registration_complete', 10, 2 );
// function my_registration_complete( $user_id, $args ) {
// 	echo "<script> alert(".$user_id."); </script>";
// }

//after register complete hook end



// Add on_register_save_recipient starts
// function on_register_save_recipient(){
// 	$person_name = $_POST['person_name'];
// 	$person_number = $_POST['person_number'];
// 	$personalize = $_POST['personalize'];
// 	$active_status = $_POST['active_status'];

// 	global $wpdb;
// 	$current_user_id = get_current_user_id();

//     $table = 'wp_recipients';
// 	$sql = "INSERT INTO $table (recipient_name, recipient_number, personalize, active_status, rec_user_id) VALUES 
// 	('$person_name', '$person_number', '$personalize', '$active_status', '$current_user_id')";
// 	$wpdb->query($sql);

// 	echo json_encode(array("success"=> "Recipient Added"));
// 	wp_die();

// }
// add_action( 'wp_ajax_nopriv_on_register_save_recipient', 'on_register_save_recipient' );
// add_action( 'wp_ajax_on_register_save_recipient', 'on_register_save_recipient' );
// Add on_register_save_recipient ends


//personalize value_exist_validate
function value_exist_validate(){
	global $wpdb;
	$id = $_POST['id'];
	$retailer_id = $_POST['retailer_id'];
	$ser_fee ="SELECT `feevalue_from`, `feevalue_to` FROM `wp_service_fee` WHERE `retailer_id` ='$retailer_id' ";
	$recipients = $wpdb->get_results( $wpdb->prepare($ser_fee));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_value_exist_validate', 'value_exist_validate' );
add_action( 'wp_ajax_value_exist_validate', 'value_exist_validate' );


//update_value_exist_validate check start
function update_value_exist_validate(){
	global $wpdb;
	$id =$_POST['id'];
	$retailer_id = $_POST['retailer_id'];
	$ser_fee ="SELECT `feevalue_from`, `feevalue_to` FROM `wp_service_fee` WHERE `retailer_id` ='$retailer_id' AND `id` <> '$id'  ";
	$recipients = $wpdb->get_results( $wpdb->prepare($ser_fee));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_update_value_exist_validate', 'update_value_exist_validate' );
add_action( 'wp_ajax_update_value_exist_validate', 'update_value_exist_validate' );
//update_value_exist_validate check end

//duplicate_value_exist_validate check start
function duplicate_value_exist_validate(){
	global $wpdb;
	
	$retailer_id = $_POST['retailer_id'];
	$ser_fee ="SELECT `feevalue_from`, `feevalue_to` FROM `wp_service_fee` WHERE `retailer_id` ='$retailer_id'  ";
	$recipients = $wpdb->get_results( $wpdb->prepare($ser_fee));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_duplicate_value_exist_validate', 'duplicate_value_exist_validate' );
add_action( 'wp_ajax_duplicate_value_exist_validate', 'duplicate_value_exist_validate' );
//duplicate_value_exist_validate check end

//add_vat_date_exist_validate check start
function add_vat_date_exist_validate(){
	global $wpdb;
	$ser_fee ="SELECT `date_from`, `date_to` FROM `wp_vat` ";
	$recipients = $wpdb->get_results( $wpdb->prepare($ser_fee));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_add_vat_date_exist_validate', 'add_vat_date_exist_validate' );
add_action( 'wp_ajax_add_vat_date_exist_validate', 'add_vat_date_exist_validate' );
//update_value_exist_validate check end


//update_vat_date_exist_validate check start
function update_vat_date_exist_validate(){
	global $wpdb;
	$id = $_POST['id'];
	$ser_fee ="SELECT `date_from`, `date_to` FROM `wp_vat` WHERE `id` <> `$id` ";
	$recipients = $wpdb->get_results( $wpdb->prepare($ser_fee));

	echo json_encode($recipients);
	wp_die();

}
add_action( 'wp_ajax_nopriv_update_vat_date_exist_validate', 'update_vat_date_exist_validate' );
add_action( 'wp_ajax_update_vat_date_exist_validate', 'update_vat_date_exist_validate' );
//update_vat_date_exist_validate check end

add_filter('woocommerce_before_checkout_form','quadlayers_change_breadcrumb');
function quadlayers_change_breadcrumb( $content) {
	echo '<p class="woo-notice-confirmation">Please confirm your order and then proceed to payment.Your order will be deleted if not paid within 6 hours.</p>';
}


	
// add_action('woocommerce_order_status_processing', 'mysite_processing');//wp-processing-status
// function mysite_processing($order_id){
// 	global $wpdb;
// 	$order = wc_get_order($order_id);
// 	$items = $order->get_items();
// 	// print_r($items);
// 	foreach ( $items as $item ) {
// 		echo $product_id = $item->get_product_id();
// 	}
// 	exit;
// }


// function sv_add_my_account_order_actions( $actions, $order ) {

//     $actions['pay'] = array(
//         'name' => __( 'Checkout', 'woocommerce' ),
//     );

//     return $actions;
// }
// add_filter( 'woocommerce_my_account_my_orders_actions', 'sv_add_my_account_order_actions', 10, 2 );

function th_wc_add_my_account_orders_column( $columns ) {

	$new_columns = array();

	foreach ( $columns as $key => $name ) {

		$new_columns[ $key ] = $name;

		// add ship-to after order status column
		if ( 'order-total' === $key ) {
			$new_columns['remaining-time'] = __( 'Remaining Time', 'textdomain' );
		}
	}

	return $new_columns;
}
add_filter( 'woocommerce_my_account_my_orders_columns', 'th_wc_add_my_account_orders_column' );


// define the woocommerce_view_order callback 
function action_woocommerce_view_order( ) { 
    // make action magic happen here... 
	echo "<a href='".get_home_url()."/my-account/orders/' class='btn pull-right rec_common_btn return_list'>Back</a>";
}; 
// add the action 
add_action( 'woocommerce_view_order', 'action_woocommerce_view_order', 10, 2 );

// define the woocommerce_view_order callback 
function action_woocommerce_view_order_back( ) { 
    // make action magic happen here... 
	echo "<a href='".get_home_url()."/my-account/orders/' class='btn pull-right rec_common_btn return_list'>Back</a>";
}; 
         
// add the action 
add_action( 'woocommerce_view_order_back', 'action_woocommerce_view_order_back', 10, 2 );



//Recepient Receives SMS
use Twilio\Rest\Client;
add_action('woocommerce_checkout_order_processed', 'voucher_pending_status');//wp-pending
function voucher_pending_status($order_id){
	global $wpdb;
	global $woocommerce;

	// $woocommerce->cart->empty_cart();
	$order = wc_get_order($order_id);
	$items = $order->get_items();
	// print_r($items);
	//getting all line items
	foreach ($order->get_items() as $item_id => $item) {

		$product = $item->get_product();
		$product_id = null;
		$product_sku = null;
		$order_type = $item->get_meta('order_type');
		$recipient_name = $item->get_meta('recipient');
		$product_name = $item->get_name();
		$voucher_amount = $item->get_total();
		$recipient_name = $item->get_meta('recipient');
		//echo "<pre>";print_r($item);echo "</pre>";exit;
		// Check if the product exists.
		if (is_object($product)) {

			$product_id = $product->get_id();

			$test = get_post_meta($product_id, 'vouchers');
			$keyCount = $test[0]."<br>";

			if($order_type == 'bulk order'){

				$voucherArray = array();
				for($i=0; $i<$keyCount; $i++) {
					//echo $i." "; 
					$reserved_meta_key = 'vouchers_'.$i.'_reserved';
					$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
					$expiry_date_field_value = '';

					$status_meta_key = 'vouchers_'.$i.'_status';
					$status_field_value = get_post_meta($product_id, $status_meta_key, true);

					if($reserved_field_value == '1' && $status_field_value == '1') {
						$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
						$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);

						$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
						$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
						
						$voucherArray[$i]['key'] = $i;
						$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
						$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
					}			
				}
				for($i=0; $i<$keyCount; $i++) {
					//echo $i." "; 
					$reserved_meta_key = 'vouchers_'.$i.'_reserved';
					$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
					$expiry_date_field_value = '';

					$status_meta_key = 'vouchers_'.$i.'_status';
					$status_field_value = get_post_meta($product_id, $status_meta_key, true);

					if($reserved_field_value == '0' && $status_field_value == '1') {
						$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
						$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);

						$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
						$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
						
						$voucherArray[$i]['key'] = $i;
						$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
						$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
					}			
				}
			}else{
				$voucherArray = array();
				for($i=0; $i<$keyCount; $i++) {
					//echo $i." "; 
					$reserved_meta_key = 'vouchers_'.$i.'_reserved';
					$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
					$expiry_date_field_value = '';

					$status_meta_key = 'vouchers_'.$i.'_status';
					$status_field_value = get_post_meta($product_id, $status_meta_key, true);

					if($reserved_field_value == '0' && $status_field_value == '1') {
						$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
						$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);

						$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
						$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
						
						$voucherArray[$i]['key'] = $i;
						$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
						$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
					}			
				}
			}
			
		}

		usort($voucherArray, 'date_compare');
		$qty = $item->get_quantity();
		// echo "Qty Based Record <br>";
		if($order_type == 'bulk order'){
			
			$bulk_orders = $item->get_meta('bulk_orders');
			$bulk_orders = unserialize($bulk_orders);

			for($j = 0; $j < $qty; $j++) {
				$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
				$product_id;
				update_post_meta($product_id, $updateReserved, "3" );

				$voucher_code = $voucherArray[$j]['voucher_number'];
				$exp_date = $voucherArray[$j]['expiry_date'];
				
				$phone_number = $bulk_orders[$j]['phone_number'];

				require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');
				$account_sid = 'ACc7020830ee8e933353c573aaa1633141';
				$auth_token = 'ecf9978c42f130334a48ed8f3605f0bb';
				$twilio_number = "+27600197711";
				$client = new Client($account_sid, $auth_token);
				$client->messages->create(
					"'+27'.$phone_number",
					array(
						'from' => $twilio_number,
						'body' => "Please confirm with the retailer for any terms and conditions regarding the use of this voucher. Your voucher code is $voucher_code expiring on $exp_date."
					)
				);
			
			}

		}else{
			for($j = 0; $j < $qty; $j++) {
				$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
				$product_id;
				update_post_meta($product_id, $updateReserved, "2" );
			}
		}
		$already_stock = get_post_meta( $product_id, '_stock', true );
		//update_post_meta($productid, '_stock', 1);
	}
}


add_action('woocommerce_order_status_processing', 'mysite_processing'); //wp-processing-status
function mysite_processing($order_id){
	global $wpdb;
	$order = wc_get_order($order_id);
	//echo "<pre>";print_r($order);echo "</pre>";
	$items = $order->get_items();
	$date = $order->get_date_created("M d, YY");
	$order_Date = date("F d, Y", strtotime($date));
	// print_r($items);
	//getting all line items
	$mail_array = array();
	foreach ($order->get_items() as $item_id => $item) {
		$recipient_name = $item->get_meta('recipient');
		$recipient_number = $item->get_meta('recipient_number');
		$personalized = $item->get_meta('personalized');
		$product_name = $item->get_name();
		$voucher_amount = $item->get_total();
		// print_r($voucher_amount);
		// exit;
		$user = $order->get_user();
		$display_name = $user->display_name;

		$product = $item->get_product();
		$product_id = null;
		$product_sku = null;
		// Check if the product exists.
		if (is_object($product)) {

			$product_id = $product->get_id();
			$price = get_post_meta($product_id , '_price', true);

			$test = get_post_meta($product_id, 'vouchers');
			$keyCount = $test[0]."<br>";

			$voucherArray = array();
			for($i=0; $i<$keyCount; $i++) {
				//echo $i." "; 
				$reserved_meta_key = 'vouchers_'.$i.'_reserved';
				$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
				$expiry_date_field_value = '';

				$status_meta_key = 'vouchers_'.$i.'_status';
				$status_field_value = get_post_meta($product_id, $status_meta_key, true);

				if($reserved_field_value == '0' && $status_field_value == '2') {
					$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
					$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);
					if($expiry_date_field_value == ""){
						$expiry_date_field_value = "00/00/00";
					}

					$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
					$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
					
					$i." - ".$reserved_field_value." - ".$expiry_date_field_value."<br>";
					$voucherArray[$i]['key'] = $i;
					$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
					$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
				}			
			}

			
		}
		// print_r($voucherArray);
	
		// echo "<br>After Sorting : <br>";
		// Sort the array 
		usort($voucherArray, 'date_compare');
		
		// Print the array
		// print_r($voucherArray); echo "<br>";

		$qty = $item->get_quantity();
		// echo "Qty Based Record <br>";
		$pdt_code = array();
		$exp_date = array();
		// foreach($voucherArray as $key => $value)	{
			for($j = 0; $j < $qty; $j++) {
				// print_r($voucherArray[$j])."<br>";

				$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
				$product_id;
				update_post_meta($product_id, $updateReserved, "3" );
				$pdt_code[] = $voucherArray[$j]['voucher_number'];
				if($voucherArray[$j]['expiry_date'] == "00/00/00"){
					$exp_date[] = "00/00/00";
				}else{
					$newDate = date("d-m-Y", strtotime($voucherArray[$j]['expiry_date']));
					$exp_date[] = $newDate;
				}
			}
		// }
		$voucher_code = implode(", ", $pdt_code);
		$exp_date = implode(", ", $exp_date);

		// $voucher_number = get_post_meta($product_id ,'voucher_number');
		$term_obj_list = get_the_terms( $product_id, 'retailer' );
		$retailer_name =  $term_obj_list[0]->name;
		
		require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');
		// Your Account SID and Auth Token from twilio.com/console
		// $account_sid = 'AC821db61646084b8f496705e5fb98cfb7';
		// $auth_token = 'cd0021c36f558e5d895915704d55c507';
		// $twilio_number = "+14842184346";
		
		// In production, these should be environment variables. E.g.:
		// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
		// A Twilio number you own with SMS capabilities
		$account_sid = 'ACc7020830ee8e933353c573aaa1633141';
		$auth_token = 'ecf9978c42f130334a48ed8f3605f0bb';
		// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
		$twilio_number = "+27600197711";
		$client = new Client($account_sid, $auth_token);
		if($personalized == "Yes"){
			$client->messages->create(
				// Where to send a text message (your cell phone?)
				"'+27'.$recipient_number",
				array(
					'from' => $twilio_number,
					'body' => "$recipient_name, you have received a R$voucher_amount $retailer_name voucher from $display_name. Please confirm with the retailer for any terms and conditions regarding the use of this voucher. Your voucher code is $voucher_code expiring on $exp_date."
				)
			);
		}elseif($personalized == "No")
		{
			$client->messages->create(
				// Where to send a text message (your cell phone?)
				"'+27'.$recipient_number",
				array(
					'from' => $twilio_number,
					'body' => "You have received a R$voucher_amount $retailer_name voucher. Please confirm with the retailer for any terms and conditions regarding the use of this voucher. Your voucher code is $voucher_code expiring on $exp_date."
				)
			);
		}else{
			$client->messages->create(
				// Where to send a text message (your cell phone?)
				"'+27'.$recipient_number",
				array(
					'from' => $twilio_number,
					'body' => "$recipient_name,you have received a R$voucher_amount $retailer_name voucher.Please confirm with the retailer for any terms and conditions regarding the use of this voucher.Your voucher code is $voucher_code expiring on $exp_date."
				)
			);
		}

		$product_id = $item['product_id'];		
		$terms = get_the_terms($product_id, 'retailer');
		$product_cat = "";
		foreach($terms as $term) {
			$product_cat = $term->name;
			// $mail_array['pdt_cat'] = $product_cat;
		}
		$mail_array[] = array( 
			"title" => $product_name,
			"recipient_name" => $recipient_name,
			"recipient_number" => $recipient_number,
			"voucher_number" => $voucher_code,
			"price" => $price,
			"qty" => $qty,
			"pdt_cat" => $product_cat,
		);
	}
}


function date_compare($element1, $element2) {
	if($element1['expiry_date'] == "00/00/00"){
		$element1['expiry_date'] = date("Y/m/d", strtotime("+10 year"));
	}
	if($element2['expiry_date'] == "00/00/00"){
		$element2['expiry_date'] = date("Y/m/d", strtotime("+10 year"));
	}
    $datetime1 = strtotime($element1['expiry_date']);
    $datetime2 = strtotime($element2['expiry_date']);
    return $datetime1 - $datetime2;
} 

//payment pending order cancel on logout start
function order_cancel(){
	global $wpdb;
	$order_id =$_POST['order_id'];
	echo $order_id;
	
	$order = new WC_Order($order_id);
 
	if (!empty($order)) {
		$order->update_status( 'cancelled' );
	}
	wp_logout('/voucher/log-in/');
	
	wp_die();

}
add_action( 'wp_ajax_nopriv_order_cancel', 'order_cancel' );
add_action( 'wp_ajax_order_cancel', 'order_cancel' );
//payment pending order cancel on logout end


function voucherotpemail($phoneNumber, $connection){
	// $email = $_POST['email'];
	session_start();
	$rndno=rand(1000, 9999);//OTP generate
	$message = urlencode("otp number.".$rndno);
	$phoneNumber=$_POST['email'];
	$subject = "OTP";
	$txt = "Welcome to Virtual Vouchers. Your verification code is ".$rndno."";
	$headers = "From: otp@virtualvouchers.com";
	wp_mail($phoneNumber,$subject,$txt,$headers);
	$sql = "UPDATE `wp_otp_users` SET `otp`=$rndno WHERE `value` = '$phoneNumber'";  
	  $verified = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
	  $_SESSION['phoneNumber'] = $phoneNumber; 
	echo json_encode(array("msg" => "OTP Sent"));
	wp_die();

}

add_action( 'wp_ajax_nopriv_voucherotpemail', 'voucherotpemail' );
add_action( 'wp_ajax_voucherotpemail', 'voucherotpemail' );


function voucherotp(){

	session_start();
	require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');  
	$configVariables = include ('config.php');
	$dbUserName = $configVariables['db_username'];  
	$dbPassword = $configVariables['db_password'];  
	$dbName = $configVariables['db_name'];  
	$connection = mysqli_connect('localhost', $dbUserName, $dbPassword, $dbName) or die('could not connect to dataabase');
	  
	$sid = $configVariables['sid'];  
	$token = $configVariables['token'];  
	$from = $configVariables['from'];  
	$countryCode = "+27";  

	$otp_type = $_POST['motp'];
	if($otp_type == "yes"){
		$phoneNumber = $_POST['mob_num'];
		$sql = "SELECT * FROM `wp_otp_users` WHERE `value` = '$phoneNumber' LIMIT 1";  
		// $isPhoneNumberPresent = $wpdb->get_results( $wpdb->prepare($sql));
		// print_r($isPhoneNumberPresent);
		// exit;
		$isPhoneNumberPresent = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
		if(mysqli_num_rows($isPhoneNumberPresent) > 0) {  
		$record = mysqli_fetch_assoc($isPhoneNumberPresent);  
		if($record['is_verified'] == '1') {  
			// echo "Number Already Verified";
			echo json_encode(array("msg" => "Number Already Verified"));
			wp_die();
			die;  
		} else {  
			sendOTP($countryCode, $phoneNumber, $connection);  
			// header('Location: /verify.php');   
			echo json_encode(array("msg" => "OTP Sent"));
			wp_die();
		}  
		} else {  
		$sql = "INSERT INTO wp_otp_users VALUES(DEFAULT, 'sms', '$phoneNumber', '0', '0')";
		$isPhoneNumberPresent = mysqli_query($connection, $sql) or die(mysqli_error($connection));
		sendOTP($countryCode, $phoneNumber, $connection);  
		//   header('Location: /verify.php');   
		echo json_encode(array("msg" => "OTP Sent"));
		wp_die();
		}
	}else{
		$phoneNumber = $_POST['email'];
		$sql = "SELECT * FROM `wp_users` WHERE `user_email` = '$phoneNumber' LIMIT 1";  
		// $isPhoneNumberPresent = $wpdb->get_results( $wpdb->prepare($sql));
		// print_r($isPhoneNumberPresent);
		// exit;
		$isPhoneNumberPresent = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
		if(mysqli_num_rows($isPhoneNumberPresent) > 0) {  
		$record = mysqli_fetch_assoc($isPhoneNumberPresent);  
		if($record['is_verified'] == '1') {  
			// echo "Number Already Verified";
			echo json_encode(array("msg" => "Number Already Verified"));
			wp_die();
			die;  
		} else {  
			voucherotpemail($phoneNumber, $connection);
			// sendOTP($countryCode, $phoneNumber, $connection);  
			// // header('Location: /verify.php');   
			echo json_encode(array("msg" => "OTP Sent"));
			wp_die();
		}  
		} else {  
		$sql = "INSERT INTO wp_otp_users VALUES(DEFAULT, 'email', '$phoneNumber', '0', '0')";
		$isPhoneNumberPresent = mysqli_query($connection, $sql) or die(mysqli_error($connection)); 
		voucherotpemail($phoneNumber, $connection); 
		// sendOTP($countryCode, $phoneNumber, $connection);  
		//   header('Location: /verify.php');   
		echo json_encode(array("msg" => "OTP Sent"));
		wp_die();
		}
	}
	
	
	
}

add_action( 'wp_ajax_nopriv_voucherotp', 'voucherotp' );
add_action( 'wp_ajax_voucherotp', 'voucherotp' );

function sendOTP($countryCode, $phoneNumber, $connection) {  
	try {  
	  global $sid;  
	  global $token;  
	  global $from;  
	//   $sid = 'AC821db61646084b8f496705e5fb98cfb7';
	//   $token = 'cd0021c36f558e5d895915704d55c507';
	  $sid = 'ACc7020830ee8e933353c573aaa1633141';
	  $token = 'ecf9978c42f130334a48ed8f3605f0bb';
	  $from = '+27600197711';
	  $client = new Client($sid , $token);  
	  $otp = generateOTP();  
	  $message = $client->messages  
		   ->create($countryCode . $phoneNumber, // to  
				array("from" => $from, "body" => "Welcome to Virtual Vouchers. Your OTP is " . $otp)  
		   );    
	  $sql = "UPDATE `wp_otp_users` SET `otp`=$otp WHERE `value` = '$phoneNumber'";  
	  $verified = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
	  $_SESSION['phoneNumber'] = $phoneNumber;           
	} catch(\Exception $ex) {  
	//   print_r($ex);die;  
	  echo json_encode(array("msg" => "Please Check Number"));
	  wp_die();
	}  
  }  
  function generateOTP() {  
	return rand(1000, 9999);  
  }



function verifyotp(){
	$phoneNumber = $_POST['mob_num'];
	$otp = $_POST['otp'];

	$configVariables = include ('config.php');
	$dbUserName = $configVariables['db_username'];  
	$dbPassword = $configVariables['db_password'];  
	$dbName = $configVariables['db_name'];  
	$connection = mysqli_connect('localhost', $dbUserName, $dbPassword, $dbName) or die('could not connect to dataabase');

	$sql = "SELECT * FROM `wp_otp_users` WHERE `value` = '$phoneNumber' AND `otp` = '$otp'";  
   	$isOTPCorrect = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
	if(mysqli_num_rows($isOTPCorrect) > 0) {  
		$record = mysqli_fetch_assoc($isOTPCorrect);  
		$sql = "UPDATE `wp_otp_users` SET `is_verified`='1' WHERE `value` = '$phoneNumber'";  
		$verified = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
		// echo "Congrats, Your Mobile Number is Verified";die;  
		echo json_encode(array("msg" => "Verified"));
	  	wp_die();
	} else {  
		// echo "Incorrect OTP";die;  
		echo json_encode(array("msg" => "Incorrect OTP"));
	  	wp_die();
	} 
}

add_action( 'wp_ajax_nopriv_verifyotp', 'verifyotp' );
add_action( 'wp_ajax_verifyotp', 'verifyotp' );


function email_verifyotp(){
	$phoneNumber = $_POST['email'];
	$otp = $_POST['otp'];

	$configVariables = include ('config.php');
	$dbUserName = $configVariables['db_username'];  
	$dbPassword = $configVariables['db_password'];  
	$dbName = $configVariables['db_name'];  
	$connection = mysqli_connect('localhost', $dbUserName, $dbPassword, $dbName) or die('could not connect to dataabase');

	$sql = "SELECT * FROM `wp_otp_users` WHERE `value` = '$phoneNumber' AND `otp` = '$otp'";  
   	$isOTPCorrect = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
	if(mysqli_num_rows($isOTPCorrect) > 0) {  
		$record = mysqli_fetch_assoc($isOTPCorrect);  
		$sql = "UPDATE `wp_otp_users` SET `is_verified`='1' WHERE `value` = '$phoneNumber'";  
		$verified = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
		// echo "Congrats, Your Mobile Number is Verified";die;  
		echo json_encode(array("msg" => "Verified"));
	  	wp_die();
	} else {  
		// echo "Incorrect OTP";die;  
		echo json_encode(array("msg" => "Incorrect OTP"));
	  	wp_die();
	} 
}

add_action( 'wp_ajax_nopriv_email_verifyotp', 'email_verifyotp' );
add_action( 'wp_ajax_email_verifyotp', 'email_verifyotp' );

function my_page_template_redirect() {
    if ( is_page( 'Edit-profile' )) {
        wp_redirect( home_url() );
        exit();
    }
    
}
add_action( 'template_redirect', 'my_page_template_redirect' );


add_action( 'pending_order_remaind', 'cron_order_remainder_sms' );
// add_shortcode( 'order_meta', 'cron_order_remainder_sms' );
function cron_order_remainder_sms() {
	// wp_mail( 'azhagappan.s@cgvakindia.com', 'Vouchers Cron', 'Test Cron' );
	global $wpdb;
	$order = array(
                'post_type' => 'shop_order',
                'post_status'       =>  array( 'wc-pending' ),
                'posts_per_page'    => -1
			);
			$lead_selection = new WP_Query($order);

	

    while($lead_selection->have_posts()): 
		global $wpdb;
		$current_user_id = get_current_user_id();
		// $user_number = wp_get_current_user()->mobile_number;
        $lead_selection->the_post();
        $order_id = get_the_ID();
		$ordered = wc_get_order( $order_id );
		$customer_id = $ordered->get_customer_id();
		$user_number = get_user_meta( $customer_id, 'mobile_number', true );
        $post_author_id =  get_post_meta( '_customer_user', $order_id );
		// print_r($post_author_id);
        // echo $order_id." - ".$post_author_id."<br>";
		
        $orderDate = get_the_date('Y-m-d');
        $orderTime = get_the_time('H:i:s');
        $date1 = $orderDate." ".$orderTime;
        $date2 = date_i18n('Y-m-d H:i:s');
        
        $timestamp1 = strtotime($date1);
        $timestamp2 = strtotime($date2);
        $hour = abs($timestamp2 - $timestamp1)/(60*60);
    // exit;
        if(($hour >2) && ($hour <2.10)) {        
			// wp_mail( 'azhagappan.s@cgvakindia.com', 'Vouchers Cron', 'Test Cron' );
            require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');
            // Your Account SID and Auth Token from twilio.com/console
            $account_sid = 'ACc7020830ee8e933353c573aaa1633141';
            $auth_token = 'ecf9978c42f130334a48ed8f3605f0bb';
            // In production, these should be environment variables. E.g.:
            // $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
            // A Twilio number you own with SMS capabilities
			// $account_sid = 'AC821db61646084b8f496705e5fb98cfb7';
			// $auth_token = 'cd0021c36f558e5d895915704d55c507';
			// $twilio_number = "+14842184346";
            $twilio_number = "+27600197711";
            $client = new Client($account_sid, $auth_token);
    
            $client->messages->create(
                // Where to send a text message (your cell phone?)
				"'+27'.$user_number",
				// "+919566714914",
                array(
                    'from' => $twilio_number,
                    'body' => "Your order at Virtual Vouchers is waiting to be finalized. Please return to complete it before it expires."
                )
            );

            print($message->sid);
        }	
		// update_post_meta($order_id, '_remainder_sms', "1");
    endwhile;
}


add_action( 'woocommerce_order_status_cancelled', 'change_status_to_refund', 21, 1 );
function change_status_to_refund($order_id ) {
	$order = new WC_Order( $order_id );
	global $wpdb;
	global $woocommerce;
	WC()->cart->empty_cart();
	// echo $order_id;
	// exit;
	// $order = wc_get_order($order_id);
	$items = $order->get_items();
	// print_r($items);
	// exit;
	//getting all line items
	foreach ($order->get_items() as $item_id => $item) {

		$product = $item->get_product();
		$product_id = null;
		$product_sku = null;
	// 	// Check if the product exists.
		if (is_object($product)) {
			// echo "test";

			$product_id = $product->get_id();

			$test = get_post_meta($product_id, 'vouchers');
			$keyCount = $test[0]."<br>";

			$voucherArray = array();
			for($i=0; $i<$keyCount; $i++) {
				//echo $i." "; 
				$reserved_meta_key = 'vouchers_'.$i.'_reserved';
				$reserved_field_value = get_post_meta($product_id, $reserved_meta_key, true);
				$expiry_date_field_value = '';

				$status_meta_key = 'vouchers_'.$i.'_status';
				$status_field_value = get_post_meta($product_id, $status_meta_key, true);

				if($status_field_value == '2') {
					$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
					$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);

					$voucher_number_meta_key = 'vouchers_'.$i.'_voucher_number';
					$voucher_number_field_value = get_post_meta($product_id, $voucher_number_meta_key, true);
					
					// echo $i." - ".$reserved_field_value." - ".$expiry_date_field_value."<br>";
					$voucherArray[$i]['key'] = $i;
					$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;
					$voucherArray[$i]['voucher_number'] = $voucher_number_field_value;
				}			
			}
			
		}
		// print_r($voucherArray);
		// exit;
		usort($voucherArray, 'date_compare');
		$qty = $item->get_quantity();
		// echo "Qty Based Record <br>";
		for($j = 0; $j < $qty; $j++) {
			$updateReserved = 'vouchers_'.$voucherArray[$j]['key'].'_status';
			$product_id;
			update_post_meta($product_id, $updateReserved, "1" );
		}
	}

}


add_action( 'voucher_code_expired', 'voucher_code_expire_bydate' );
// add_shortcode( 'order_meta', 'cron_order_remainder_sms' );
function voucher_code_expire_bydate() {
	global $wpdb;
	$args = array(
		'post_type' => 'product',
		'paged' => $paged,
		'posts_per_page' => -1
	);
	$loop = new WP_Query( $args );

	while ( $loop->have_posts() ) : $loop->the_post(); 
	$product_id = $loop->post->ID;
	$test = get_post_meta($product_id, 'vouchers');
				$keyCount = $test[0]."<br>";

				$voucherArray = array();
				for($i=0; $i<$keyCount; $i++) {
					
						$status_meta_key = 'vouchers_'.$i.'_status';
						$expiry_date_meta_key = 'vouchers_'.$i.'_expiry_date';
						$expiry_date_field_value = get_post_meta($product_id, $expiry_date_meta_key, true);
						
						$voucherArray[$i]['expiry_date'] = $expiry_date_field_value;	
						$mydate = date("d-m-Y", strtotime($voucherArray[$i]['expiry_date']));
						$currentDateTime = date('d-m-Y');
						if($mydate < $currentDateTime ){
							update_post_meta($product_id, $status_meta_key, "4" );
							// echo "expired";
							// echo "<br>";	
						}	
				}
	endwhile; 
	//  wp_reset_query();
}

add_action( 'woocommerce_checkout_order_processed', 'save_voucher_order',  1, 1  );
function save_voucher_order($order_id) {
// 	global $woocommerce;
// $woocommerce->cart->empty_cart();
// $woocommerce->cart->add_to_cart($product_id,$qty);
	// echo $order_id;
	// print_r($_POST);
	if($_POST['order_type'] == '1') { 
		exit;

		// header("Location: http://202.129.196.139:3444/voucher/my-account/orders/");
		// exit;
		// echo "stest";
	} 
	// exit;
	// WC()->cart->empty_cart();
}

/**
*  @param $user
*  @author Webkul
*/

add_action( 'edit_user_profile', 'wk_custom_user_profile_fields' );

function wk_custom_user_profile_fields( $user )
{
    //echo '<h3 class="heading">Custom Fields</h3>';

    $all_meta_for_user = get_user_meta($user->ID);
    $mobile_number = $all_meta_for_user['mobile_number'][0];
    $country = $all_meta_for_user['country'][0];
    $user_city = $all_meta_for_user['user_city'][0];
    $company_name = $all_meta_for_user['company-name'][0];
    $company_reg = $all_meta_for_user['company-registration-number'][0];
    $company_vat = $all_meta_for_user['vat-registration-number'][0];
    $company_address = $all_meta_for_user['user-address'][0];


    global $woocommerce;
	$countries_obj   = new WC_Countries();
	$countries   = $countries_obj->__get('countries');
	$countryCode = '';
	if(!empty($countries)){
		foreach($countries as $key=>$value){
			if(strtolower($value) == strtolower($country) || strtolower($key) == strtolower($country)){
				$countryCode = $key;
			}
		}
	}/*
    ?>
    
    <table class="form-table">
	<tr>
        <th><label for="mobile_number">Phone Number</label></th>
	    <td>
	    	<input type="text" pattern="[0-9]{9}" onkeypress="return isNumberKey(<?php echo $user->ID; ?>)" class="input-text form-control" value="<?php echo $mobile_number; ?>" name="mobile_number" id="mobile_number" />
		</td>
	</tr>
	<tr>
		<th><label for="country">Country</label></th>
	    <td>
	    	<?php
			wp_enqueue_script( 'wc-country-select' );

			woocommerce_form_field( 'country', array(
			'type'      => 'country',
			'class'     => array('input-text','form-control'),
			'required'  => true,
			'default'   => $countryCode,
			));
	    	?>
		</td>
	</tr>
	<tr>
		<th><label for="user_city">City</label></th>
	    <td>
	    	<input type="text" class="input-text form-control" value="<?php echo $user_city; ?>" name="user_city" id="user_city" />
		</td>
	</tr>
	<tr>
		<th><label for="company-name">Company Name</label></th>
	    <td>
	    	<input type="text" class="input-text form-control" value="<?php echo $company_name; ?>" name="company-name" id="company-name" />
		</td>
	</tr>
	<tr>
		<th><label for="company-registration-number">Company Registration Number</label></th>
	    <td>
	    	<input type="text" class="input-text form-control" value="<?php echo $company_reg; ?>" name="company-registration-number" id="company-registration-number" />
		</td>
	</tr>
	<tr>
		<th><label for="vat-registration-number">VAT Registration Number</label></th>
	    <td>
	    	<input type="text" class="input-text form-control" value="<?php echo $company_vat; ?>" name="vat-registration-number" id="vat-registration-number" />
		</td>
	</tr>
	<tr>
		<th><label for="user-address">Company Address</label></th>
	    <td>
	    	<input type="text" class="input-text form-control" value="<?php echo $company_address; ?>" name="user-address" id="user-address" />
		</td>

	</tr>
    </table>
    
    <?php
    */
}
add_action( 'show_user_profile', 'wk_custom_user_profile_fields' );

add_action( 'personal_options_update', 'wk_save_custom_user_profile_fields' );

add_action( 'edit_user_profile_update', 'wk_save_custom_user_profile_fields' );
/**
*   @param User Id $user_id
*/
function wk_save_custom_user_profile_fields( $user_id )
{	
    $custom_data = $_POST['mobile_number'];
    update_user_meta( $user_id, 'mobile_number', $custom_data );
    $country = $_POST['country'];
    update_user_meta( $user_id, 'country', $country );
    $user_city = $_POST['user_city'];
    update_user_meta( $user_id, 'user_city', $user_city );
    $company_name = $_POST['company-name'];
    update_user_meta( $user_id, 'company-name', $company_name );
    $company_reg = $_POST['company-registration-number'];
    update_user_meta( $user_id, 'company-registration-number', $company_reg );
    $company_vat = $_POST['vat-registration-number'];
    update_user_meta( $user_id, 'vat-registration-number', $company_vat );
    $company_address = $_POST['user-address'];
    update_user_meta( $user_id, 'user-address', $company_address );
}


// add_action( 'user_new_form', 'dontchecknotify_register_form' );
 
// function dontchecknotify_register_form() { 
//     echo '<script>jQuery(document).ready(function($) { 
//         $("#send_user_notification").removeAttr("checked"); 
// 		jQuery("#send_user_notification").parent("td").parent("tr").css("display","none");
//     } ); </script>';
// }


add_action('admin_menu', 'remove_built_in_roles');
 
function remove_built_in_roles() {
    global $wp_roles;
 
    $roles_to_remove = array('customer', 'contributor', 'author', 'editor');
 
    foreach ($roles_to_remove as $role) {
        if (isset($wp_roles->roles[$role])) {
            $wp_roles->remove_role($role);
        }
    }
}

add_action('save_post','save_post_callback');
function save_post_callback($post_id){
    global $post; 
    if($post->post_type == 'product'){
    	$voucher_data = get_field('vouchers', $post_id);
    	$i = 0;
    	foreach($voucher_data as $data){
    		if($data['status'] == 1 || $data['status'] == 2) {
    			$i++;
    		}
    	}
    	update_post_meta($post_id, '_stock', $i);
    	update_post_meta($post_id, '_stock_status', 'outofstock');
		if($i > 0) {
			update_post_meta($post_id, '_stock_status', 'instock');
		}
    	
    }
    //if you get here then it's your post type so do your thing....
}

add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
	global $pagenow;
	if($pagenow == 'users.php'){
    ?>
	    <style type="text/css">
	    #the-list .row-actions .view, #the-list .row-actions .frontend_profile{
	    	display: none;
	    }
	    </style>
    <?php
	}
	if($pagenow == 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] == 'product'){
    ?>
	    <style type="text/css">
	    #product_cat.dropdown_product_cat{
	    	display: none;
	    }
	    </style>
    <?php
	}if($pagenow == 'edit-tags.php' && isset($_GET['taxonomy']) && $_GET['taxonomy'] == 'retailer'){
    ?>
	    <style type="text/css">
	    .row-actions .view{
	    	display: none;
	    }
	    </style>
    <?php
	}
}
/**
 * Display a custom taxonomy dropdown in admin
 * @author Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
add_action('restrict_manage_posts', 'tsm_filter_post_type_by_taxonomy');
function tsm_filter_post_type_by_taxonomy() {
	global $typenow;
	$post_type = 'product'; // change to your post type
	$taxonomy  = 'retailer'; // change to your taxonomy
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => sprintf( __( 'Select a %s', 'textdomain' ), $info_taxonomy->label ),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}

add_filter( 'manage_edit-product_columns', 'wootix_show_product_order', 15 ) ;

function wootix_show_product_order( $columns )
{
    $arr = array( 'wootix_credit' => __( 'Stock', 'Stock' ) ) ;
    array_splice( $columns, 5, 0, $arr ) ;
    unset($columns['is_in_stock']);
    return $columns ;
}

add_action( 'manage_product_posts_custom_column', 'wpso23858236_product_column_offercode', 10, 2 );

function wpso23858236_product_column_offercode( $column, $postid ) {

    if ( $column == 'Stock In' ) {
    	$stock_count = 0;
        $voucher_data = get_field('vouchers', $postid);
        $c = 0;
        if(!empty($voucher_data)){
            foreach($voucher_data as $data){
                if($data['status'] == 1 || strtolower($data['status']) == 'available'){
                    $stock_count = ++$c;
                }
            }
        }
        if($stock_count == 0){
        	echo '<mark class="outofstock">Out of stock</mark> ('.$stock_count.')';
        }else{
        	echo '<mark class="instock">In stock</mark> ('.$stock_count.')';
        }
    }
}

/**
 * Filter posts by taxonomy in admin
 * @author  Mike Hemberger
 * @link http://thestizmedia.com/custom-post-type-filter-admin-custom-taxonomy/
 */
add_filter('parse_query', 'tsm_convert_id_to_term_in_query');
function tsm_convert_id_to_term_in_query($query) {
	global $pagenow;
	$post_type = 'product'; // change to your post type
	$taxonomy  = 'retailer'; // change to your taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

/*add_action( 'load-edit.php', 'no_category_dropdown' );
function no_category_dropdown() {
    add_filter( 'wp_dropdown_cats', '__return_false' );
}*/

function cart_logout_no(){
	// do_action( 'wp_logout', $user_id );
	global $wpdb;
	global $woocommerce;
	WC()->cart->empty_cart();
}
add_action( 'wp_ajax_nopriv_cart_logout_no', 'cart_logout_no' );
add_action( 'wp_ajax_cart_logout_no', 'cart_logout_no' );

function delete_cart_items(){
	// do_action( 'wp_logout', $user_id );
	global $wpdb;
	global $woocommerce;
	// WC()->cart->empty_cart();
	//echo '<script>window.location.href="'.home_url().'/bulk-order-import/";</script>';
	exit();
}
add_action( 'wp_ajax_nopriv_delete_cart_items', 'delete_cart_items' );
add_action( 'wp_ajax_delete_cart_items', 'delete_cart_items' );




function cart_logout_yes(){
	session_start();
	$_SESSION["cartlogout_value"] = "cart_logout_yes";
}
add_action( 'wp_ajax_nopriv_cart_logout_yes', 'cart_logout_yes' );
add_action( 'wp_ajax_cart_logout_yes', 'cart_logout_yes' );

function action_wp_logout( $array ) { 
    wp_redirect('http://202.129.196.139:3444/voucher/sample-page/?redirect_to=http://202.129.196.139:3444/voucher/log-in/');
	exit;
}; 
         
// add the action 
add_action( 'wp_logout', 'action_wp_logout', 10, 1 ); 

add_action( 'wp_ajax_nopriv_check_email', 'check_email' );
add_action( 'wp_ajax_check_email', 'check_email' );

function check_email(){

	session_start();
	require_once(get_stylesheet_directory() . '/twilio-php/src/Twilio/autoload.php');  
	$configVariables = include ('config.php');
	$dbUserName = $configVariables['db_username'];  
	$dbPassword = $configVariables['db_password'];  
	$dbName = $configVariables['db_name'];  
	$connection = mysqli_connect('localhost', $dbUserName, $dbPassword, $dbName) or die('could not connect to dataabase');

	$otp_type = $_POST['motp'];
	if($otp_type == "no"){
		$phoneNumber = $_POST['email'];
		$sql = "SELECT * FROM `wp_users` WHERE `user_email` = '$phoneNumber' LIMIT 1";  
		$isPhoneNumberPresent = mysqli_query($connection, $sql) or die(mysqli_error($connection));  
		if(mysqli_num_rows($isPhoneNumberPresent) > 0) {  
		$record = mysqli_fetch_assoc($isPhoneNumberPresent);  
			echo json_encode(array("msg" => "Number Already Verified"));
			wp_die();
			die;
		}
	}
	
}


add_action( 'woocommerce_cart_is_empty', 'custom_empty_cart_message', 1 );

function custom_empty_cart_message() {
	global $wpdb;
	global $woocommerce;
	if ( is_user_logged_in() ) :

		$user_id = get_current_user_id();
		$customer = new WC_Customer( $user_id );
		$last_order = $customer->get_last_order();

		$customer_orders = get_posts(array(
			'numberposts' => -1,
			'meta_key' => '_customer_user',
			'orderby' => 'date',
			'order' => 'DESC',
			'meta_value' => get_current_user_id(),
			'post_type' => wc_get_order_types(),
			'post_status' => array_keys(wc_get_order_statuses()), 
			'post_status' => array('wc-pending'),
		));

		
		// print_r($customer_orders);
		// echo count(array($customer_orders ));
		// exit;
		if(( count($customer_orders) > 0 ) && $last_order->get_status() == "pending") {
			wc_print_notice( sprintf( '<span class="pending-reminder">' .
				__('Already have one order in pending waiting to be completed  %s', 'woocommerce') . '</span>',
				'<a class="pending-reminder" href="/voucher/my-account/orders/" class="button alt" style="float:right">'. __('Go to My Order', 'woocommerce') .'</a>'
			), 'notice' );?>
		<script>
			$(".recipient").prop('disabled','true');
			// $(".retailer").prop('disabled','true');
			// $(".voucher_price").prop('disabled','true');
			$('.woocommerce-info').css('background-color','#b22222');
			$('.pending-reminder').css('color','#fff');
		</script>
		<?php } ?>
		
		<?php
	endif;
}

add_shortcode( 'my_purchased_products', 'bbloomer_products_bought_by_curr_user' );
   
function bbloomer_products_bought_by_curr_user() {
   
    // GET CURR USER
    $current_user = wp_get_current_user();
    if ( 0 == $current_user->ID ) return;
   
    // GET USER ORDERS (COMPLETED + PROCESSING)
    $customer_orders = get_posts( array(
        'numberposts' => -1,
        'meta_key'    => '_customer_user',
        'meta_value'  => $current_user->ID,
        'post_type'   => wc_get_order_types(),
        'post_status' => array_keys( wc_get_is_paid_statuses() ),
    ) );
   
    // LOOP THROUGH ORDERS AND GET PRODUCT IDS
    if ( ! $customer_orders ) return;
    $product_ids = array();
    foreach ( $customer_orders as $customer_order ) {
        $order = wc_get_order( $customer_order->ID );
        $items = $order->get_items();
        foreach ( $items as $item ) {
            $product_id = $item->get_product_id();
            $product_ids[] = $product_id;
        }
    }
    $product_ids = array_unique( $product_ids );
    $product_ids_str = implode( ",", $product_ids );
   
    // PASS PRODUCT IDS TO PRODUCTS SHORTCODE
    return do_shortcode("[products ids='$product_ids_str']");
   
}


add_action('user_new_form', 'remove_email_register_form'); 
function remove_email_register_form() { 
    echo '<script>jQuery(document).ready(function($) { 
        $("#send_user_notification").removeAttr("checked"); 
		$("#send_user_notification").parent("td").parent("tr").css("display","none");
    }); </script>';
}

add_action('user_register', 'send_welcome_mail', 10, 1); 
function send_welcome_mail($user_id) { 
	$siteName = get_bloginfo();
	$siteUrl = get_site_url();
	$adminEmail = get_option('admin_email');

	if(isset($_POST['email'])) {
		$userEmail = $_POST['email'];
	} else {
		$userEmail = $_POST['user_email-14'];
	}
	if(isset($_POST['email'])) {
		$userPass = $_POST['pass1'];
	} else {
		$userPass = $_POST['user_password-14'];
	}
	
	$loginPageId = UM()->options()->get('core_login');
	if(get_post($page_id)) {
		$loginUrl = get_permalink($loginPageId);
	} else {
		$loginUrl = $siteUrl;
	}	
	
	$to = $userEmail;
	$subject = "Welcome to Virtual Vouchers!";
	$txt = '<div style="max-width: 660px;padding: 20px;background: #ffffff;border-radius: 5px;margin: 40px auto;font-family: Open Sans,Helvetica,Arial;font-size: 15px;color: #666">
	<div style="color: #444444;font-weight: normal">
	<div style="text-align: center;font-weight: 600;font-size: 26px;padding: 10px 0;border-bottom: solid 3px #eeeeee">'.$siteName.'</div>
	<div style="clear: both"> </div>
	</div>
	<div style="padding: 0 30px 30px 30px;border-bottom: 3px solid #eeeeee">
	<div style="padding-top: 30px; padding-right: 0px; font-size: 24px; text-align: center">Thank you for signing up!</div>
	<div style="padding-top: 5px; padding-right: 0px; font-size: 24px; text-align: center">Your account is now active.</div>
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Your account Username: '.$userEmail.'</div>
	<div style="padding-top: 10px; padding-right: 0px; padding-bottom: 30px; font-size: 18px; text-align: center">Your account Password: '.$userPass.'</div>
	<div style="padding: 10px 0 50px 0;text-align: center"><a style="background: #555555;color: #fff;padding: 12px 30px;text-decoration: none;border-radius: 3px;letter-spacing: 0.3px" href="'.$loginUrl.'">Login to our site</a></div>
	<div style="padding: 20px">If you have any problems, please contact us at <a style="color: #3ba1da;text-decoration: none" href="mailto:'.$adminEmail.'">'.$adminEmail.'</a></div>
	</div>
	<div style="color: #999;padding: 20px 30px">
	<div>Thank you!</div>
	<div>The <a style="color: #3ba1da;text-decoration: none" href="'.$siteUrl.'">'.$siteName.'</a> Team</div>
	</div>
	</div>';
	
	$headers[] = 'Content-type: text/html; charset=utf-8';
	$headers[] = "From: azhagappan109@gmail.com";
	wp_mail($to, $subject, $txt, $headers);
}

add_action( 'woocommerce_checkout_order_processed', 'checkout_order_processed',  1, 1  );
function checkout_order_processed( $order_id ){
    $order = new WC_Order( $order_id );
    $payment_method = get_post_meta( $order->id, '_payment_method', true );
    if(isset($_POST['hidden_bulk_order_save']) && $_POST['hidden_bulk_order_save'] == 'saveorder'){
   		WC()->session->set( 'hidden_bulk_order_save', 'saveorder');
	}else{
		if($payment_method == 'cod'){
			$order->update_status( 'completed' );
		}
	}
}

add_action('woocommerce_add_order_item_meta','wdm_add_values_to_order_item_meta',1,2);
if(!function_exists('wdm_add_values_to_order_item_meta'))
{
  function wdm_add_values_to_order_item_meta($item_id, $values)
  {
        global $woocommerce,$wpdb;
        if(isset($values['bulk_orders'])){
	        $bulk_orders = $values['bulk_orders'];
	        $order_type = $values['order_type'];
	        $add_size = $values['add_size'];

	        if(!empty($bulk_orders))
	        {
	            wc_add_order_item_meta($item_id,'bulk_orders',serialize($bulk_orders));  
	        }
	        if(!empty($order_type))
	        {
	            wc_add_order_item_meta($item_id,'order_type',$order_type);  
	        }
	        if(!empty($add_size))
	        {
	            wc_add_order_item_meta($item_id,'add_size',serialize($add_size));  
	        }
    	}
  }
}
add_filter( 'woocommerce_available_payment_gateways' , 'unsetting_payment_gateway', 10, 1); 
function unsetting_payment_gateway( $available_gateways ) { 
	$session_order_type = WC()->session->get('session_order_type');
	if(isset($session_order_type) && $session_order_type == 'bulk order'){
		unset($available_gateways['payfast']); 
	}else{
		unset($available_gateways['cod']); 
	}

	return $available_gateways; 
}

/*add_action( 'woocommerce_thankyou', 'my_custom_status_update' );

function my_custom_status_update( $order_id ) {

    $order = new WC_Order( $order_id );
    $order->update_status( 'awaiting-shipment' );

}*/

/*add_role('moderator1', __(
   'Moderator1'),
   array(
       'read'            => true, // Allows a user to read
       'create_posts'      => true, // Allows user to create new posts
       'edit_posts'        => true, // Allows user to edit their own posts
       'edit_others_posts' => true, // Allows user to edit others posts too
       'publish_posts' => true, // Allows the user to publish posts
       'manage_categories' => true, // Allows user to manage post categories
       'create_users' => true,
       'delete_users' => true,
       'edit_users' => true,
	   'list_users' => true,
	   'promote_users' => true,
	   'remove_users' => true
       )
);*/


add_action( 'wp_ajax_nopriv_bulk_order_mail', 'bulk_order_mail' );
add_action( 'wp_ajax_bulk_order_mail', 'bulk_order_mail' );
function bulk_order_mail(){
	global $wpdb;
	$siteName = get_bloginfo();
	$siteUrl = get_site_url();
	$adminEmail = get_option('admin_email');
	$to = get_field('bulk_order_email','option');;
	$subject = "Virtual Vouchers Special Order";
	$txt = '<div style="max-width: 660px;padding: 20px;background: #ffffff;border-radius: 5px;margin: 40px auto;font-family: Open Sans,Helvetica,Arial;font-size: 15px;color: #666">
	<div style="color: #444444;font-weight: normal">
	<div style="text-align: center;font-weight: 600;font-size: 26px;padding: 10px 0;border-bottom: solid 3px #eeeeee">'.$siteName.'</div>
	<div style="clear: both"> </div>
	</div>
	<div style="padding: 0 30px 30px 30px;border-bottom: 3px solid #eeeeee">
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Contact Person: '.$_POST['name'].'</div>
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Contact email: '.$_POST['email'].'</div>
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Contact Phone Number: '.$_POST['number'].'</div>
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Expected Delivery Date: '.$_POST['exp_date'].'</div>
	<div style="padding-top: 15px; padding-right: 0px; font-size: 18px; text-align: center">Voucher Message: '.$_POST['message'].'</div>
	</div>
	</div>
	<div style="color: #999;padding: 20px 30px">
	<div>Thank you!</div>
	<div>The <a style="color: #3ba1da;text-decoration: none" href="'.$siteUrl.'">'.$siteName.'</a> Team</div>
	</div>
	</div>';
	
	$headers[] = 'Content-type: text/html; charset=utf-8';
	$headers[] = "From: azhagappan109@gmail.com";
	wp_mail($to, $subject, $txt, $headers);
}


add_action( 'wp_ajax_accept_terms_condition', 'accept_terms_condition' );    
add_action( 'wp_ajax_nopriv_accept_terms_condition', 'accept_terms_condition' ); 
function accept_terms_condition(){
    $userinfo = wp_get_current_user();
    $all_meta_for_user = get_user_meta($userinfo->ID);
    $updated = array('Please accept Terms & Conditions');
    update_user_meta( $userinfo->ID, 'terms-conditions', serialize($updated) );
    echo 'updated';exit;
    //echo "<pre>";print_r($all_meta_for_user);echo "</pre>";
}
function numberformat($value){
	return number_format($value,2);
}

// // 1. Allow Order Again for Processing Status
  
// add_filter( 'woocommerce_valid_order_statuses_for_order_again', 'bbloomer_order_again_statuses' );
  
// function bbloomer_order_again_statuses( $statuses ) {
//     $statuses[] = 'pending';
//     return $statuses;
// }
  
// // ----------------
// // 2. Add Order Actions @ My Account
  
// add_filter( 'woocommerce_my_account_my_orders_actions', 'bbloomer_add_edit_order_my_account_orders_actions', 50, 2 );
  
// function bbloomer_add_edit_order_my_account_orders_actions( $actions, $order ) {
//     if ( $order->has_status( 'pending' ) ) {
//         $actions['edit-order'] = array(
//             'url'  => wp_nonce_url( add_query_arg( array( 'order_again' => $order->get_id(), 'edit_order' => $order->get_id() ) ), 'woocommerce-order_again' ),
//             'name' => __( 'Edit Order', 'woocommerce' )
//         );
//     }
//     return $actions;
// }
  
// // ----------------
// // 3. Detect Edit Order Action and Store in Session
  
// // add_action( 'woocommerce_cart_loaded_from_session', 'bbloomer_detect_edit_order' );
             
// // function bbloomer_detect_edit_order( $cart ) {
// //     if ( isset( $_GET['edit_order'], $_GET['_wpnonce'] ) && is_user_logged_in() && wp_verify_nonce( wp_unslash( $_GET['_wpnonce'] ), 'woocommerce-order_again' ) ) WC()->session->set( 'edit_order', absint( $_GET['edit_order'] ) );
	
// // 	// if(isset( $_GET['recipient'] ) || isset( $_GET['recipient_number'] ) || isset( $_GET['personalized'] )){
// // 		$recipient = isset( $_GET['recipient'] )  ? esc_attr( $_GET['recipient'] )  : '';
// //         $recipient_number  = isset( $_GET['recipient_number'] ) ? esc_attr( $_GET['recipient_number'] ) : '';
// //         $personalized  = isset( $_GET['personalized'] ) ? esc_attr( $_GET['personalized'] ) : '';
// // 		WC()->session->set( 'edit_order', array( 'recipient' => $recipient, 'recipient_number' => $recipient_number, 'personalized' => $personalized ) );
// // 	// }
// // }
  
// // ----------------
// // 4. Display Cart Notice re: Edited Order
  
// add_action( 'woocommerce_before_cart', 'bbloomer_show_me_session' );
  
// function bbloomer_show_me_session() {
//     if ( ! is_cart() ) return;
//     $edited = WC()->session->get('edit_order');
//     if ( ! empty( $edited ) ) {
//         $order = new WC_Order( $edited );
//         $credit = $order->get_total();
//         // wc_print_notice( 'A credit of ' . wc_price($credit) . ' has been applied to this new order. Feel free to add products to it or change other details such as delivery date.', 'notice' );
//     }
// }
  
// // ----------------
// // 5. Calculate New Total if Edited Order
   
// // add_action( 'woocommerce_cart_calculate_fees', 'bbloomer_use_edit_order_total', 20, 1 );
   
// // function bbloomer_use_edit_order_total( $cart ) {
    
// //   if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
     
// //   $edited = WC()->session->get('edit_order');
// //   if ( ! empty( $edited ) ) {
// //       $order = new WC_Order( $edited );
// //       $credit = -1 * $order->get_total();
// //       $cart->add_fee( 'Credit', $credit );
// //   }
    
// // }
  
// // ----------------
// // 6. Save Order Action if New Order is Placed
  
// add_action( 'woocommerce_checkout_update_order_meta', 'bbloomer_save_edit_order' );
   
// function bbloomer_save_edit_order( $order_id ) {
//     $edited = WC()->session->get( 'edit_order' );
//     if ( ! empty( $edited ) ) {
//         // update this new order
//         update_post_meta( $order_id, '_edit_order', $edited );
//         $neworder = new WC_Order( $order_id );
//         $oldorder_edit = get_edit_post_link( $edited );
//         $neworder->add_order_note( 'Order placed after editing. Old order number: <a href="' . $oldorder_edit . '">' . $edited . '</a>' );
//         // cancel previous order
//         $oldorder = new WC_Order( $edited );
//         $neworder_edit = get_edit_post_link( $order_id );
//         $oldorder->update_status( 'cancelled', 'Order cancelled after editing. New order number: <a href="' . $neworder_edit . '">' . $order_id . '</a> -' );
//         WC()->session->set( 'edit_order', null );
//     }
// }

function removeorder(){
	global $wpdb;
	global $woocommerce;
	$user_id = get_current_user_id();
	$customer = new WC_Customer( $user_id );
	echo $last_order = $customer->get_last_order();
	$last_order->update_status( 'cancelled' );
	wp_redirect('http://202.129.196.139:3444/voucher/checkout');
	exit;
}
add_action( 'wp_ajax_nopriv_removeorder', 'removeorder' );
add_action( 'wp_ajax_removeorder', 'removeorder' );

// add_filter('custom_email','my_email_template',10,2)
// function