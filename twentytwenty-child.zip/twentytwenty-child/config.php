 <?php  
 return [  
   'db_username' => 'root',  
   'db_password' => '',  
   'db_name' => 'voucher',  
   'sid' => 'ACc7020830ee8e933353c573aaa1633141',  
   'token' => 'ecf9978c42f130334a48ed8f3605f0bb',  
   'from' => '+27600197711'  
 ];  