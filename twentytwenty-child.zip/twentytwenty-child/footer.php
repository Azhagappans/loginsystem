<?php
$userinfo = wp_get_current_user();
$all_meta_for_user = get_user_meta($userinfo->ID);
  //print_r( $all_meta_for_user );  
//echo "<pre>";print_r($all_meta_for_user);echo "</pre>";
if(isset($all_meta_for_user['terms-conditions']) && !empty($all_meta_for_user['terms-conditions'])){
}else{
  if(isset($userinfo->ID) && !empty($userinfo->ID)){
?>
<!-- Modal -->
<div class="modal" id="exampleModalCenter-new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="display: block !important;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Terms and Conditions</h5>
      </div>
      <div class="modal-body">
      <?php
      $id = 864; 
      $post = get_post($id); 
      $content = apply_filters('the_content', $post->post_content); 
      echo $content;   ?>
      </div>
      <div class="modal-footer">
        <div class="col-6"> 
          <button type="button" id="tc-accept1" data-dismiss="modal" class="btn btn-primary">Accept</button>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
  }
}
?>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Terms and Conditions</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php
      $id = 864; 
      $post = get_post($id); 
      $content = apply_filters('the_content', $post->post_content); 
      echo $content;   ?>
      </div>
      <div class="modal-footer">
        <div class="col-6"> 
          <button type="button" id="tc-accept" data-dismiss="modal" class="btn btn-primary">Accept</button>
        </div>
        <div class="col-6">
          <button type="button" id="tc-decline" class="btn btn-secondary" data-dismiss="modal">Decline</button>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="cancelorder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Order.?</h5>
        
      </div>
      <div class="modal-body">
          Do you want to delete the order?
      </div>
      <div class="modal-footer">
        <a type="button" id="yes" class="btn btn-primary" onclick="orderCancel('<?php echo $order_id; ?>')">Delete order</a>
        <button type="button" class="btn btn-secondary" id="no" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>



<!-- otp-sms-modal -->
<div class="modal fade" id="otp_sms_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"><span>OTP</span></h5>
      </div>
      <div class="modal-body">
        <p class="otp_text">Please enter the OTP sent to your mobile number</p><br>
        <p><input type="number" class="form-control otp_check rec_common_input" placeholder="Please enter 4-digits of OTP"></p>
      </div>
      <div class="modal-footer">
      <div class="col-12 otp_btn_area"> 
        <button type="button" id="otp_submit" class="btn btn-primary rec_common_btn">Submit</button>
      </div>
         </div>
    </div>
  </div>
</div>
<!-- otp-sms-modal -->


<!-- otp-email-modal -->
<div class="modal fade" id="otp_email_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"><span>OTP</span></h5>
      </div>
      <div class="modal-body">
        <p class="otp_text">OTP Sent To Entered Email</p><br>
        <p><input type="number" class="form-control otp_check_email rec_common_input" placeholder="Please enter 4-digits of OTP"></p>
      </div>
      <div class="modal-footer">
      <div class="col-12 otp_btn_area"> 
        <button type="button" id="otp_submit_email" class="btn btn-primary rec_common_btn">Submit</button>
      </div>
         </div>
    </div>
  </div>
</div>
<!-- otp-email-modal -->


<div id="overlay">
				<div class="cv-spinner">
					<span class="spinner"></span>
				</div>
			</div>




<?php wp_footer(); ?>
<script>
jQuery(".um-button.um-alt").attr("href", "<?php echo home_url(); ?>");
</script>
<!-- <script language="javascript">
	populateCountries("country_user", "city_user"); // first parameter is id of country drop-down and second parameter is id of state drop-down
	
</script> -->
</body>

</html>