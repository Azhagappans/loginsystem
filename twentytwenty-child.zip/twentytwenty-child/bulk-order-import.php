<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: Bulk Order Import
 */
get_header();
global $wpdb;

$error_message = '';

if (isset($_POST["Upload"])){

   if (isset($_FILES["file"])){

        $target_dir = realpath(__DIR__)."/uploads/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {} 

        $name = $_FILES["file"]["name"];
        $ext = end((explode(".", $name))); # extra () to prevent notice
        if($ext == 'csv'){
            $file = fopen($target_file,"r");
            $i = 1;
            $c = 0;
            $one_insert = 0;
            $product_id_count = array();
            $product_meta_array = array();
            $error_html = '';
            $mismatch_array = array();
            while (($data = fgetcsv($file)) !== FALSE)
            {
                if (array(null) !== $data) { // ignore blank lines
                    if($i>1){
                        //$query = $wpdb->prepare('SELECT ID FROM ' . $wpdb->posts . ' WHERE post_name = %s', sanitize_title_with_dashes($data[2]));
                        //$product_id = $wpdb->get_var( $query );
                        $titles = $data[2];
                        $product_ids = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE (post_title = '".$titles."' AND post_status = 'publish' )");
                        $product_id_ary = '';

                        if(isset($product_ids[0]->ID)){
                            $product_id_ary = $product_ids;
                        }
                        
                        if(!empty($product_id_ary)){
                        }else{
                            $titles = 'R'.$data[2];
                            $product_ids = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE (post_title = '". $titles ."' AND post_status = 'publish' )");
                        }
                        if(isset($product_ids[0]->ID)){
                            $product_id_ary = $product_ids;
                        }
                        
                        $productsID = '';
                        $termsname = '';
                        if(isset($product_id_ary) && !empty($product_id_ary)){
                            foreach($product_id_ary as $product_id){
                                //echo "<pre>";print_r($product_id); echo "</pre>";
                                $terms = get_the_terms( $product_id->ID, 'retailer' );
                                if(strtolower($terms[0]->name) == strtolower($data[0])){
                                    $productsID = $product_id->ID;
                                    $termsname = $terms[0]->name;
                                }
                            }
                        }
                        if(!empty($productsID) && !empty($termsname)){
                            $product_meta_array[$productsID][] = array('line_number'=>$i, 'retail_name'=>$data[0], 'phone_number'=>$data[1], 'value'=>$data[2], 'recipient_name'=>$data[3]);
                        }else{
                            $mismatch_array[] = array('line_number'=>$i, 'retail_name'=>$data[0], 'phone_number'=>$data[1], 'value'=>$data[2], 'recipient_name'=>$data[3], 'reason'=>' Retailer mismatched');
                            
                        }
                           
                    }
                    //$mismatch_array++;
                    $i++;
                }
            }
            //echo "<pre>";print_r($mismatch_array); echo "</pre>";
            $bulk_orders = array();
            $inventory_err_array = array();
            if(empty($mismatch_array)){
                if(isset($product_meta_array) && !empty($product_meta_array)){
                    foreach($product_meta_array as $key=>$value){
                        $product_id = $key;
                        $product = wc_get_product($product_id);
                        $vouchers = get_field('vouchers', $product_id);
                        $reserve_count = 0;
                        if(!empty($vouchers)){
                            foreach($vouchers as $voucher){
                                $status = $voucher['status'];
                                $reserved = $voucher['reserved'];
                                //echo  $status.'status';
                                if($status == 1 || strtolower($status) == 'available'){
                                    $reserve_count++;

                                     //echo $key.' In '.$reserve_count.'<br>';
                                }
                            }
                        }
                        //echo $key.' - '.$reserve_count.'<br>';
                        if(count($product_meta_array[$key]) <= $reserve_count){
                            $bulk_orders[$key] = $value;
                        }else{
                            $inventory_err_array[$key] = $value;
                        }
                    }
                }
            }
        }else{
            $error_message .= '<span class="success-mesage"><strong>Please upload the right format(csv)</strong></span><br>';
        }       
        
    }else{
         echo "No file selected <br />";
    }
}

if(isset($bulk_orders) && !empty($bulk_orders)){
   /* echo "<pre>";
    print_r($bulk_orders);
    echo "</pre>";*/
}
?>
<div class="main-content-area payment_report">
    <div class="page-inner-wrapper">
        <div class="user-management-page white-bg-wrap">
            <div class="">
                <div class="error-message">
                    <?php echo $error_message; ?>
                </div>
                <form action="" method="post" name="import_file_form" enctype="multipart/form-data">

                    <div class="row">
                        <div class="form-group" style="margin-right:12px;">
                            <!-- <label for="import">Upload CSV File<span class="text-danger"> * </span></label><br> -->
                            <select name="bulk_order_user" id="bulk_order_user" class="custom-select form-control">
                                <option value="">-- Select User --</option>
                                <?php
                                    $args = array(
                                            'role'    => 'subscriber',
                                            'orderby' => 'user_nicename',
                                            'order'   => 'ASC'
                                        );
                                    $users = get_users( $args );
                                    //echo "<pre>";print_r($users);echo "</pre>";
                                    foreach($users as $value){
                                        $user_name = $value->user_email;
                                        if(!empty($value->display_name)){
                                            $user_name = $value->display_name;
                                        }
                                ?>
                                        <option <?php if(isset($_POST['bulk_order_user']) && $_POST['bulk_order_user'] == $value->ID) echo 'selected="selected"'; ?> value="<?php echo $value->ID; ?>"><?php echo $user_name; ?></option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>                  
                        <div class="form-group">
                            <!-- <label for="import">Upload CSV File<span class="text-danger"> * </span></label><br> -->
                            <input type="file" class="form-control" name="file" id="files" placeholder="Upload CSV File" accept=".csv" >
                        </div>
                        <div class="form-group" style="margin-left: 12px;">
                            <label for="import" style="visibility: hidden;">submit</label>
                            <input type="submit" class="form-control" name="Upload"  id="upload_submit" value="Upload" style="line-height: 0;">
                        </div>                      
                    </div>
                </form>
                <?php
                if((isset($mismatch_array) && !empty($mismatch_array)) || (isset($inventory_err_array) && !empty($inventory_err_array)) ){
                ?>
                <div class="row">
                    
                    <div class="col-12">
                        <h3 class="text-left">Bulk order error report</h3>
                        <div class="table-responsive">
                            <table class="table table-bordered list_table dt-responsive display nowrap"  id="bulk_orders_import_table">
                                <thead>
                                    <tr>
                                        <th scope="col" width="20%" id="">Line Number</th>
                                        <th scope="col" width="20%" id="">Retailer</th>
                                        <th scope="col" width="20%" id="">Phone Number</th>
                                        <th scope="col" width="20%" id="">Value</th>
                                        <th scope="col" width="20%" id="">Recipient Name</th>
                                        <th scope="col" width="20%" id="">Reason</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach($mismatch_array as $array){
                                    ?>
                                        <tr>
                                            <td><?php echo $array['line_number']; ?></td>
                                            <td><?php echo $array['retail_name']; ?></td>
                                            <td><?php echo $array['phone_number']; ?></td>
                                            <td><?php echo $array['value']; ?></td>
                                            <td><?php echo $array['recipient_name']; ?></td>
                                            <td><?php echo $array['reason']; ?></td>
                                        </tr>                                  
                                    <?php 
                                    }
                                    ?>
                                    <?php
                                    foreach($inventory_err_array as $array){
                                        if(!empty($array)){
                                            foreach($array as $arr){
                                        ?>
                                            <tr>
                                                <td><?php echo $arr['line_number']; ?></td>
                                                <td><?php echo $arr['retail_name']; ?></td>
                                                <td><?php echo $arr['phone_number']; ?></td>
                                                <td><?php echo $arr['value']; ?></td>
                                                <td><?php echo $arr['recipient_name']; ?></td>
                                                <td><?php echo 'stock unavailable'; ?></td>
                                            </tr>                                  
                                        <?php
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php
                }else{
                    if(isset($bulk_orders) && !empty($bulk_orders)){
                    ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table class="table table-bordered list_table dt-responsive display nowrap"  id="bulk_orders_import_table">
                                    <thead>
                                        <tr>
                                            <th scope="col" width="20%" id="">Line Number</th>
                                            <th scope="col" width="20%" id="">Retailer</th>
                                            <th scope="col" width="20%" id="">Phone Number</th>
                                            <th scope="col" width="20%" id="">Value</th>
                                            <th scope="col" width="20%" id="">Recipient Name</th>
                                            <!-- <th scope="col" width="20%" id="">Reason</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($bulk_orders as $array){
                                        if(!empty($array)){
                                            foreach($array as $arr){
                                        ?>
                                            <tr>
                                                <td><?php echo $arr['line_number']; ?></td>
                                                <td><?php echo $arr['retail_name']; ?></td>
                                                <td><?php echo $arr['phone_number']; ?></td>
                                                <td><?php echo $arr['value']; ?></td>
                                                <td><?php echo $arr['recipient_name']; ?></td>
                                            </tr>                                  
                                        <?php
                                            }
                                        }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="page-button-wrapper bulk-order-import-checkout checkout_btn">
                                <a href="javascript:void(0);" id="bulkorder-checkout-button" class="checkout-button button alt wc-forward um-button">
                                Proceed to Checkout</a>
                            </div>
                    </div>
                    </div>
                    <?php
                    }
                }
                ?>
            </div>   
        </div>
    </div>
</div>

<?php get_footer(); ?>
<?php
// display navbar here
} else {  wp_redirect(home_url().'/log-in/'); } ?>
<?php
if(isset($bulk_orders) && !empty($bulk_orders)){
?>
    <script type="text/javascript">
    $("#bulkorder-checkout-button").click(function(){
        var jsonString = JSON.stringify();
        var bulk_order_user = $('#bulk_order_user').val();
        $('#overlay').show();
        jQuery.ajax({
            type: "POST",
            url: frontEndAjax.ajaxurl,
            data: {action: "bulk_order_import_add",nonce_ajax : frontEndAjax.nonce,jsondata:<?php echo json_encode($bulk_orders); ?>, bulk_order_user: bulk_order_user},
            dataType : "json",
            }).done(
            function(data){    
                window.location.href="<?php echo home_url(); ?>/checkout";
            });
    });
    </script>
<?php
}
?>