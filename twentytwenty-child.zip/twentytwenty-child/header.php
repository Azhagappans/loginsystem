<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package voucher
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Specification Voucher System</title>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="profile" href="http://gmpg.org/xfn/11"> -->

	<?php
	wp_head();

	/**/
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	$image = wp_get_attachment_image_src( $custom_logo_id, 'full');
	$first_name = wp_get_current_user()->user_firstname;
	$lastname = wp_get_current_user()->user_lastname;
	$username = wp_get_current_user()->display_name; 
	$update = wp_get_current_user()->user_login;
	$title = get_the_title();
	$title_tag = $_GET['pay'];
	if(is_wc_endpoint_url( 'order-received' )) {
		$order_id = get_query_var('order-received');
		$title_tag = "order-received";
	 }
	 if(is_wc_endpoint_url( 'order-pay' )) {
		 $order_id = get_query_var('order-pay');
		 $title_tag = "order-pay";
	  }
	?>

</head>
<script type="text/javascript">
	var home_url = "<?php echo home_url(); ?>";
</script>
<body>

	<?php
	$loop = new WP_Query(
		array(
			'post_type' => 'help', // This is the name of your post type - change this as required,
			// This is the amount of posts per page you want to show
			'post__not_in' => array(864)
		)
	);
	
	/**/
	while ( $loop->have_posts() ) : $loop->the_post();
	// The content you want to loop goes in here:
	?>
		<!-- Modal -->
		<div class="modal fade help_modal" id="<?php the_title(); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content" id="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel"><?php the_title(); ?></h3>
				<button type="button" class="close close_btn" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<p><?php the_content(); ?></p>
			</div>
			<div class="modal-footer">
				<button type="button" id="close" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
			</div>
		</div>
		</div>
	<?php
	endwhile;
	wp_reset_postdata();
	/**/
	?>

<section class="page-wrapper">
	<?php
	get_sidebar(); 
	?>

	<div class="main-page-wrapper min-sidebar">
		<div class="cus-header">
			<div class="row">
				<div class="col-xl-4 col-lg-4">
					<div class="page-title">
						<h2> <span class="cus-heading-color-blue">Virtual</span> <span class="cus-heading-color">Vouchers</span></h2>
					</div>
				</div>
				<div class="col-xl-4 col-lg-4">
					<div class="page-title page_head">
						<?php 
						
						if ($title) {
							if ($title == "test") {
								echo "<h4>Place New Order</h4>";
							} else 
							{
								if (($title == "Checkout" ) && (!$title_tag)) {
									echo "<h4>Your Order</h4>";
								} else {
									if ($title == "My account") {
										echo "<h4>My Orders</h4>";
									} else {
										if($title_tag == "order-received"){
											echo "<h4>Payment Confirmation</h4>";
										}else{ if($title_tag == "order-pay"){
											echo "<h4>Checkout</h4>";
										}else{
										
						?>
										<h4><?php echo $title; ?></h4><?php
									} }
								}
																	
																}
															}
														}; ?>
					</div>
				</div>
				<div class="col-xl-4 col-lg-4">
					<div class="header-right">

						<div class="help-wrapper">
							<div class="help-icon">
								<a href="#" data-toggle="modal" data-target="#help"><span class="fa fa-question"></span></a>
							</div>
						</div>
						<div class="profile-wrap">
							<div class="dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										<?php if ($first_name) {
											echo $first_name; ?>
										<?php echo $lastname;
										} else { ?>
										<?php echo $username;
										} ?>
										<?php /* <span><?php echo wp_get_current_user()->roles[0]; ?></span>*/ ?>
									</div>
								</a>
								<div class="dropdown-menu fade" aria-labelledby="navbarDropdown">
									<a class="dropdown-item" href="/voucher/my-profile2/?um_action=edit"><span class="fa fa-user-o"></span>My Profile</a>
									<div class="dropdown-divider"></div>
									<?php if(WC()->cart && !WC()->cart->is_empty()){ ?>
										<a class="dropdown-item logout_btn" data-toggle="modal" data-target="#logoutalert"><span class="fa fa-sign-out"></span>Log Out</a>
									<?php } else{ ?>
										<a href="http://202.129.196.139:3444/voucher/sample-page/?redirect_to=http://202.129.196.139:3444/voucher/log-in/" class="dropdown-item"><span class="fa fa-sign-out"></span>Log Out</a>
									<?php }?>
									
								</div>
							</div>
						</div>
						<div class="mob-toggle">
							<span><i class="fa fa-bars" aria-hidden="true"></i></span>
						</div>
					</div>
				</div>				

			</div>
		</div>
		
		<div class="help-sidebar">
			<div class="close">
				<span class="fa fa-times"></span>
			</div>
			<div class="help-wrapper">
				<h2>Help</h2>
				
				<?php				
				$loop = new WP_Query(
					array(
						'post_type' => 'help', 
						'order' => 'ASC',
						'post__not_in' => array(864)
					)
				);
				while ($loop->have_posts()) : $loop->the_post();
				?>
					<ul class="list-unstyled">
						<li data-toggle="modal" data-target="#<?php the_title(); ?>"><?php the_title(); ?></li>
					</ul>
				<?php
				endwhile;
				wp_reset_postdata();				
				?>
			</div>
		</div>				


<!-- Logout-Modal -->
<div class="modal fade" id="logoutalert" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Logout?</h5>
        
      </div>
      <div class="modal-body">
      Your order is unsaved. Do you want to save it before exiting?
        <?php

          // For logged in users only
          if ( is_user_logged_in() ) :

          $user_id = get_current_user_id(); // The current user ID
          //echo $user_id;
          // Get the WC_Customer instance Object for the current user
          $customer = new WC_Customer( $user_id );
          
          // Get the last WC_Order Object instance from current customer
          $last_order = $customer->get_last_order();
          // print_r($last_order);
          if($last_order) {
            $order_id     = $last_order->get_id(); // Get the order id
            $order_data   = $last_order->get_data(); // Get the order unprotected data in an array
            $order_status = $last_order->get_status(); // Get the order status
          }
          // add_action( 'woocommerce_checkout_order_processed', 'save_voucher_order',  1, 1  );
          // WC()->cart->empty_cart();
        ?>

        
        <?php endif; ?>
      </div>
      <div class="modal-footer">
      <?php 
      if(get_the_title() == "Checkout"){ ?>
		<button type="button" class="btn btn-secondary logout_yes" id="yes">Yes</button>
	  <?php }else { 
      // if($order_status == "pending"){ ?>
        <a type="button" class="btn btn-secondary" id="yes" href="http://202.129.196.139:3444/voucher/sample-page/?redirect_to=http://202.129.196.139:3444/voucher/log-in/">Yes</button>
      <?php }
    // } else {?>
          <a type="button" class="btn btn-secondary logout_no"  id="no"  href="http://202.129.196.139:3444/voucher/sample-page/?redirect_to=http://202.129.196.139:3444/voucher/log-in/">No</a>
         <?php 
        // }?>
        <!-- <button type="button" class="btn btn-secondary" id="no" data-dismiss="modal">No</button> -->
      </div>
    </div>
  </div>
</div>
<!-- Logout-Modal -->