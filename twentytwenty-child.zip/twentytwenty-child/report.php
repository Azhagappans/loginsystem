<?php 
if (get_current_user_id()) {
	// display navbar here
 ?>
 <?php
/**
* Template Name: Report
 */
 get_header();
if(isset($_GET['productid']) && !empty($_GET['productid'])){
    $productId = base64_decode($_GET['productid']);
    //$products = wc_get_product( $productId );
}else{
    $args = array( 'post_type' => 'product',
                'posts_per_page' => -1,
                'status' => 'publish',
                'orderby'   => array(
                                    'date' =>'DESC',
                                    'menu_order'=>'ASC',
                                    ));
    $loop = new WP_Query( $args );
}
?>
<div class="main-content-area payment_report">
<div class="page-inner-wrapper">
<div class="user-management-page white-bg-wrap">

    <div class="container-div">
        <div class="row">
            <div class="col-12">
                <input type="hidden" id="filteredData_report" name="filteredData" value="0">
                <input type="hidden" id="search_hidden" name="" value="">
                <table cellspacing="5" cellpadding="5" class="borderless">
                <tbody>
                    <tr>
                        <td>Status:</td>
                        <td>
                            <select id="filter_status" class="">
                                <option value="0">-- Select Status --</option>
                                <option value="Available">Available</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Sold">Sold</option>
                                <option value="Expired">Expired</option>
                            </select>
                        </td>
                        <td>Retailer:</td>
                        <td>
                            <select id="filter_retailer" class="">
                                <option value="0">-- Select Retailer --</option>
                                <?php
                                $retailers = get_terms( 'retailer', array(
                                            'hide_empty' => false,
                                            'post_type' => 'product',
                                            'orderby' => 'name',
                                            'order'   => 'ASC',
                                            ) );
                        
                                foreach($retailers as $value) { ?>
                                <option value="<?php echo $value->name;?>"><?php echo $value->name;?></option>
                                <?php } ?>
                            </select>
                        </td>
                        <?php /* ?><td><button type="" id="" class="action-btn filter_by_reports" data-toggle="modal"  title="Filter"><i class="fa fa-filter"></i></button></td>
                        <td><button type="" id="" class="action-btn report_filters_reset reset_filter" data-toggle="modal"  title="Reset"><i class="fa fa-repeat"></i></button></td><?php */ ?>
                    </tr>
                    <tr>
                        <td>Expiry Date From:</td>
                        <td><input type="text" id="dlo_from_report" name="dlo_from" class="date_input_filters"></td>
                        <td>Expiry Date To:</td>
                        <td><input type="text" id="dlo_to_report" name="dlo_to" class="date_input_filters"></td>
                        <td><button type="" id="" class="action-btn filter_by_reports" data-toggle="modal"   title="Filter"><i class="fa fa-filter"></i></button></td>
                        <td><button type="" id="" class="action-btn report_filters_reset reset_filter" data-toggle="modal" title="Reset"><i class="fa fa-repeat"></i></button></td>
                    </tr>
                    
                </tbody>
                </table>
                <table cellspacing="5" cellpadding="5" class="borderless">
                    <tbody>
                        <tr>
                            <td width="30%">Total Value : <div style="display: inline-block; font-weight: bold;" id="valueTotalSum"></div></td>
                            <td width="0%"></td>
                            <td width="10%"></td>
                            <td width="20%"></td>
                            <td width="20%"></td>
                            <td width="20%"></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="cus-report-section">

      <?php /* ?>  <form action="" method="post" class="import_export search_status searchfilternew" name="import_file_form" enctype="multipart/form-data">
            <div class="form-group">
                <select id="filter_status" class="custom-select form-control">
                    <option value="0">-- Select Status --</option>
                    <option value="Available">Available</option>
                    <option value="On Hold">On Hold</option>
                    <option value="Sold">Sold</option>
                    <option value="Expired">Expired</option>
                </select>
            </div>                 
        </form>
        <form action="" method="post" class="import_export search_retailer" name="import_file_form" enctype="multipart/form-data">
            <div class="form-group">
                <select id="filter_retailer" class="custom-select form-control">
                    <option value="0">-- Select Retailer --</option>
                    <?php
                    $retailers = get_terms( 'retailer', array(
                                'hide_empty' => false,
                                'post_type' => 'product',
                                'orderby' => 'name',
                                'order'   => 'ASC',
                                ) );
            
                    foreach($retailers as $value) { ?>
                    <option value="<?php echo $value->name;?>"><?php echo $value->name;?></option>
                    <?php } ?>
                </select>
            </div>  

        </form>
        <form action="" method="post" class="import_export reset_filter_form" name="import_file_form" enctype="multipart/form-data">
            <div class="form-group">
                <a hrfe="" id="" class="action-btn report_filters_reset reset_filter" data-toggle="modal"  title="Reset"><i class="fa fa-repeat"></i></a>
            </div>
        </form>      
        <?php */ ?>
        <div class="row">
        <div class="col-md-12">                
        <div class="table-responsive">
            <table class="table table-bordered list_table column_height product-table-export"  id="product-table-export">
                <thead>
                <tr>
                    <th scope="col" width="10%" id="">Retailer</th>
                    <th scope="col" width="10%" id="">Expiry Date</th>
                    <th scope="col" width="15%" id="">Pin Number</th>
                    <th scope="col" width="15%" id="">Voucher Number</th>
                    <th scope="col" width="15%" id="">Value</th>
                    <th scope="col" width="10%" id="">Reserved</th>
                    <th scope="col" width="15%" id="">Status</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                    if(isset($_GET['productid']) && !empty($_GET['productid'])){
                        if( have_rows('vouchers', $productId) ):
                            $h = 1;
                            while ( have_rows('vouchers', $productId) ) : the_row();
                            $bulk = get_sub_field("reserved");
                            $status = get_sub_field("status");
                            $product = wc_get_product( $productId );
                            
                            $temp_date = get_sub_field("expiry_date");
                            if(!empty($temp_date)){
                                $expiry_date = str_replace('/', '-', $temp_date);
                                $expiry_date = date('Y-m-d', strtotime($expiry_date));
                            }
                        ?>
                        <tr>
                            <td><?php $terms = get_the_terms( $productId , 'retailer' );
                                $retailer_name =  $terms[0]->name;
                                echo $retailer_name; ?></td>
                            <td><?php echo $expiry_date; ?></td>
                            <td><?php echo get_sub_field("pin_number"); ?></td>
                            <td><?php echo get_sub_field("voucher_number"); ?></td>
                            <td data-search="<?php echo get_woocommerce_currency_symbol().$product->get_price(); ?>"><?php if(!empty($product->get_price())){ echo get_woocommerce_currency_symbol().numberformat($product->get_price()); }else{ ''; } ?></td>
                            <td><?php if($bulk == 1){ echo 'Yes';} if($bulk == 0){ echo 'No';} ?></td>
                            <td>
                                <?php 
                                if($status == 1){ 
                                    echo 'Available';
                                }
                                elseif($status == 2){ 
                                    echo 'On Hold';
                                }
                                elseif($status == 3){
                                    echo 'Sold';
                                }
                                elseif($status == 4){
                                    echo 'Expired';
                                }
                                else{
                                    echo "Available";
                                }
                                ?>
                            </td>
                        </tr>
                        <?php 
                            $h++;
                        endwhile;
                        else :
                        endif;
                    }else{
                        while ( $loop->have_posts() ) : $loop->the_post();
                            global $product;
                            $productId = get_the_ID();
                            $currency = get_woocommerce_currency_symbol();

                            if( have_rows('vouchers', $productId) ):
                                    $h = 1;
                                    while ( have_rows('vouchers', $productId) ) : the_row();
                                    $bulk = get_sub_field("reserved");
                                    $status = get_sub_field("status");
                                    $product = wc_get_product( $productId );

                                    $expiry_date = '';
                                    $temp_date = get_sub_field("expiry_date");
                                    if(!empty($temp_date)){
                                        $expiry_date = str_replace('/', '-', $temp_date);
                                        $expiry_date = date('Y-m-d', strtotime($expiry_date));
                                    }
                                ?>
                                <tr>
                                    <td><?php $terms = get_the_terms( $productId , 'retailer' );
                                        $retailer_name =  $terms[0]->name;
                                        echo $retailer_name; ?></td>
                                    <td><?php  echo $expiry_date;  ?></td>
                                    <td><?php echo get_sub_field("pin_number"); ?></td>
                                    <td><?php echo get_sub_field("voucher_number"); ?></td>
                                    <td data-search="<?php echo get_woocommerce_currency_symbol().$product->get_price(); ?>"><?php if(!empty($product->get_price())){ echo get_woocommerce_currency_symbol().numberformat($product->get_price()); }else{ ''; } ?></td>
                                    <td><?php if($bulk == 1){ echo 'Yes';} if($bulk == 0){ echo 'No';} ?></td>
                                    <td>
                                        <?php 
                                        if($status == 1){ 
                                            echo 'Available';
                                        }
                                        elseif($status == 2){ 
                                            echo 'On Hold';
                                        }
                                        elseif($status == 3){
                                            echo 'Sold';
                                        }
                                        elseif($status == 4){
                                            echo 'Expired';
                                        }
                                        else{
                                            echo "Available";
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php 
                                $h++;
                                endwhile;
                            else :
                            endif;
                        endwhile;
                        wp_reset_query();
                    }
                    ?>
                </tbody>
            </table>

        </div>            
        </div>
        </div>

        <?php if(isset($_GET['productid']) && !empty($_GET['productid'])) { ?>
            <div class="report-bottom">
                <a href="javascript:history.back()">Back</a>
            </div>
        <?php }?>
        
    </div>

</div>
</div>
</div>

<?php get_footer(); ?>
<?php
// display navbar here
} else {   wp_redirect(home_url().'/log-in/'); }?>