=== Appoinment Scheduling ===

Book an appoinment using this form for user available timings.

== Description ==

Book an appoinment using this form for user available timings.

== Installation ==
1.You can download our zip sile and extract the folder OR Upload the plugin zip file through the **Plugins** screen.
2. Upload the entire `appoinment-schedling` folder to the `/wp-content/plugins/` directory.
3. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

You will find **Appoinment Schedule** menu in your WordPress admin screen.
