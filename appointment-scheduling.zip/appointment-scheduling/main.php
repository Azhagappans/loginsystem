<?php
/*
Plugin Name: Appointment Scheduling
Plugin URI: http://localhost/test
Description: Appointment Scheduling for customer
Version: 1.0
Author: Azhagappan
Author URI: http://localhost/test
*/

add_action('admin_menu', 'custom_plugin_setup_menu');
function custom_plugin_setup_menu(){
    add_menu_page( 'Schedule Appoinment', 'Schedule Appoinment', 'manage_options', 'schedule-appoinment', 'wp_custom_form' );
}
 

wp_register_script( 'custom-script', plugins_url('assets/js/appoinment.js', __FILE__) );

wp_enqueue_script( 'custom-script' );

function wp_custom_form() {

    include('templates/form.php');
}

function app_create_table(){

    global $wpdb;
    $app       = apply_filters( 'app_database', $wpdb );
    $table_name = $app->prefix.'app_forms';

    if( $app->get_var("SHOW TABLES LIKE '$table_name'") != $table_name ) {

        $charset_collate = $app->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            form_id bigint(20) NOT NULL AUTO_INCREMENT,
            form_person_name varchar(20) NOT NULL,
            form_start_date date NOT NULL,
            form_end_date date NOT NULL,
            form_start_time varchar(20) NOT NULL,
            form_end_time varchar(20) NOT NULL,
            form_interval varchar(20) NOT NULL,
            PRIMARY KEY  (form_id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

}


function app_activate( $network_wide ){

    global $wpdb;
    if ( is_multisite() && $network_wide ) {
        // Get all blogs in the network and activate plugin on each one
        $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
        foreach ( $blog_ids as $blog_id ) {
            switch_to_blog( $blog_id );
            app_create_table();
            restore_current_blog();
        }
    } else {
        app_create_table();
    }
	// Add custom capability
	$role = get_role( 'administrator' );
}

register_activation_hook( __FILE__, 'app_activate' );


add_action('wp_ajax_add_form_transfer', 'process_submit_from');

function process_submit_from() {
    global $wpdb; 
    $person_name = $_POST['person_name'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $interval = $_POST['interval'];
    $table_name = $wpdb->prefix . 'app_forms';     
    $wpdb->insert($table_name, array('form_person_name' => $person_name, 'form_start_date' => $start_date,'form_end_date' => $end_date,'form_start_time' => $start_time,'form_end_time' => $end_time,'form_interval' => $interval, )); 
    
    wp_redirect(admin_url('admin.php?page=schedule-appoinment'));
    echo json_encode();
    die;    
}



?>