<?php 
$nds_add_meta_nonce = wp_create_nonce( 'nds_add_user_meta_form_nonce' ); ?>
<div class="main-page">
  <div class="container">
    <div class="appoinment-schedule">
      <h1>Schedule Appoinment</h1>
      <form action="<?php echo admin_url('admin-ajax.php'); ?>" method="post">
      <?php wp_nonce_field('add_form_transfer','security-code-here'); ?>
      <input name="action" value="add_form_transfer" type="hidden">
        <label>Person name</label><br>
        <input type="text" name="person_name" id="person_name"><br>
        <label>Start Date</label><br>
        <input type="date" name="start_date" id="start_date"><br>
        <label>End date</label><br>
        <input type="date" name="end_date" id="end_date"><br>
        <label>Available Time Start From</label><br>
        <input type="time" name="start_time" id="start_time"><br>
        <label>Ends at</label><br>
        <input type="time" name="end_time" id="end_time"><br>
        <label>Interval</label><br>
        <select name="interval" id="interval">
          <option value="10mins">10mins</option>
          <option value="20mins">20mins</option>
          <option value="30mins">30mins</option>
          <option value="40mins">40mins</option>
          <option value="50mins">50mins</option>
          <option value="60mins">60mins</option>
        </select><br>
        <br>
        <input type="submit" id="app_submit">
      </form>
    </div>
  </div>
</div>